


import pytest

from cart3r.brain.fees import impact_pct


def test_ratio_field_is_multiplied():
    assert impact_pct({"priceImpactPct": "0.0123", "priceImpact": 1.23}) == pytest.approx(1.23)


def test_percent_field_is_kept_as_is():
    assert impact_pct({"priceImpact": 0.56}) == pytest.approx(0.56)
    assert impact_pct({"priceImpact": -2.5}) == pytest.approx(2.5)


def test_missing_impact_is_an_error():
    with pytest.raises(ValueError):
        impact_pct({})


def test_usd_values_take_priority():
    q = {"inUsdValue": 5.0, "outUsdValue": 4.9, "priceImpact": 98.0, "priceImpactPct": "0.98"}
    assert impact_pct(q) == pytest.approx(2.0)
