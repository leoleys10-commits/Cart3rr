import asyncio
from datetime import datetime, timezone

from cart3r.core.events import InMemoryEventBus
from cart3r.ingest.graduations import GraduationPoller
from cart3r.sources.base import Fresh
from cart3r.sources.gecko_parse import WSOL, parse_new_pools

MINT = "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJospump"


def pool(addr, dex, base, quote=WSOL, created="2026-11-27T08:00:00Z"):
    return {
        "id": f"solana_{addr}", "type": "pool",
        "attributes": {"address": addr, "pool_created_at": created},
        "relationships": {
            "base_token": {"data": {"id": f"solana_{base}"}},
            "quote_token": {"data": {"id": f"solana_{quote}"}},
            "dex": {"data": {"id": dex}},
        },
    }


def test_parse_keeps_only_pumpswap_sol_pools():
    body = {"data": [
        pool("P1", "pumpswap", MINT),
        pool("P2", "pump-fun", "Other111"),
        pool("P3", "raydium", "Ray111"),
        pool("P4", "pumpswap", "Usdc111", quote="EPjFWdd5AufqSSqeM2qJ1zzybapC8G4wEGGkZwyTDt1v"),
    ]}
    out = parse_new_pools(body)
    assert [(p.pool, p.mint) for p in out] == [("P1", MINT)]
    assert out[0].created_at == datetime(2026, 11, 27, 8, tzinfo=timezone.utc)


def test_parse_inverted_pool_and_bad_input():
    out = parse_new_pools({"data": [pool("P1", "pumpswap", WSOL, quote=MINT, created="bad")]})
    assert out[0].mint == MINT and out[0].created_at is None
    assert parse_new_pools({}) == [] and parse_new_pools({"data": [{}]}) == []


class FakeGecko:
    def __init__(self, pages):
        self.pages, self.calls = pages, []

    async def new_pools(self, page=1):
        self.calls.append(page)
        return Fresh(self.pages.get(page, {"data": []}), datetime.now(timezone.utc), "geckoterminal")


def test_poller_publishes_once_and_stops_paging():
    filler = [pool(f"F{i}", "pump-fun", f"T{i}") for i in range(19)]
    gecko = FakeGecko({1: {"data": [pool("P1", "pumpswap", MINT)] + filler}, 2: {"data": []}})
    bus = InMemoryEventBus()
    poller = GraduationPoller(gecko, bus, max_pages=3, page_gap_s=0)
    assert asyncio.run(poller.poll_once()) == 1
    ev = bus.log[0]
    assert ev.type == "token.graduated" and ev.payload["mint"] == MINT
    assert ev.payload["created_at"].startswith("2026-11-27T08:00")
    assert gecko.calls == [1, 2]
    # Deuxième passage : pool déjà vu → rien de publié, pas de page suivante.
    gecko.calls.clear()
    assert asyncio.run(poller.poll_once()) == 0
    assert gecko.calls == [1]


def test_poller_survives_api_error():
    class Broken:
        async def new_pools(self, page=1):
            raise RuntimeError("429")
    assert asyncio.run(GraduationPoller(Broken(), InMemoryEventBus()).poll_once()) == 0


def test_non_pump_tokens_on_pumpswap_are_ignored():
    body = {"data": [pool("P1", "pumpswap", "5DtPAtcrGWjvYwm2jk98iPziLoNgB7PLbm4h84gmoon")]}
    assert parse_new_pools(body) == []
    assert len(parse_new_pools(body, require_pump_suffix=False)) == 1
