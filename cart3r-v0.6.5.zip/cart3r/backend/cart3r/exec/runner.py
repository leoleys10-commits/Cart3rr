"""Processus `exec` : exécution (Paper en V1) et gestion des positions ouvertes.

- `order.approved` → fill simulé sur quote réelle → position « open »
- boucle toutes les 5 s : valeur de revente, plan de sortie, ventes
- `wallet.trade` d'un wallet copié → vente au prorata
- PANIC STOP : plus aucun achat ; les ventes continuent (protéger le capital)

Le mode Live n'est PAS câblé : un ordre approuvé hors Paper est refusé avec
une alerte (signature réelle = phase 5, après les critères go/no-go).
NON TESTÉ EN RÉSEAU (câblage) ; logique testée dans `exits.py` et `paper.py`.
"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import datetime, timezone

import httpx

from cart3r.brain.shadow_recorder import QuoteResult
from cart3r.core.config import Secrets
from cart3r.core.events import Event
from cart3r.core.runtime import alert, create_pool, load_settings
from cart3r.db.event_store import PostgresEventBus
from cart3r.sources.clients import DexScreener, Jupiter

from .exits import ExitPlan, RiskFlags, apply, evaluate
from .paper import PaperBroker, PaperFillError

log = logging.getLogger(__name__)
LAMPORTS = 1_000_000_000


class Executor:
    def __init__(self, pool, bus, broker: PaperBroker, dex: DexScreener) -> None:
        self.pool, self.bus, self.broker, self.dex = pool, bus, broker, dex
        self.panic = False
        self.settings = None
        self.wallet_sells: dict[str, float] = {}  # position_id -> part vendue par le wallet suivi
        self._lock = asyncio.Lock()

    async def on_settings(self, _: Event | None = None) -> None:
        self.settings, _v = await load_settings(self.pool)

    async def _publish_fill(self, side: str, pos_id: str, lamports: int, corr: str | None, remaining: int = 0,
                            reason: str = "") -> None:
        await self.bus.publish(Event(
            type="order.filled", source="exec", observed_at=datetime.now(timezone.utc), correlation_id=corr,
            idempotency_key=f"fill:{pos_id}:{side}:{uuid.uuid4().hex[:8]}",
            payload={"side": side, "position_id": pos_id, "lamports": lamports,
                     "remaining_value_lamports": remaining, "reason": reason}))

    async def on_approved(self, ev: Event) -> None:
        p = ev.payload
        if self.panic:
            return await alert(self.bus, "warning", "panic", "Ordre ignoré : PANIC STOP actif")
        if p.get("mode") != "paper":
            return await alert(self.bus, "critical", "exec",
                               "Ordre réel refusé : l'exécution réelle n'est pas activée dans cette version.")
        try:
            fill = await self.broker.buy(p["mint"], int(p["lamports"]))
        except PaperFillError as exc:
            await self.bus.publish(Event(type="order.failed", source="exec", observed_at=datetime.now(timezone.utc),
                                         correlation_id=ev.correlation_id, payload={"reason": str(exc)}))
            return await alert(self.bus, "warning", "exec", f"Achat simulé impossible ({p['mint'][:6]}…) : {exc}")
        s = self.settings.exits
        plan = ExitPlan(stop_pct=float(p["stop_pct"]), trailing_pct=float(s.trailing_stop_pct),
                        take_profits=[(float(g), float(q)) for g, q in s.take_profit_levels])
        pos_id = uuid.uuid4().hex
        await self.pool.execute(
            "INSERT INTO positions (id, mint, mode, strategy, state, entry_lamports, token_amount, stop_pct, exit_plan, "
            "realized_lamports, opened_at, cost_lamports, last_value_lamports, entry_liquidity_usd, wallet, correlation_id) "
            "VALUES ($1,$2,'paper',$3,'open',$4,$5,$6,$7::jsonb,0,now(),$8,$9,$10,$11,$12)",
            pos_id, p["mint"], p["strategy"], int(p["lamports"]), fill.tokens, plan.stop_pct, json.dumps(plan.to_json()),
            fill.lamports, int(p["lamports"]), p.get("liquidity_usd"), p.get("wallet"), ev.correlation_id or "-")
        await self._publish_fill("buy", pos_id, fill.lamports, ev.correlation_id)
        await alert(self.bus, "info", "buy",
                    f"ACHAT (paper) {p['mint'][:6]}… {fill.lamports / LAMPORTS:.4f} SOL, stratégie {p['strategy']}, "
                    f"stop -{plan.stop_pct:.0f} %", mint=p["mint"])

    async def on_wallet_trade(self, ev: Event) -> None:
        p = ev.payload
        if p["side"] != "sell":
            return
        rows = await self.pool.fetch(
            "SELECT id FROM positions WHERE state <> 'closed' AND wallet = $1 AND mint = $2", p["wallet"], p["mint"])
        if not rows:
            return
        held_after = await self.pool.fetchval(
            "SELECT coalesce(sum(CASE WHEN side='buy' THEN token_amount ELSE -token_amount END), 0) "
            "FROM wallet_trades WHERE wallet = $1 AND mint = $2", p["wallet"], p["mint"])
        held_before = float(held_after) + int(p["token_amount"])
        frac = min(1.0, int(p["token_amount"]) / held_before) if held_before > 0 else 1.0
        for r in rows:
            self.wallet_sells[r["id"]] = frac

    async def _liquidity_drop(self, mint: str, entry_liq: float | None) -> float | None:
        if not entry_liq:
            return None
        try:
            pairs = (await self.dex.tokens([mint])).value
        except Exception:  # noqa: BLE001
            return None
        liq = max(((pp.get("liquidity") or {}).get("usd") or 0) for pp in pairs) if pairs else 0
        return max(0.0, 100.0 * (1 - float(liq) / float(entry_liq)))

    async def manage_once(self) -> None:
        rows = await self.pool.fetch("SELECT * FROM positions WHERE state IN ('open', 'blocked')")
        now = datetime.now(timezone.utc)
        for r in rows:
            plan = ExitPlan.from_json(json.loads(r["exit_plan"]) if isinstance(r["exit_plan"], str) else r["exit_plan"])
            tokens = int(r["token_amount"])
            remaining_cost = r["cost_lamports"] * (1 - plan.sold_fraction)
            try:
                value = await self.broker.value(r["mint"], tokens)
                unsellable = False
            except Exception:  # noqa: BLE001
                value, unsellable = 0, True
            ratio = value / remaining_cost if remaining_cost > 0 else 0
            prev = r["last_value_lamports"]
            if not unsellable and prev and value < 0.5 * int(prev):
                # Chute de plus de moitié en 5 s : on revérifie une fois avant d'agir,
                # pour ne pas vendre sur une quote aberrante (mauvais routage, pool vide…).
                await asyncio.sleep(2)
                try:
                    value = max(value, await self.broker.value(r["mint"], tokens))
                except Exception:  # noqa: BLE001
                    pass
                ratio = value / remaining_cost if remaining_cost > 0 else 0
            flags = RiskFlags(
                liquidity_drop_pct=await self._liquidity_drop(r["mint"], r["entry_liquidity_usd"]),
                followed_wallet_sold_fraction=self.wallet_sells.pop(r["id"], None), unsellable=unsellable)
            await self.pool.execute("UPDATE positions SET last_value_lamports = $2, state = $3 WHERE id = $1",
                                    r["id"], value, "blocked" if unsellable else "open")
            action = evaluate(plan, ratio, r["opened_at"], now, flags)
            await self.pool.execute("UPDATE positions SET exit_plan = $2::jsonb WHERE id = $1", r["id"],
                                    json.dumps(plan.to_json()))
            if action is None:
                continue
            sell_tokens = tokens if action.fraction_of_remaining >= 0.999 else int(tokens * action.fraction_of_remaining)
            closes = sell_tokens >= tokens
            try:
                fill = await self.broker.sell(r["mint"], sell_tokens, closes_position=closes)
            except PaperFillError as exc:
                await alert(self.bus, "warning", "exec", f"Vente simulée impossible ({r['mint'][:6]}…) : {exc}")
                continue
            apply(plan, action)
            left = tokens - sell_tokens
            realized = int(r["realized_lamports"]) + fill.lamports
            remaining_value = 0 if closes else int(value * left / tokens)
            await self.pool.execute(
                "UPDATE positions SET token_amount = $2, realized_lamports = $3, exit_plan = $4::jsonb, state = $5::varchar, "
                "closed_at = CASE WHEN $5::varchar = 'closed' THEN now() ELSE closed_at END, "
                "exit_reason = CASE WHEN $5::varchar = 'closed' THEN $6::varchar ELSE exit_reason END, "
                "last_value_lamports = $7 WHERE id = $1",
                r["id"], left, realized, json.dumps(plan.to_json()), "closed" if closes else "open", action.reason[:64],
                remaining_value)
            await self._publish_fill("sell", r["id"], fill.lamports, r["correlation_id"], remaining_value, action.reason)
            pnl = ""
            if closes:
                pnl = f", résultat net {100.0 * (realized - r['cost_lamports']) / r['cost_lamports']:+.1f} %"
            await alert(self.bus, "critical" if action.emergency else "info", "sell",
                        f"VENTE (paper) {r['mint'][:6]}… {action.fraction_of_remaining * 100:.0f} % — {action.reason}{pnl}",
                        mint=r["mint"])

    async def loop(self) -> None:
        while True:
            try:
                async with self._lock:
                    await self.manage_once()
            except Exception as exc:  # noqa: BLE001
                log.warning("gestion des positions en échec : %s", exc)
            await asyncio.sleep(5)


async def run_exec(secrets: Secrets) -> None:
    pool = await create_pool(secrets)
    bus = PostgresEventBus(pool, consumer="exec")
    async with httpx.AsyncClient(timeout=10) as http:
        jup = Jupiter(http, secrets.jupiter_api_key.get_secret_value() if secrets.jupiter_api_key else "")

        async def quote(inp: str, out: str, amount: int) -> QuoteResult:
            q = (await jup.quote(inp, out, amount, slippage_bps=300)).value
            fees = sum(int(q.get(k) or 0) for k in ("signatureFeeLamports", "prioritizationFeeLamports"))
            return QuoteResult(out_amount=int(q["outAmount"]), fee_lamports=fees)

        ex = Executor(pool, bus, PaperBroker(quote), DexScreener(http))
        await ex.on_settings()
        state = await pool.fetchval("SELECT state FROM guard_state WHERE id = 1")
        if state:
            ex.panic = bool((json.loads(state) if isinstance(state, str) else state).get("panic"))

        async def on_panic(_: Event) -> None:
            ex.panic = True

        async def on_resume(_: Event) -> None:
            ex.panic = False

        bus.subscribe("order.approved", ex.on_approved)
        bus.subscribe("wallet.trade", ex.on_wallet_trade)
        bus.subscribe("system.panic_stop", on_panic)
        bus.subscribe("system.resume", on_resume)
        bus.subscribe("settings.changed", ex.on_settings)
        await asyncio.gather(bus.run(), ex.loop())
