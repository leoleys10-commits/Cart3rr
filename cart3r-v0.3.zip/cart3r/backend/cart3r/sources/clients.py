"""Clients HTTP des sources externes (phase 3).

NON TESTÉS EN RÉSEAU dans l'environnement de développement actuel : ils seront
validés par les tests d'intégration (respx pour le format, puis appels réels
sur le VPS). Chaque méthode renvoie un `Fresh[...]` horodaté.

Références consultées le 27/11/2026 :
- Jupiter Swap API V2 : GET https://api.jup.ag/swap/v2/order (inputMint,
  outputMint, amount, taker optionnel, slippageBps), en-tête x-api-key.
- DexScreener : limites 300 req/min (paires/tokens) et 60 req/min (profils/boosts).
- RugCheck : API publique api.rugcheck.xyz (rapports mis en cache).
"""
from __future__ import annotations

import base64
from datetime import datetime, timezone
from typing import Any

import httpx

from .base import Fresh


def _now() -> datetime:
    return datetime.now(timezone.utc)


class RateLimiter:
    """Seau à jetons simple : `rate` requêtes par `per` secondes."""

    def __init__(self, rate: int, per: float) -> None:
        import asyncio
        import time

        self._rate, self._per = rate, per
        self._tokens = float(rate)
        self._last = time.monotonic()
        self._lock = asyncio.Lock()
        self._time = time

    async def acquire(self) -> None:
        import asyncio

        async with self._lock:
            while True:
                now = self._time.monotonic()
                self._tokens = min(self._rate, self._tokens + (now - self._last) * self._rate / self._per)
                self._last = now
                if self._tokens >= 1:
                    self._tokens -= 1
                    return
                await asyncio.sleep((1 - self._tokens) * self._per / self._rate)


class SolanaRpc:
    """JSON-RPC Solana (Helius ou RPC de secours)."""

    def __init__(self, url: str, name: str, client: httpx.AsyncClient, rps: int = 8) -> None:
        self.url, self.name, self._client = url, name, client
        self._limiter = RateLimiter(rps, 1.0)
        self._id = 0

    async def call(self, method: str, params: list[Any]) -> Any:
        await self._limiter.acquire()
        self._id += 1
        r = await self._client.post(self.url, json={"jsonrpc": "2.0", "id": self._id, "method": method, "params": params})
        r.raise_for_status()
        body = r.json()
        if "error" in body:
            raise RuntimeError(f"RPC {method}: {body['error']}")
        return body["result"]

    async def account_info(self, address: str) -> Fresh[tuple[bytes, str] | None]:
        res = await self.call("getAccountInfo", [address, {"encoding": "base64", "commitment": "confirmed"}])
        value = res.get("value")
        data = None if value is None else (base64.b64decode(value["data"][0]), value["owner"])
        return Fresh(data, _now(), self.name)

    async def largest_token_accounts(self, mint: str) -> Fresh[list[dict[str, Any]]]:
        res = await self.call("getTokenLargestAccounts", [mint, {"commitment": "confirmed"}])
        return Fresh(res["value"], _now(), self.name)

    async def signatures_for_address(self, address: str, limit: int = 50, before: str | None = None) -> Fresh[list]:
        cfg: dict[str, Any] = {"limit": limit, "commitment": "confirmed"}
        if before:
            cfg["before"] = before
        return Fresh(await self.call("getSignaturesForAddress", [address, cfg]), _now(), self.name)

    async def transaction(self, signature: str) -> Fresh[dict | None]:
        res = await self.call(
            "getTransaction",
            [signature, {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 1, "commitment": "confirmed"}],
        )
        return Fresh(res, _now(), self.name)

    async def recent_priority_fees(self, accounts: list[str]) -> Fresh[list[dict]]:
        return Fresh(await self.call("getRecentPrioritizationFees", [accounts]), _now(), self.name)

    async def token_account_owners(self, addresses: list[str]) -> Fresh[dict[str, str]]:
        """Propriétaire de chaque compte token (pour exclure pool et bonding curve du top 10)."""
        res = await self.call("getMultipleAccounts", [addresses, {"encoding": "jsonParsed", "commitment": "confirmed"}])
        owners: dict[str, str] = {}
        for addr, acc in zip(addresses, res.get("value") or []):
            try:
                owners[addr] = acc["data"]["parsed"]["info"]["owner"]
            except (TypeError, KeyError):
                continue
        return Fresh(owners, _now(), self.name)


class PriceFeed:
    """Cours SOL en EUR et USD (CoinGecko, API publique). Aucun cours de secours inventé."""

    URL = "https://api.coingecko.com/api/v3/simple/price"

    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client
        self._limiter = RateLimiter(5, 60.0)

    async def sol(self) -> Fresh[tuple[float, float]]:
        await self._limiter.acquire()
        r = await self._client.get(self.URL, params={"ids": "solana", "vs_currencies": "eur,usd"})
        r.raise_for_status()
        d = r.json()["solana"]
        return Fresh((float(d["eur"]), float(d["usd"])), _now(), "coingecko")


class DexScreener:
    BASE = "https://api.dexscreener.com"

    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client
        self._pairs = RateLimiter(250, 60.0)  # marge sous 300/min
        self._profiles = RateLimiter(50, 60.0)  # marge sous 60/min

    async def tokens(self, mints: list[str]) -> Fresh[list[dict]]:
        if not 0 < len(mints) <= 30:
            raise ValueError("1 à 30 adresses par appel")
        await self._pairs.acquire()
        r = await self._client.get(f"{self.BASE}/tokens/v1/solana/{','.join(mints)}")
        r.raise_for_status()
        return Fresh(r.json(), _now(), "dexscreener")

    async def latest_boosts(self) -> Fresh[list[dict]]:
        await self._profiles.acquire()
        r = await self._client.get(f"{self.BASE}/token-boosts/latest/v1")
        r.raise_for_status()
        return Fresh(r.json(), _now(), "dexscreener")


class GeckoTerminal:
    BASE = "https://api.geckoterminal.com/api/v2"

    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client
        self._limiter = RateLimiter(25, 60.0)  # marge sous ~30/min

    async def token_pools(self, mint: str) -> Fresh[dict]:
        await self._limiter.acquire()
        r = await self._client.get(f"{self.BASE}/networks/solana/tokens/{mint}/pools")
        r.raise_for_status()
        return Fresh(r.json(), _now(), "geckoterminal")


class Jupiter:
    BASE = "https://api.jup.ag/swap/v2"

    def __init__(self, client: httpx.AsyncClient, api_key: str) -> None:
        self._client, self._key = client, api_key
        self._limiter = RateLimiter(1, 1.0)  # offre gratuite : à ajuster selon le portail

    async def quote(self, input_mint: str, output_mint: str, amount: int, slippage_bps: int) -> Fresh[dict]:
        """Quote sans `taker` : sert au Fee Optimizer et au Shadow Trading, ne signe rien."""
        await self._limiter.acquire()
        r = await self._client.get(
            f"{self.BASE}/order",
            params={"inputMint": input_mint, "outputMint": output_mint, "amount": str(amount),
                    "slippageBps": str(slippage_bps)},
            headers={"x-api-key": self._key},
        )
        r.raise_for_status()
        body = r.json()
        if body.get("errorCode"):
            raise RuntimeError(f"Jupiter {body.get('errorCode')}: {body.get('errorMessage')}")
        return Fresh(body, _now(), "jupiter")


class RugCheck:
    BASE = "https://api.rugcheck.xyz/v1"

    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client
        self._limiter = RateLimiter(1, 1.0)

    async def summary(self, mint: str) -> Fresh[dict]:
        await self._limiter.acquire()
        r = await self._client.get(f"{self.BASE}/tokens/{mint}/report/summary")
        r.raise_for_status()
        return Fresh(r.json(), _now(), "rugcheck")

    async def report(self, mint: str) -> Fresh[dict]:
        await self._limiter.acquire()
        r = await self._client.get(f"{self.BASE}/tokens/{mint}/report")
        r.raise_for_status()
        return Fresh(r.json(), _now(), "rugcheck")
