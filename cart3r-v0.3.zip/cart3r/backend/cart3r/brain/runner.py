"""Processus `brain` : Shadow Trading + décisions d'entrée → `trade.intent`.

NON TESTÉ EN RÉSEAU : la logique qu'il assemble (signaux, sécurité, décision,
shadow) est couverte par les tests unitaires ; ce fichier n'est que du câblage.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import datetime, timezone

import httpx

from cart3r.core.config import Secrets
from cart3r.core.events import Event
from cart3r.core.runtime import alert, create_pool, load_settings
from cart3r.db.event_store import PostgresEventBus
from cart3r.solana.tx_parse import SwapEvent
from cart3r.sources.clients import DexScreener, Jupiter, PriceFeed, RugCheck, SolanaRpc

from .decision import decide
from .fees import CostInputs
from .security import evaluate as evaluate_security
from .security_service import collect
from .shadow_recorder import QuoteResult, ShadowRecorder
from .shadow_store import save_shadow
from .strategies import MarketSnapshot, MomentumParams, SmartMoneyParams, momentum_signal, smart_money_signal

log = logging.getLogger(__name__)
WSOL = "So11111111111111111111111111111111111111112"
LAMPORTS = 1_000_000_000
SECURITY_CACHE_S = 120
PLATFORM_FEE_PCT = 1.25  # hypothèse prudente : bonding curve / premier palier PumpSwap


def impact_pct(quote: dict) -> float:
    """Impact de prix en %. Jupiter V2 renvoie `priceImpact` (unité à confirmer au premier lancement :
    fraction ou pourcentage). Par prudence, une valeur < 1 est lue comme une fraction."""
    raw = quote.get("priceImpact", quote.get("priceImpactPct")) or 0
    v = abs(float(raw))
    return v * 100 if v < 1 else v


class Brain:
    def __init__(self, pool, bus, rpc, jup, dex, rug, prices) -> None:
        self.pool, self.bus, self.rpc, self.jup, self.dex, self.rug, self.prices = pool, bus, rpc, jup, dex, rug, prices
        self.graduated_at: dict[str, datetime] = {}
        self._sec_cache: dict[str, tuple[float, object]] = {}
        self._intent_sent: dict[str, float] = {}
        self.settings = None
        self.settings_version = 0

    async def reload_settings(self, _: Event | None = None) -> None:
        self.settings, self.settings_version = await load_settings(self.pool)

    # ---------- utilitaires ----------

    async def _quote(self, inp: str, out: str, amount: int) -> QuoteResult:
        q = (await self.jup.quote(inp, out, amount, slippage_bps=300)).value
        fees = sum(int(q.get(k) or 0) for k in ("signatureFeeLamports", "prioritizationFeeLamports"))
        return QuoteResult(out_amount=int(q["outAmount"]), fee_lamports=fees)

    async def _position_lamports(self, sol_eur: float) -> int:
        """Taille indicative utilisée pour les contrôles (la taille finale est fixée par guard)."""
        return int(float(self.settings.positions.max_buy_eur) / sol_eur * LAMPORTS)

    async def _security(self, mint: str, pair: str | None, liquidity: float | None, lamports: int, sol_usd: float):
        hit = self._sec_cache.get(mint)
        if hit and time.monotonic() - hit[0] < SECURITY_CACHE_S:
            return hit[1]
        inp = await collect(mint=mint, rpc=self.rpc, jupiter=self.jup, rugcheck=self.rug, pair_address=pair,
                            liquidity_usd=liquidity, position_lamports=lamports, sol_usd=sol_usd)
        verdict = evaluate_security(inp)
        self._sec_cache[mint] = (time.monotonic(), verdict)
        await self.pool.execute(
            "INSERT INTO security_checks (mint, checked_at, excluded, score, findings, sources) "
            "VALUES ($1, now(), $2, $3, $4::jsonb, $5::jsonb)",
            mint, verdict.excluded, verdict.score,
            json.dumps([f.__dict__ | {"severity": f.severity.value} for f in verdict.findings]),
            json.dumps(["rpc", "jupiter", "rugcheck"]),
        )
        return verdict

    async def _strategy_returns(self, strategy: str) -> list[float]:
        rows = await self.pool.fetch(
            "SELECT realized_lamports, cost_lamports FROM positions WHERE strategy = $1 AND state = 'closed' "
            "AND mode = $2 ORDER BY closed_at DESC LIMIT 200", strategy, self.settings.mode.value)
        return [100.0 * (r["realized_lamports"] - r["cost_lamports"]) / r["cost_lamports"] for r in rows if r["cost_lamports"]]

    async def _has_position(self, mint: str) -> bool:
        return bool(await self.pool.fetchval(
            "SELECT 1 FROM positions WHERE mint = $1 AND state NOT IN ('closed') LIMIT 1", mint))

    async def _evaluate(self, *, mint: str, signal, snapshot_liquidity: float | None, pair: str | None,
                        wallet: str | None = None) -> None:
        if await self._has_position(mint) or time.monotonic() - self._intent_sent.get(mint, 0) < 600:
            return
        sol_eur, sol_usd = (await self.prices.sol()).value
        lamports = await self._position_lamports(sol_eur)
        verdict = await self._security(mint, pair, snapshot_liquidity, lamports, sol_usd)
        try:
            q = (await self.jup.quote(WSOL, mint, lamports, 300)).value
            impact = impact_pct(q)
            net_fee_sol = sum(int(q.get(k) or 0) for k in ("signatureFeeLamports", "prioritizationFeeLamports")) / LAMPORTS
        except Exception as exc:  # noqa: BLE001
            log.info("quote impossible pour %s : %s", mint, exc)
            return
        costs = CostInputs(
            position_usd=lamports / LAMPORTS * sol_usd, platform_fee_buy_pct=PLATFORM_FEE_PCT,
            platform_fee_sell_pct=PLATFORM_FEE_PCT, aggregator_fee_pct=0.1, network_fee_sol_per_tx=net_fee_sol,
            tip_sol_per_tx=0.0, sol_usd=sol_usd, slippage_buy_pct=impact + 0.5, slippage_sell_pct=impact + 0.5,
        )
        result = decide(mint=mint, security=verdict, signal=signal, social_score=None, settings=self.settings,
                        costs=costs, strategy_returns=await self._strategy_returns(signal.strategy),
                        liquidity_usd=snapshot_liquidity or 0.0, wallet=wallet)
        corr = result.intent.correlation_id if result.intent else None
        await self.pool.execute(
            "INSERT INTO decisions (correlation_id, mint, decided_at, strategy, scores, expected_net_pct, accepted, "
            "reasons, settings_version) VALUES ($1, $2, now(), $3, $4::jsonb, $5, $6, $7::jsonb, $8)",
            corr or "-", mint, signal.strategy,
            json.dumps({"opportunity": result.opportunity_score, "security": verdict.score,
                        "momentum": signal.momentum_score, "liquidity": signal.liquidity_score,
                        "smart_money": signal.smart_money_score}),
            result.expected_net_pct, result.accepted, json.dumps(list(result.reasons)), self.settings_version,
        )
        if result.accepted:
            self._intent_sent[mint] = time.monotonic()
            i = result.intent
            await self.bus.publish(Event(
                type="trade.intent", source="brain", observed_at=datetime.now(timezone.utc),
                correlation_id=i.correlation_id, idempotency_key=f"intent:{i.correlation_id}",
                payload={"side": "buy", **i.__dict__},
            ))
            await alert(self.bus, "info", "opportunity",
                        f"Opportunité {mint[:6]}… ({i.strategy}) score {i.opportunity_score}, sécurité {i.security_score}"
                        + (" — exploration paper" if i.exploration else f", E_net {i.expected_net_pct:.1f} %"))

    # ---------- abonnements ----------

    async def on_graduated(self, ev: Event) -> None:
        mint = ev.payload["mint"]
        self.graduated_at[mint] = ev.observed_at
        await self.pool.execute(
            "INSERT INTO tokens (mint, created_at, status, graduated_at, extensions) VALUES ($1, $2, 'graduated', $2, '[]') "
            "ON CONFLICT (mint) DO UPDATE SET status = 'graduated', graduated_at = EXCLUDED.graduated_at",
            mint, ev.observed_at)

    async def on_tick(self, ev: Event) -> None:
        if self.settings is None or "momentum_post_graduation" not in {s.value for s in self.settings.strategies}:
            return
        p = ev.payload
        if not p.get("mint"):
            return
        snap = MarketSnapshot.from_dexscreener(p["raw"], ev.observed_at) if "raw" in p else None
        if snap is None:
            return
        await self.pool.execute(
            "INSERT INTO token_snapshots (mint, observed_at, source, price_usd, market_cap_usd, liquidity_usd, "
            "volume_5m, volume_1h, buyers_5m, sellers_5m) SELECT $1::varchar,$2,'dexscreener',$3,$4,$5,$6,$7,$8,$9 "
            "WHERE EXISTS (SELECT 1 FROM tokens WHERE mint = $1::varchar)",
            snap.mint, snap.observed_at, snap.price_usd, snap.market_cap_usd, snap.liquidity_usd,
            snap.volume_5m_usd, snap.volume_1h_usd, snap.buys_5m, snap.sells_5m)
        sig = momentum_signal(snap, self.graduated_at.get(snap.mint), MomentumParams())
        if sig.ok:
            await self._evaluate(mint=snap.mint, signal=sig, snapshot_liquidity=snap.liquidity_usd, pair=snap.pair_address)

    async def on_wallet_trade(self, ev: Event, recorder: ShadowRecorder) -> None:
        p = ev.payload
        await self.pool.execute(
            "INSERT INTO wallet_trades (signature, wallet, mint, side, token_amount, sol_lamports, fee_lamports, slot, "
            "block_time, detected_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9, now()) ON CONFLICT DO NOTHING",
            p["signature"], p["wallet"], p["mint"], p["side"], int(p["token_amount"]), int(p["sol_lamports"]),
            int(p["fee_lamports"]), int(p["slot"]), ev.observed_at)
        swap = SwapEvent(p["signature"], p["wallet"], p["mint"], p["side"], int(p["token_amount"]),
                         int(p["sol_lamports"]), int(p["fee_lamports"]), int(p["slot"]), ev.observed_at)
        before = len(recorder.closed)
        await recorder.on_swap(swap)
        for t in recorder.closed[before:]:
            await save_shadow(self.pool, t)

        if p["side"] != "buy" or "smart_money_swing" not in {s.value for s in self.settings.strategies}:
            return
        status = await self.pool.fetchval("SELECT shadow_status FROM wallets WHERE address = $1", p["wallet"])
        if status != "copyable":
            return
        try:
            sol_eur, _ = (await self.prices.sol()).value
            lamports = await self._position_lamports(sol_eur)
            ours = await self._quote(WSOL, p["mint"], lamports)
            pairs = (await self.dex.tokens([p["mint"]])).value
        except Exception as exc:  # noqa: BLE001
            log.info("copie impossible à évaluer : %s", exc)
            return
        buyers = await self.pool.fetchval(
            "SELECT count(DISTINCT coalesce(w.cluster_id, w.address)) FROM wallet_trades t JOIN wallets w ON w.address = t.wallet "
            "WHERE t.mint = $1 AND t.side = 'buy' AND w.shadow_status = 'copyable' AND t.block_time > now() - interval '30 minutes'",
            p["mint"])
        sig = smart_money_signal(
            wallet_status=status, wallet_price_sol_per_token=int(p["sol_lamports"]) / int(p["token_amount"]),
            our_price_sol_per_token=lamports / max(ours.out_amount, 1),
            seconds_after_wallet=(datetime.now(timezone.utc) - ev.observed_at).total_seconds(),
            independent_buyers=int(buyers or 1), p=SmartMoneyParams())
        pair = pairs[0] if pairs else {}
        liq = (pair.get("liquidity") or {}).get("usd")
        await self._evaluate(mint=p["mint"], signal=sig, snapshot_liquidity=float(liq) if liq else None,
                             pair=pair.get("pairAddress"), wallet=p["wallet"])


async def run_brain(secrets: Secrets) -> None:
    pool = await create_pool(secrets)
    bus = PostgresEventBus(pool, consumer="brain")
    key = secrets.helius_api_key.get_secret_value() if secrets.helius_api_key else ""
    async with httpx.AsyncClient(timeout=10) as http:
        brain = Brain(
            pool, bus, SolanaRpc(f"https://mainnet.helius-rpc.com/?api-key={key}", "helius", http),
            Jupiter(http, secrets.jupiter_api_key.get_secret_value() if secrets.jupiter_api_key else ""),
            DexScreener(http), RugCheck(http), PriceFeed(http),
        )
        await brain.reload_settings()

        async def accept(swap: SwapEvent) -> tuple[bool, str | None]:
            # Vue « CART3R » du shadow : mêmes filtres de sécurité que pour un vrai achat.
            try:
                sol_eur, sol_usd = (await brain.prices.sol()).value
                v = await brain._security(swap.mint, None, None, await brain._position_lamports(sol_eur), sol_usd)
            except Exception as exc:  # noqa: BLE001
                return False, f"filtres non évaluables : {exc}"
            return (not v.excluded), (None if not v.excluded else "; ".join(v.reasons[:3]))

        recorder = ShadowRecorder(brain._quote, accept, position_lamports=80_000_000)
        bus.subscribe("token.graduated", brain.on_graduated)
        bus.subscribe("market.tick", brain.on_tick)
        bus.subscribe("wallet.trade", lambda ev: brain.on_wallet_trade(ev, recorder))
        bus.subscribe("settings.changed", brain.reload_settings)
        await asyncio.gather(bus.run())
