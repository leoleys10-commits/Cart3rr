# CART3R Memecoin AI — v0.3 (mode Paper)

Bot de trading de memecoins Solana, conçu pour un capital de 100 €. **Installation : voir `INSTALL.md`.**

## Ce que fait cette version

- Détecte les tokens Pump.fun qui « graduent » vers PumpSwap et les suit sur DexScreener.
- Filtre anti-rug : autorités mint/freeze, extensions Token-2022 (dont Permanent Delegate), concentration
  des holders, vendabilité testée par un aller-retour Jupiter, rapport RugCheck.
- Stratégies : momentum post-graduation et copie de wallets « copiables » (smart money swing).
- Opportunity Score, Fee Optimizer (coût aller-retour, espérance nette), journal de chaque décision.
- Capital Protection : taille de position par le risque, 2 positions max, pertes jour/semaine, drawdown 15 %,
  PANIC STOP. Le bot ne peut pas relever ses propres limites.
- Exécution **simulée** sur des quotes Jupiter réelles (latence + glissement + frais + rente comptés).
- Sorties : stop, prises de profit partielles, trailing stop, durée max, urgences (liquidité, sécurité,
  vente du wallet copié).
- Shadow Trading : 3 carnets (wallet réel, copie brute, CART3R) et statuts des wallets.
- Dashboard 9 pages (tunnel SSH + mot de passe) et bot Telegram (alertes + commandes, TOTP pour les actions sensibles).

## Architecture

Cinq processus Docker (`ingest`, `brain`, `guard`, `exec`, `api`) + PostgreSQL, reliés par un bus
d'événements durable (table `events` + LISTEN/NOTIFY). Voir le document d'architecture (phase 2).

## Statut des tests

- 106 tests unitaires passent (`cd backend && pip install -e .[dev] && pytest`) : réglages, événements,
  masquage des secrets, lecture des mints, sécurité, frais, décision, stratégies, garde-fou du capital,
  sorties, broker paper, shadow, parsing des transactions, TOTP.
- **Non testé** : tout ce qui parle au réseau ou à PostgreSQL (clients API, services, processus, dashboard
  connecté). Ces parties n'ont pas pu être exécutées dans l'environnement de développement. Le premier
  lancement sur le serveur servira de test d'intégration ; des corrections sont probables.

## Pas encore fait

- Exécution réelle (signature des transactions, keystore chiffré) : verrouillée jusqu'aux critères go/no-go.
- Analyse maison des bundles, du wash trading et du graphe de financement (V1 : pénalités ou RugCheck).
- Stratégie breakout, analyse sociale (Telegram), backtest walk-forward et Monte Carlo, ML.
- Migrations Alembic (V1 : création directe du schéma).
