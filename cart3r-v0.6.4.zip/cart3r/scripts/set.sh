#!/usr/bin/env bash
# CART3R - remplacer UNE valeur de la configuration sans toucher aux autres.
# Usage : bash scripts/set.sh telegram | helius | jupiter | dashboard
# (Ne relance pas configure.sh sur une installation qui tourne : il changerait le mot de passe de la base.)
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] || { echo "Pas de fichier .env : lance d'abord bash scripts/configure.sh"; exit 1; }

case "${1:-}" in
  telegram)  KEY=CART3R_TELEGRAM_BOT_TOKEN; Q="Nouveau token du bot Telegram" ;;
  helius)    KEY=CART3R_HELIUS_API_KEY;     Q="Nouvelle clé API Helius" ;;
  jupiter)   KEY=CART3R_JUPITER_API_KEY;    Q="Nouvelle clé API Jupiter" ;;
  dashboard) KEY=CART3R_DASHBOARD_PASSWORD; Q="Nouveau mot de passe du dashboard" ;;
  *) echo "Usage : bash scripts/set.sh telegram | helius | jupiter | dashboard"; exit 1 ;;
esac

read -r -p "$Q : " VALUE
VALUE="$(printf '%s' "$VALUE" | tr -d '[:space:]')"
[ -n "$VALUE" ] || { echo "Valeur vide : rien n'a été modifié."; exit 1; }

TMP="$(mktemp)"
grep -v "^${KEY}=" .env > "$TMP" || true
printf '%s=%s\n' "$KEY" "$VALUE" >> "$TMP"
cat "$TMP" > .env && rm -f "$TMP"
chmod 600 .env
docker compose up -d >/dev/null
echo "Valeur mise à jour et bot redémarré."
