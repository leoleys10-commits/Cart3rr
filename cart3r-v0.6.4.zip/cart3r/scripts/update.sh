#!/usr/bin/env bash
# CART3R - installer une nouvelle version déposée sur GitHub. Ta configuration (.env) et tes données sont conservées.
# Usage : bash scripts/update.sh 0.5      (le zip doit s'appeler cart3r-v0.5.zip dans ton dépôt GitHub)
set -euo pipefail
REPO="${CART3R_REPO:-leoleys10-commits/Cart3rr}"
V="${1:?Indique la version, ex. : bash scripts/update.sh 0.5}"
cd ~
wget -q --show-progress -O "cart3r-v${V}.zip" "https://github.com/${REPO}/raw/main/cart3r-v${V}.zip"
unzip -oq "cart3r-v${V}.zip"
cd cart3r
docker compose up -d --build
echo "Version ${V} installée."
