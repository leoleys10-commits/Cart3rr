#!/usr/bin/env bash
# CART3R - résumé de l'état et des erreurs, à copier-coller dans la conversation avec Claude.
# Les clés API et le token Telegram sont masqués.
cd "$(dirname "$0")/.."
docker compose ps --format "table {{.Service}}\t{{.Status}}"
for s in ingest brain guard exec api; do
  echo
  echo "===== $s ====="
  docker compose logs --no-color --tail 20 "$s" 2>&1 \
    | sed -E 's/[0-9]{6,12}:[A-Za-z0-9_-]{30,}/[MASQUÉ]/g; s/(api-key=)[^& "]+/\1[MASQUÉ]/g' \
    | cut -c1-220
done
