"""Stratégies d'entrée et Opportunity Score (MVP paper trading).

Deux stratégies actives au lancement :
- `momentum_post_graduation` : token gradué depuis peu, acheteurs qui
  dominent, liquidité suffisante, hausse déjà amorcée mais pas parabolique ;
- `smart_money_swing` : un wallet au statut « copiable » achète, et notre prix
  reste proche du sien.

Tous les seuils sont des HYPOTHÈSES de départ, réglables, que le paper trading
sert justement à mesurer.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class MomentumParams(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)
    min_minutes_since_graduation: float = Field(5, ge=0)
    max_minutes_since_graduation: float = Field(180, ge=1)
    min_liquidity_usd: float = Field(15_000, ge=1_000)
    min_market_cap_usd: float = Field(60_000, ge=0)
    max_market_cap_usd: float = Field(3_000_000, ge=10_000)
    min_buy_sell_ratio_5m: float = Field(1.3, ge=1.0)
    min_txns_5m: int = Field(40, ge=1)
    min_volume_5m_usd: float = Field(5_000, ge=0)
    min_price_change_5m_pct: float = 3.0
    max_price_change_5m_pct: float = 40.0  # au-delà : achat trop tardif
    max_price_change_1h_pct: float = 250.0


class SmartMoneyParams(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)
    max_price_gap_pct: float = Field(15, ge=0, le=100)  # notre prix vs celui du wallet
    max_seconds_after_wallet: float = Field(120, ge=1)


@dataclass(frozen=True)
class MarketSnapshot:
    mint: str
    observed_at: datetime
    price_usd: float | None
    liquidity_usd: float | None
    market_cap_usd: float | None
    volume_5m_usd: float | None
    volume_1h_usd: float | None
    buys_5m: int | None
    sells_5m: int | None
    price_change_5m_pct: float | None
    price_change_1h_pct: float | None
    pair_address: str | None = None
    dex: str | None = None

    @classmethod
    def from_dexscreener(cls, pair: dict, observed_at: datetime) -> "MarketSnapshot":
        def f(x):
            try:
                return float(x) if x is not None else None
            except (TypeError, ValueError):
                return None

        txns = (pair.get("txns") or {}).get("m5") or {}
        vol = pair.get("volume") or {}
        chg = pair.get("priceChange") or {}
        return cls(
            mint=(pair.get("baseToken") or {}).get("address", ""),
            observed_at=observed_at,
            price_usd=f(pair.get("priceUsd")),
            liquidity_usd=f((pair.get("liquidity") or {}).get("usd")),
            market_cap_usd=f(pair.get("marketCap") or pair.get("fdv")),
            volume_5m_usd=f(vol.get("m5")),
            volume_1h_usd=f(vol.get("h1")),
            buys_5m=txns.get("buys"),
            sells_5m=txns.get("sells"),
            price_change_5m_pct=f(chg.get("m5")),
            price_change_1h_pct=f(chg.get("h1")),
            pair_address=pair.get("pairAddress"),
            dex=pair.get("dexId"),
        )


@dataclass(frozen=True)
class Signal:
    ok: bool
    strategy: str
    reasons: tuple[str, ...]
    momentum_score: float = 0.0  # 0 à 1
    liquidity_score: float = 0.0  # 0 à 1
    smart_money_score: float = 0.0  # 0 à 1
    extra: dict = field(default_factory=dict)


def _clip(x: float) -> float:
    return max(0.0, min(1.0, x))


def momentum_signal(s: MarketSnapshot, graduated_at: datetime | None, p: MomentumParams) -> Signal:
    r: list[str] = []
    missing = [n for n in ("liquidity_usd", "market_cap_usd", "volume_5m_usd", "buys_5m", "sells_5m",
                           "price_change_5m_pct", "price_change_1h_pct") if getattr(s, n) is None]
    if missing:
        return Signal(False, "momentum_post_graduation", (f"données manquantes : {', '.join(missing)}",))
    if graduated_at is None:
        r.append("date de graduation inconnue")
    else:
        minutes = (s.observed_at - graduated_at).total_seconds() / 60
        if not p.min_minutes_since_graduation <= minutes <= p.max_minutes_since_graduation:
            r.append(f"gradué il y a {minutes:.0f} min (fenêtre {p.min_minutes_since_graduation:.0f}-"
                     f"{p.max_minutes_since_graduation:.0f})")
    if s.liquidity_usd < p.min_liquidity_usd:
        r.append(f"liquidité {s.liquidity_usd:,.0f} $ < {p.min_liquidity_usd:,.0f} $")
    if not p.min_market_cap_usd <= s.market_cap_usd <= p.max_market_cap_usd:
        r.append(f"market cap {s.market_cap_usd:,.0f} $ hors fenêtre")
    txns = s.buys_5m + s.sells_5m
    ratio = s.buys_5m / max(s.sells_5m, 1)
    if txns < p.min_txns_5m:
        r.append(f"{txns} transactions sur 5 min < {p.min_txns_5m}")
    if ratio < p.min_buy_sell_ratio_5m:
        r.append(f"ratio achats/ventes {ratio:.2f} < {p.min_buy_sell_ratio_5m}")
    if s.volume_5m_usd < p.min_volume_5m_usd:
        r.append(f"volume 5 min {s.volume_5m_usd:,.0f} $ trop faible")
    if s.price_change_5m_pct < p.min_price_change_5m_pct:
        r.append(f"variation 5 min {s.price_change_5m_pct:+.1f} % : pas d'élan")
    if s.price_change_5m_pct > p.max_price_change_5m_pct:
        r.append(f"variation 5 min {s.price_change_5m_pct:+.1f} % : trop tard")
    if s.price_change_1h_pct > p.max_price_change_1h_pct:
        r.append(f"variation 1 h {s.price_change_1h_pct:+.1f} % : trop tard")

    momentum = _clip((ratio - 1.0) / 1.5) * 0.5 + _clip(s.price_change_5m_pct / 20) * 0.5
    liquidity = _clip(s.liquidity_usd / 100_000) * 0.6 + _clip(s.volume_5m_usd / max(s.liquidity_usd, 1.0) * 5) * 0.4
    return Signal(not r, "momentum_post_graduation", tuple(r), momentum, liquidity)


def smart_money_signal(
    *, wallet_status: str, wallet_price_sol_per_token: float, our_price_sol_per_token: float,
    seconds_after_wallet: float, independent_buyers: int, p: SmartMoneyParams,
) -> Signal:
    r: list[str] = []
    if wallet_status != "copyable":
        r.append(f"wallet au statut « {wallet_status} » (copie réservée aux wallets copiables)")
    gap = 100.0 * (our_price_sol_per_token / wallet_price_sol_per_token - 1.0) if wallet_price_sol_per_token > 0 else 1e9
    if gap > p.max_price_gap_pct:
        r.append(f"notre prix est {gap:.1f} % au-dessus de celui du wallet")
    if seconds_after_wallet > p.max_seconds_after_wallet:
        r.append(f"{seconds_after_wallet:.0f} s après le wallet : trop tard")
    sm = _clip(independent_buyers / 3)
    return Signal(not r, "smart_money_swing", tuple(r), smart_money_score=sm, extra={"price_gap_pct": gap})


# Pondérations initiales (phase 1, section 8) ramenées aux composantes mesurées en V1.
WEIGHTS = {"security": 20, "smart_money": 20, "momentum": 25, "liquidity": 20, "social": 15}


def opportunity_score(security_score: int, sig: Signal, social_score: float | None) -> int:
    """Score /100. Une composante inconnue (social en V1) voit son poids redistribué."""
    parts = {
        "security": security_score / 100,
        "smart_money": sig.smart_money_score,
        "momentum": sig.momentum_score,
        "liquidity": sig.liquidity_score,
        "social": social_score,
    }
    # Le smart money ne compte que pour la stratégie qui l'utilise ; le momentum inversement.
    if sig.strategy == "momentum_post_graduation":
        parts["smart_money"] = None
    if sig.strategy == "smart_money_swing":
        parts["momentum"] = None
        parts["liquidity"] = parts["liquidity"] or None
    known = {k: v for k, v in parts.items() if v is not None}
    total_w = sum(WEIGHTS[k] for k in known)
    return round(100 * sum(WEIGHTS[k] * v for k, v in known.items()) / total_w) if total_w else 0
