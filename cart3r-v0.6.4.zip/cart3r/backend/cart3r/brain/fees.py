"""Fee Optimizer : coût aller-retour et espérance nette d'un trade.

E_net = p_win·G - (1 - p_win)·P - C_aller-retour - p_rug·L_rug   (en % de la position)

Toutes les entrées viennent de mesures (quotes, frais réseau récents) ou de
statistiques de la stratégie ; rien n'est inventé. Les montants sont en USD
pour rester dans l'unité des quotes ; la conversion EUR se fait en amont.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CostInputs:
    position_usd: float
    platform_fee_buy_pct: float  # ex. 1.25 sur la bonding curve Pump.fun
    platform_fee_sell_pct: float
    aggregator_fee_pct: float  # par côté, ex. 0.05 à 0.10 pour Jupiter
    network_fee_sol_per_tx: float  # base + priorité, estimé sur les frais récents
    tip_sol_per_tx: float
    sol_usd: float
    slippage_buy_pct: float  # impact + glissement estimé
    slippage_sell_pct: float
    txs_per_round_trip: int = 3  # achat, vente, fermeture du compte token


@dataclass(frozen=True)
class CostBreakdown:
    platform_pct: float
    aggregator_pct: float
    network_pct: float
    tip_pct: float
    slippage_pct: float

    @property
    def total_pct(self) -> float:
        return self.platform_pct + self.aggregator_pct + self.network_pct + self.tip_pct + self.slippage_pct


def round_trip_cost(c: CostInputs) -> CostBreakdown:
    if c.position_usd <= 0 or c.sol_usd <= 0:
        raise ValueError("position et cours du SOL doivent être positifs")
    to_pct = 100.0 / c.position_usd
    # Les pourcentages côté vente s'appliquent à la valeur de sortie ; on
    # reste conservateur en les appliquant à la valeur d'entrée.
    network = c.network_fee_sol_per_tx * c.txs_per_round_trip * c.sol_usd * to_pct
    tip = c.tip_sol_per_tx * 2 * c.sol_usd * to_pct  # pas de tip sur la fermeture du compte
    return CostBreakdown(
        platform_pct=c.platform_fee_buy_pct + c.platform_fee_sell_pct,
        aggregator_pct=2 * c.aggregator_fee_pct,
        network_pct=network,
        tip_pct=tip,
        slippage_pct=c.slippage_buy_pct + c.slippage_sell_pct,
    )


@dataclass(frozen=True)
class OutcomeModel:
    """Statistiques de la stratégie (issues du backtest / shadow), en %."""

    p_win: float
    avg_gain_pct: float
    avg_loss_pct: float  # valeur positive, inclut le glissement du stop
    p_rug: float
    rug_loss_pct: float = 90.0

    def __post_init__(self) -> None:
        for name in ("p_win", "p_rug"):
            v = getattr(self, name)
            if not 0.0 <= v <= 1.0:
                raise ValueError(f"{name} doit être entre 0 et 1")
        if self.p_win + self.p_rug > 1.0:
            raise ValueError("p_win + p_rug > 1")


def expected_net_pct(model: OutcomeModel, cost: CostBreakdown) -> float:
    p_loss = 1.0 - model.p_win - model.p_rug
    gross = model.p_win * model.avg_gain_pct - p_loss * model.avg_loss_pct - model.p_rug * model.rug_loss_pct
    return gross - cost.total_pct


@dataclass(frozen=True)
class FeeDecision:
    accepted: bool
    expected_net_pct: float
    cost: CostBreakdown
    reasons: tuple[str, ...]


def decide(
    model: OutcomeModel,
    costs: CostInputs,
    *,
    min_expected_net_pct: float,
    max_round_trip_cost_pct: float,
    max_tip_pct_of_position: float,
) -> FeeDecision:
    cost = round_trip_cost(costs)
    e_net = expected_net_pct(model, cost)
    reasons: list[str] = []
    if cost.total_pct > max_round_trip_cost_pct:
        reasons.append(f"coût aller-retour {cost.total_pct:.2f} % > {max_round_trip_cost_pct} %")
    if cost.tip_pct > max_tip_pct_of_position:
        reasons.append(f"tip {cost.tip_pct:.2f} % > {max_tip_pct_of_position} %")
    if e_net < min_expected_net_pct:
        reasons.append(f"espérance nette {e_net:.2f} % < {min_expected_net_pct} %")
    return FeeDecision(accepted=not reasons, expected_net_pct=e_net, cost=cost, reasons=tuple(reasons))


def impact_pct(quote: dict) -> float:
    """Impact de prix en %.

    Jupiter Swap V2 : `priceImpactPct` (chaîne, déprécié) est documenté comme un
    RATIO de 0 à 1 → ×100. `priceImpact` (nombre) est déjà en pourcentage.
    L'ancienne lecture « < 1 = fraction » multipliait par 100 un impact déjà en %,
    ce qui gonflait le coût aller-retour (jusqu'à 113 % observé).
    """
    ratio = quote.get("priceImpactPct")
    if ratio not in (None, ""):
        return abs(float(ratio)) * 100
    pct = quote.get("priceImpact")
    if pct not in (None, ""):
        return abs(float(pct))
    raise ValueError("impact de prix absent de la quote Jupiter")  # donnée manquante ≠ impact nul
