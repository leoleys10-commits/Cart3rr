"""Détection des graduations Pump.fun → PumpSwap via GeckoTerminal (gratuit)."""
from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from cart3r.core.events import Event, EventBus
from cart3r.sources.gecko_parse import parse_new_pools

if TYPE_CHECKING:
    from cart3r.sources.clients import GeckoTerminal

log = logging.getLogger(__name__)


class GraduationPoller:
    """Détection des graduations sans WebSocket (aucun crédit Helius)."""

    def __init__(self, gecko: GeckoTerminal, bus: EventBus, poll_s: float = 60.0, max_pages: int = 3, page_gap_s: float = 4.0) -> None:
        self._gecko, self._bus, self._poll_s, self._max_pages = gecko, bus, poll_s, max_pages
        self._page_gap_s = page_gap_s
        self._seen: dict[str, None] = {}  # pools déjà vus, ordre d'insertion conservé
        self.graduated_count = 0

    def _remember(self, pool: str) -> None:
        self._seen[pool] = None
        while len(self._seen) > 5000:
            self._seen.pop(next(iter(self._seen)))

    async def poll_once(self) -> int:
        published = 0
        for page in range(1, self._max_pages + 1):
            if page > 1:
                await asyncio.sleep(self._page_gap_s)  # évite le 429 de GeckoTerminal
            try:
                fresh = await self._gecko.new_pools(page)
            except Exception as exc:  # noqa: BLE001
                log.info("GeckoTerminal new_pools page %d indisponible (%s) : nouvel essai au prochain passage", page, str(exc)[:60])
                break
            items = fresh.value.get("data") or []
            pools = parse_new_pools(fresh.value)
            known = sum(1 for p in pools if p.pool in self._seen)
            for p in pools:
                if p.pool in self._seen:
                    continue
                self._remember(p.pool)
                payload = {"mint": p.mint, "pool": p.pool, "dex": p.dex}
                if p.created_at:
                    payload["created_at"] = p.created_at.isoformat()
                n = await self._bus.publish(Event(
                    type="token.graduated", source="geckoterminal", observed_at=fresh.observed_at,
                    payload=payload, idempotency_key=f"graduated:{p.mint}",
                ))
                published += n
            # Page incomplète, ou on retombe sur des pools déjà vus : inutile d'aller plus loin.
            if len(items) < 20 or (pools and known == len(pools)):
                break
        self.graduated_count += published
        return published

    async def run(self) -> None:
        while True:
            n = await self.poll_once()
            if n:
                log.info("%d graduation(s) PumpSwap détectée(s)", n)
            await asyncio.sleep(self._poll_s)
