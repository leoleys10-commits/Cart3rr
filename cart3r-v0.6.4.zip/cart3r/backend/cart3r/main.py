"""Point d'entrée : `python -m cart3r.main ingest|brain|guard|exec|api|totp`.

Mode Paper uniquement dans cette version : aucune clé privée n'est chargée,
aucune transaction réelle n'est signée.
"""
from __future__ import annotations

import asyncio
import os
import sys
from datetime import timedelta

import httpx

from cart3r.core.config import Secrets
from cart3r.core.events import Event
from cart3r.core.logging import setup_logging
from cart3r.core.runtime import create_pool
from cart3r.db.event_store import PostgresEventBus
from cart3r.ingest.services import GraduationPoller, MarketScanner, SmartMoneyTracker, TokenDetector
from cart3r.sources.base import FallbackSource, Provider
from cart3r.sources.clients import DexScreener, GeckoTerminal, SolanaRpc


async def _active_wallets(pool) -> list[str]:
    rows = await pool.fetch("SELECT address FROM wallets WHERE active ORDER BY added_at LIMIT 50")
    return [r["address"] for r in rows]


async def run_ingest(secrets: Secrets) -> None:
    pool = await create_pool(secrets)
    bus = PostgresEventBus(pool, consumer="ingest")
    key = secrets.helius_api_key.get_secret_value() if secrets.helius_api_key else ""
    async with httpx.AsyncClient(timeout=10) as http:
        main_rpc = SolanaRpc(f"https://mainnet.helius-rpc.com/?api-key={key}", "helius", http)
        rpcs = [main_rpc]
        if secrets.helius_backup_rpc_url:
            rpcs.append(SolanaRpc(secrets.helius_backup_rpc_url.get_secret_value(), "backup", http))
        tx_source = FallbackSource(
            [Provider(r.name, r.transaction, timeout_s=5) for r in rpcs], max_age=timedelta(seconds=30)
        )
        # Par défaut : détection gratuite via GeckoTerminal. Le WebSocket Helius
        # (facturé au volume de données) ne s'active qu'avec CART3R_HELIUS_WS=1.
        detectors = [GraduationPoller(GeckoTerminal(http), bus).run()]
        if os.environ.get("CART3R_HELIUS_WS") == "1":
            detectors.append(TokenDetector(f"wss://mainnet.helius-rpc.com/?api-key={key}", tx_source, bus).run())
        tracker = SmartMoneyTracker(main_rpc, bus, await _active_wallets(pool),
                                    poll_s=float(os.environ.get("CART3R_WALLET_POLL_S", "120")))
        scanner = MarketScanner(DexScreener(http), bus)
        # Reprend le suivi des tokens gradués des 3 dernières heures après un redémarrage.
        for r in await pool.fetch("SELECT mint FROM tokens WHERE graduated_at > now() - interval '3 hours'"):
            scanner.tracked.add(r["mint"])

        async def track(ev: Event) -> None:
            scanner.tracked.add(ev.payload["mint"])

        async def refresh_wallets() -> None:
            while True:
                await asyncio.sleep(60)
                tracker.wallets[:] = await _active_wallets(pool)

        async def expire_tokens() -> None:
            while True:
                await asyncio.sleep(300)
                fresh = {r["mint"] for r in await pool.fetch(
                    "SELECT mint FROM tokens WHERE graduated_at > now() - interval '3 hours'")}
                scanner.tracked.intersection_update(fresh | {r["mint"] for r in await pool.fetch(
                    "SELECT mint FROM positions WHERE state <> 'closed'")})

        bus.subscribe("token.graduated", track)
        await asyncio.gather(*detectors, tracker.run(), scanner.run(), bus.run(), refresh_wallets(), expire_tokens())


def main() -> None:
    setup_logging()
    role = sys.argv[1] if len(sys.argv) > 1 else ""
    if role == "totp":
        from cart3r.core import totp
        secret = totp.new_secret()
        print(f"CART3R_TOTP_SECRET={secret}")
        print(f"Lien à scanner/ajouter dans ton appli d'authentification : {totp.provisioning_uri(secret)}")
        return
    secrets = Secrets.from_env()
    if role == "api":
        from cart3r.api.server import run_api
        return run_api(secrets)
    if role == "brain":
        from cart3r.brain.runner import run_brain as runner
    elif role == "guard":
        from cart3r.guard.runner import run_guard as runner
    elif role == "exec":
        from cart3r.exec.runner import run_exec as runner
    elif role == "ingest":
        runner = run_ingest
    else:
        raise SystemExit("usage : python -m cart3r.main ingest|brain|guard|exec|api|totp")
    asyncio.run(runner(secrets))


if __name__ == "__main__":
    main()
