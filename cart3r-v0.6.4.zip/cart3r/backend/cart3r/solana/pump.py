"""Constantes et détection Pump.fun / PumpSwap.

Les logs d'une transaction Pump.fun contiennent aussi ceux des autres programmes
appelés (ex. « Instruction: CreateIdempotent » du programme de comptes
associés, présent dans presque chaque achat). On ne compare donc que des
lignes EXACTES, sinon chaque achat serait pris pour une création.
"""
from __future__ import annotations

PUMP_FUN_PROGRAM = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"
PUMPSWAP_PROGRAM = "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA"
CREATE_LINES = frozenset({"Program log: Instruction: Create", "Program log: Instruction: CreateV2"})
MIGRATE_LINES = frozenset({"Program log: Instruction: Migrate"})


def classify_logs(logs: list[str]) -> str | None:
    """'created', 'graduated' ou None, d'après les logs d'une transaction Pump.fun."""
    lines = {line.strip() for line in logs}
    if lines & MIGRATE_LINES:
        return "graduated"
    if lines & CREATE_LINES:
        return "created"
    return None
