"""Lecture pure de la réponse GeckoTerminal `/networks/solana/new_pools`.

Les graduations Pump.fun créent un pool sur PumpSwap (dex id « pumpswap »).
La liste contient aussi les pools des courbes Pump.fun (dex id « pump-fun »)
et des autres DEX : on ne garde que PumpSwap avec SOL en jeton de cotation.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

WSOL = "So11111111111111111111111111111111111111112"
GRADUATION_DEXES = frozenset({"pumpswap"})


@dataclass(frozen=True)
class NewPool:
    pool: str
    mint: str
    dex: str
    created_at: datetime | None


def _rel_id(item: dict, name: str) -> str:
    return ((item.get("relationships") or {}).get(name) or {}).get("data", {}).get("id") or ""


def _strip_network(token_id: str) -> str:
    return token_id.split("_", 1)[1] if token_id.startswith("solana_") else ""


def _parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def parse_new_pools(body: dict, dexes: frozenset[str] = GRADUATION_DEXES) -> list[NewPool]:
    out: list[NewPool] = []
    for item in body.get("data") or []:
        dex = _rel_id(item, "dex")
        if dex not in dexes:
            continue
        base = _strip_network(_rel_id(item, "base_token"))
        quote = _strip_network(_rel_id(item, "quote_token"))
        if quote != WSOL and base == WSOL:  # pool inversé : le memecoin est en cotation
            base, quote = quote, base
        if not base or quote != WSOL:
            continue
        attrs = item.get("attributes") or {}
        pool = attrs.get("address") or _strip_network(item.get("id") or "")
        out.append(NewPool(pool=pool, mint=base, dex=dex, created_at=_parse_dt(attrs.get("pool_created_at"))))
    return out
