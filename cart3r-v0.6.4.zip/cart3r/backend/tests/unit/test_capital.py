

def test_min_buy_not_rejected_by_rounding():
    # Cours choisi pour que 5 € ne tombe pas sur un nombre entier de lamports.
    from cart3r.core.config import Settings
    from cart3r.guard.capital import CapitalGuard
    for eur_per_sol in (64.99, 123.456789, 187.3, 99.99):
        g = CapitalGuard.fresh(Settings(), eur_per_sol=eur_per_sol)
        d = g.size(stop_pct=25.0, eur_per_sol=eur_per_sol, liquidity_usd=1_000_000, sol_usd=eur_per_sol * 1.1)
        assert d.approved, (eur_per_sol, d.reasons)
