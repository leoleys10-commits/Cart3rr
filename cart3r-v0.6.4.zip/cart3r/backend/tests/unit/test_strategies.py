

def test_momentum_zero_liquidity_does_not_crash():
    from cart3r.brain.strategies import MarketSnapshot, MomentumParams, momentum_signal
    import inspect
    fields = {n: 0.0 for n in inspect.signature(MarketSnapshot).parameters}
    fields.update(mint="M", pair_address="P", buys_5m=10, sells_5m=2, market_cap_usd=50_000.0,
                  volume_5m_usd=1_000.0, liquidity_usd=0.0)
    from datetime import datetime, timezone
    for k in ("observed_at", "pair_created_at"):
        if k in fields:
            fields[k] = datetime.now(timezone.utc)
    sig = momentum_signal(MarketSnapshot(**fields), datetime.now(timezone.utc), MomentumParams())
    assert not sig.ok and any("liquidité" in r for r in sig.reasons)
