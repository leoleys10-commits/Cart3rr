# CART3R — Installation depuis un iPhone, pas à pas

Durée : environ 1 heure. Coût : environ 4,57 € TTC par mois pour le serveur. Tout le reste est gratuit.
Tout se fait depuis le téléphone. Le bot démarre en **mode Paper** : il trade en simulation avec les vrais prix, sans toucher à ton argent.

Astuce : garde ce guide ouvert et copie-colle chaque commande (appui long → Copier, puis appui long dans Termius → Coller).

## Étape 0 — Préparer le téléphone (5 min)

Installe depuis l'App Store (toutes gratuites) :
- **Termius** : ton terminal pour piloter le serveur ;
- **Google Authenticator** : les codes de sécurité à 6 chiffres ;
- **Telegram** (si tu ne l'as pas déjà).

Télécharge **cart3r-v0.2.zip** depuis la conversation avec Claude : il arrive dans l'app **Fichiers** (dossier Téléchargements).

## Étape 1 — Louer le serveur (10 min, Safari)

1. Va sur https://www.ovhcloud.com/fr/vps/ et choisis **VPS-1** (2 vCores, 4 Go RAM, 40 Go).
2. Système : **Ubuntu 24.04**, sans panneau de gestion.
3. Localisation : **France**. Aucune option payante, sans engagement.
4. Crée ton compte et paie.
5. Tu reçois un e-mail avec l'**adresse IP** (ex. `51.68.12.34`), l'utilisateur (en général `ubuntu`) et le mot de passe.

## Étape 2 — Se connecter avec Termius (5 min)

1. Ouvre Termius → **+** → **New Host**.
2. **Address** : l'adresse IP. **Username** : `ubuntu`. **Password** : celui de l'e-mail. Enregistre.
3. Touche l'hôte pour te connecter, accepte l'empreinte (**Continue**).
4. Si on te demande de changer le mot de passe : ancien, puis deux fois le nouveau. **Note-le**, mets-le à jour dans l'hôte Termius et reconnecte-toi.

Tu es connecté quand tu vois `ubuntu@vps-xxxx:~$`.

## Étape 3 — Préparer le serveur (10 min)

Colle ce bloc d'un coup (le mot de passe peut être demandé une fois) :

```
sudo apt update && sudo apt -y upgrade && sudo apt -y install ufw unattended-upgrades unzip wget && sudo ufw allow OpenSSH && sudo ufw --force enable && curl -fsSL https://get.docker.com | sudo sh && sudo usermod -aG docker ubuntu
```

Quand c'est fini, **ferme la session Termius et reconnecte-toi** (obligatoire pour Docker). Vérifie :

```
docker compose version
```

Un numéro de version doit s'afficher.

## Étape 4 — Mettre le code sur le serveur via GitHub (10 min)

1. Dans Safari : crée un compte sur https://github.com.
2. **+** (en haut) → **New repository** → nom `cart3r` → **Public** → **Create repository**.
3. Sur la page du dépôt : **uploading an existing file** → choisis `cart3r-v0.2.zip` dans Fichiers → **Commit changes**.
   Le zip ne contient aucun secret : tes clés ne seront saisies que sur le serveur.
4. Dans Termius (remplace `TON_PSEUDO` par ton nom d'utilisateur GitHub) :

```
wget -O cart3r-v0.2.zip https://github.com/TON_PSEUDO/cart3r/raw/main/cart3r-v0.2.zip && unzip -o cart3r-v0.2.zip && cd cart3r
```

## Étape 5 — Créer les comptes gratuits (15 min, Safari + Telegram)

Garde chaque valeur dans l'app **Notes** pour la coller ensuite.

- **Helius** : https://dashboard.helius.dev → compte gratuit → copie l'**API key**.
- **Jupiter** : https://portal.jup.ag → connexion par e-mail → crée une **API key** → copie-la.
- **Telegram** :
  1. Écris à **@BotFather** : `/newbot`, choisis un nom (ex. `CART3R`) puis un identifiant finissant par `bot` (ex. `cart3r_leo_bot`). Copie le **token** (forme `123456789:AAH…`).
  2. Écris `/start` à **@userinfobot** : copie ton **Id** (un nombre).
  3. Ouvre ton nouveau bot et appuie sur **Démarrer**.

## Étape 6 — Configurer (5 min)

Dans Termius, dans le dossier `cart3r` :

```
bash scripts/configure.sh
```

Le script te demande, une par une : la clé Helius, la clé Jupiter, le token Telegram, ton Id Telegram, puis un mot de passe pour le dashboard (invente-le et note-le). Colle chaque valeur puis Entrée.

À la fin, il affiche un **code de 32 lettres et chiffres** :
1. Copie-le (appui long).
2. Google Authenticator → **+** → **Saisir une clé de configuration** → nom `CART3R` → colle le code → **Basé sur l'heure** → **Ajouter**.

Un code à 6 chiffres qui change toutes les 30 secondes apparaît : il protège les actions sensibles du bot.

## Étape 7 — Démarrer (10 min)

```
bash scripts/start.sh
```

Attends la fin (3 à 8 minutes la première fois). Tu dois voir 6 services **running** / **Up**, puis recevoir sur Telegram :
- **« CART3R api démarré »**
- **« Capital paper initialisé : 100 € = … SOL »**

Envoie `/status` à ton bot : il répond avec ton capital simulé. **C'est en marche.**

## Étape 8 — Ajouter des wallets à observer

Le bot ne copie personne tant qu'un wallet n'a pas fait ses preuves en Shadow Trading (30 trades rentables pour un copieur).

1. Trouve des traders Solana actifs dans les classements de **GMGN** (gmgn.ai), **Cielo** ou **Nansen** : ce ne sont que des candidats, le bot les juge lui-même.
2. Pour chacun, envoie à ton bot Telegram : `/observer ADRESSE_DU_WALLET 123456` (123456 = le code affiché à ce moment dans Google Authenticator).
3. Vise 20 à 30 wallets.

## Au quotidien : tout passe par Telegram

| Je veux… | Message à envoyer au bot |
| --- | --- |
| Capital et état du bot | `/status` |
| Positions ouvertes | `/positions` |
| Wallets observés | `/wallets` |
| Tout arrêter tout de suite | `/panic` |
| Reprendre après un arrêt | `/reprendre 123456` |
| Ajouter un wallet | `/observer ADRESSE 123456` |
| Liste des commandes | `/aide` |

Le bot t'écrit tout seul à chaque opportunité, achat, vente, stop, limite atteinte ou erreur.

## Le dashboard sur le téléphone (facultatif)

1. Termius → **Port Forwarding** → **+** → **Local**.
2. Host : ton serveur. Port local : `8080`. Destination : `127.0.0.1`, port `8080`. Enregistre et active la règle.
3. Dans Safari : **http://localhost:8080** → identifiant `cart3r`, mot de passe du dashboard.

Si la page ne charge plus, repasse quelques secondes dans Termius : iOS met parfois les apps en pause en arrière-plan.

## Si quelque chose ne marche pas

C'est attendu au premier lancement : la partie réseau n'a pas pu être testée avant. Dans Termius :

```
cd ~/cart3r && bash scripts/logs.sh
```

Copie tout ce qui s'affiche (appui long → Sélectionner tout → Copier) et **colle-le dans la conversation avec Claude**. Je corrige et je te donne la commande de mise à jour.

Cas fréquents :
- `401` ou `403` avec Helius ou Jupiter : clé mal collée → relance `bash scripts/configure.sh` puis `docker compose up -d`.
- `429` : limite gratuite atteinte ; le bot réessaie seul.
- Aucun message Telegram : appuie sur **Démarrer** dans ton bot et vérifie ton Id.

## Commandes utiles (dans Termius)

| Action | Commande |
| --- | --- |
| Aller dans le dossier du bot | `cd ~/cart3r` |
| Arrêter le bot (données conservées) | `docker compose down` |
| Redémarrer | `docker compose up -d` |
| Voir l'état et les erreurs | `bash scripts/logs.sh` |
| Installer une nouvelle version | remplacer le zip sur GitHub, puis refaire la commande de l'étape 4 et `docker compose up -d --build` |

## Ce qui est volontairement bloqué

- **Le trading réel** : verrouillé, aucune clé de wallet chargée. Proposé seulement après des résultats positifs mesurés (backtest, au moins 4 semaines de paper trading, simulation Monte Carlo).
- **Le dashboard sur Internet** : accessible uniquement par le tunnel Termius.
