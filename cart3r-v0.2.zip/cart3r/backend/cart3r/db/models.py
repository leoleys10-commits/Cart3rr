"""Modèle de données PostgreSQL (section 5 de l'architecture).

Montants en entiers (lamports, unités de base du token). Toutes les dates en UTC.
Migrations générées avec Alembic à partir de ces modèles.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    BigInteger, Boolean, DateTime, ForeignKey, Identity, Index, Integer, Numeric, String, Text, UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


def ts() -> Mapped[datetime]:
    return mapped_column(DateTime(timezone=True), nullable=False)


class EventRow(Base):
    __tablename__ = "events"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    seq: Mapped[int] = mapped_column(BigInteger, Identity(always=True), unique=True)
    type: Mapped[str] = mapped_column(String(40), index=True)
    source: Mapped[str] = mapped_column(String(40))
    observed_at: Mapped[datetime] = ts()
    created_at: Mapped[datetime] = ts()
    correlation_id: Mapped[str | None] = mapped_column(String(32), index=True)
    idempotency_key: Mapped[str | None] = mapped_column(String(80), unique=True)
    payload: Mapped[dict] = mapped_column(JSONB)


class Token(Base):
    __tablename__ = "tokens"
    mint: Mapped[str] = mapped_column(String(44), primary_key=True)
    symbol: Mapped[str | None] = mapped_column(String(32))
    name: Mapped[str | None] = mapped_column(String(128))
    creator: Mapped[str | None] = mapped_column(String(44), index=True)
    program: Mapped[str | None] = mapped_column(String(44))
    extensions: Mapped[list] = mapped_column(JSONB, default=list)
    created_at: Mapped[datetime] = ts()
    status: Mapped[str] = mapped_column(String(16), default="curve")  # curve | graduated | dead
    graduated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class TokenSnapshot(Base):
    __tablename__ = "token_snapshots"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    mint: Mapped[str] = mapped_column(ForeignKey("tokens.mint"), index=True)
    observed_at: Mapped[datetime] = ts()
    source: Mapped[str] = mapped_column(String(32))
    price_usd: Mapped[float | None] = mapped_column(Numeric(38, 18))
    market_cap_usd: Mapped[float | None] = mapped_column(Numeric(20, 2))
    liquidity_usd: Mapped[float | None] = mapped_column(Numeric(20, 2))
    volume_1m: Mapped[float | None] = mapped_column(Numeric(20, 2))
    volume_5m: Mapped[float | None] = mapped_column(Numeric(20, 2))
    volume_15m: Mapped[float | None] = mapped_column(Numeric(20, 2))
    volume_1h: Mapped[float | None] = mapped_column(Numeric(20, 2))
    buyers_5m: Mapped[int | None] = mapped_column(Integer)
    sellers_5m: Mapped[int | None] = mapped_column(Integer)
    txns_5m: Mapped[int | None] = mapped_column(Integer)
    holders: Mapped[int | None] = mapped_column(Integer)
    top10_share_pct: Mapped[float | None] = mapped_column(Numeric(6, 2))
    __table_args__ = (Index("ix_snap_mint_time", "mint", "observed_at"),)


class SecurityCheck(Base):
    __tablename__ = "security_checks"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    mint: Mapped[str] = mapped_column(ForeignKey("tokens.mint"), index=True)
    checked_at: Mapped[datetime] = ts()
    excluded: Mapped[bool] = mapped_column(Boolean)
    score: Mapped[int] = mapped_column(Integer)
    findings: Mapped[list] = mapped_column(JSONB)
    sources: Mapped[list] = mapped_column(JSONB)


class Wallet(Base):
    __tablename__ = "wallets"
    address: Mapped[str] = mapped_column(String(44), primary_key=True)
    cluster_id: Mapped[str | None] = mapped_column(String(44), index=True)
    style: Mapped[str | None] = mapped_column(String(24))
    shadow_status: Mapped[str] = mapped_column(String(16), default="observed")
    reputation: Mapped[float | None] = mapped_column(Numeric(6, 3))
    added_at: Mapped[datetime] = ts()
    added_from: Mapped[str] = mapped_column(String(32))  # onchain | gmgn | cielo | nansen | manual
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class WalletTrade(Base):
    __tablename__ = "wallet_trades"
    signature: Mapped[str] = mapped_column(String(88), primary_key=True)
    wallet: Mapped[str] = mapped_column(ForeignKey("wallets.address"), index=True)
    mint: Mapped[str] = mapped_column(String(44), index=True)
    side: Mapped[str] = mapped_column(String(4))  # buy | sell
    token_amount: Mapped[int] = mapped_column(Numeric(40, 0))
    sol_lamports: Mapped[int] = mapped_column(BigInteger)
    fee_lamports: Mapped[int] = mapped_column(BigInteger)
    slot: Mapped[int] = mapped_column(BigInteger)
    block_time: Mapped[datetime] = ts()
    detected_at: Mapped[datetime] = ts()


class ShadowLeg(Base):
    __tablename__ = "shadow_trades"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    wallet: Mapped[str] = mapped_column(ForeignKey("wallets.address"), index=True)
    mint: Mapped[str] = mapped_column(String(44), index=True)
    book: Mapped[str] = mapped_column(String(8))  # wallet | copy | cart3r
    status: Mapped[str] = mapped_column(String(16))  # open | closed | not_simulable
    note: Mapped[str | None] = mapped_column(Text)
    fills: Mapped[list] = mapped_column(JSONB)  # liste de fills avec quote brute
    net_return_pct: Mapped[float | None] = mapped_column(Numeric(12, 4))
    opened_at: Mapped[datetime] = ts()
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (UniqueConstraint("wallet", "mint", "book", "opened_at"),)


class Decision(Base):
    __tablename__ = "decisions"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    correlation_id: Mapped[str] = mapped_column(String(32), index=True)
    mint: Mapped[str] = mapped_column(String(44), index=True)
    decided_at: Mapped[datetime] = ts()
    strategy: Mapped[str | None] = mapped_column(String(32))
    scores: Mapped[dict] = mapped_column(JSONB)
    expected_net_pct: Mapped[float | None] = mapped_column(Numeric(8, 3))
    accepted: Mapped[bool] = mapped_column(Boolean)
    reasons: Mapped[list] = mapped_column(JSONB)
    settings_version: Mapped[int] = mapped_column(Integer)


class Order(Base):
    __tablename__ = "orders"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    idempotency_key: Mapped[str] = mapped_column(String(80), unique=True)
    mode: Mapped[str] = mapped_column(String(10))
    side: Mapped[str] = mapped_column(String(4))
    mint: Mapped[str] = mapped_column(String(44), index=True)
    status: Mapped[str] = mapped_column(String(16))  # approved | sent | filled | failed | expired
    quote: Mapped[dict] = mapped_column(JSONB)
    signature: Mapped[str | None] = mapped_column(String(88), unique=True)
    fee_lamports: Mapped[int | None] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = ts()
    updated_at: Mapped[datetime] = ts()


class Position(Base):
    __tablename__ = "positions"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    mint: Mapped[str] = mapped_column(String(44), index=True)
    mode: Mapped[str] = mapped_column(String(10))
    strategy: Mapped[str] = mapped_column(String(32))
    state: Mapped[str] = mapped_column(String(16))  # voir machine d'états (section 4)
    entry_lamports: Mapped[int] = mapped_column(BigInteger)
    token_amount: Mapped[int] = mapped_column(Numeric(40, 0))  # quantité restante
    stop_pct: Mapped[float] = mapped_column(Numeric(6, 2))
    exit_plan: Mapped[dict] = mapped_column(JSONB)
    realized_lamports: Mapped[int] = mapped_column(BigInteger, default=0)
    opened_at: Mapped[datetime] = ts()
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    exit_reason: Mapped[str | None] = mapped_column(String(64))
    cost_lamports: Mapped[int] = mapped_column(BigInteger)  # coût total payé (frais et rente inclus)
    last_value_lamports: Mapped[int | None] = mapped_column(BigInteger)
    entry_liquidity_usd: Mapped[float | None] = mapped_column(Numeric(20, 2))
    wallet: Mapped[str | None] = mapped_column(String(44))  # wallet copié (smart_money_swing)
    correlation_id: Mapped[str] = mapped_column(String(32), index=True)


class GuardStateRow(Base):
    __tablename__ = "guard_state"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    state: Mapped[dict] = mapped_column(JSONB)
    updated_at: Mapped[datetime] = ts()


class CapitalLedger(Base):
    __tablename__ = "capital_ledger"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    at: Mapped[datetime] = ts()
    bucket: Mapped[str] = mapped_column(String(16))  # reference | reserve | gains | fees | rent
    delta_lamports: Mapped[int] = mapped_column(BigInteger)
    reason: Mapped[str] = mapped_column(String(64))
    ref: Mapped[str | None] = mapped_column(String(32))


class SettingsHistory(Base):
    __tablename__ = "settings_history"
    version: Mapped[int] = mapped_column(Integer, primary_key=True)
    changed_at: Mapped[datetime] = ts()
    author: Mapped[str] = mapped_column(String(32))
    settings: Mapped[dict] = mapped_column(JSONB)
    risk_increasing: Mapped[list] = mapped_column(JSONB)
    confirmed_with_totp: Mapped[bool] = mapped_column(Boolean)


class Alert(Base):
    __tablename__ = "alerts"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    at: Mapped[datetime] = ts()
    level: Mapped[str] = mapped_column(String(10))
    kind: Mapped[str] = mapped_column(String(40))
    message: Mapped[str] = mapped_column(Text)
    delivered: Mapped[bool] = mapped_column(Boolean, default=False)
