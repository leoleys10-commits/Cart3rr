"""Création du schéma : `python -m cart3r.db.init`.

Phase 3 : création directe depuis les modèles. Les migrations Alembic
remplaceront ce script avant la première mise à jour de schéma en production.
"""
from __future__ import annotations

import asyncio

from sqlalchemy.ext.asyncio import create_async_engine

from cart3r.core.config import Secrets
from cart3r.db.models import Base


async def main() -> None:
    engine = create_async_engine(Secrets.from_env().database_url.get_secret_value())
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    await engine.dispose()
    print("Schéma CART3R créé.")


if __name__ == "__main__":
    asyncio.run(main())
