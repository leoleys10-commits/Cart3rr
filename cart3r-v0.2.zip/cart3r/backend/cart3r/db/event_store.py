"""Bus d'événements PostgreSQL : table `events` + LISTEN/NOTIFY.

Même contrat que `InMemoryEventBus` :
- `publish` est idempotent (contrainte UNIQUE sur idempotency_key) ;
- les abonnés ne reçoivent que des événements frais ;
- au redémarrage, un abonné reprend depuis le dernier `seq` traité
  (aucune perte d'événement entre deux processus).

NON TESTÉ dans l'environnement actuel (pas de PostgreSQL ni d'asyncpg) ;
couvert par les tests d'intégration de la phase 7 (docker compose).
"""
from __future__ import annotations

import asyncio
import json
from collections import defaultdict

import asyncpg

from cart3r.core.events import EVENT_TYPES, Event, Handler, utcnow

CHANNEL = "cart3r_events"

INSERT = """
INSERT INTO events (id, type, source, observed_at, created_at, correlation_id, idempotency_key, payload)
VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb)
ON CONFLICT (idempotency_key) DO NOTHING
RETURNING seq
"""


class PostgresEventBus:
    def __init__(self, pool: asyncpg.Pool, consumer: str) -> None:
        self._pool, self._consumer = pool, consumer
        self._handlers: dict[str, list[Handler]] = defaultdict(list)
        self._wakeup = asyncio.Event()

    def subscribe(self, event_type: str, handler: Handler) -> None:
        if event_type not in EVENT_TYPES:
            raise ValueError(event_type)
        self._handlers[event_type].append(handler)

    async def publish(self, event: Event) -> bool:
        async with self._pool.acquire() as con:
            seq = await con.fetchval(
                INSERT, event.id, event.type, event.source, event.observed_at, event.created_at,
                event.correlation_id, event.idempotency_key, json.dumps(event.payload, default=str),
            )
            if seq is None:
                return False
            await con.execute("SELECT pg_notify($1, $2)", CHANNEL, str(seq))
            return True

    async def _cursor(self, con: asyncpg.Connection) -> int:
        await con.execute(
            "CREATE TABLE IF NOT EXISTS event_cursors (consumer TEXT PRIMARY KEY, seq BIGINT NOT NULL)"
        )
        seq = await con.fetchval("SELECT seq FROM event_cursors WHERE consumer = $1", self._consumer)
        return seq or 0

    async def run(self, batch: int = 500) -> None:
        """Boucle de consommation : à lancer comme tâche de fond du processus."""
        listener = await self._pool.acquire()
        await listener.add_listener(CHANNEL, lambda *_: self._wakeup.set())
        try:
            async with self._pool.acquire() as con:
                last = await self._cursor(con)
            types = list(self._handlers)
            while True:
                async with self._pool.acquire() as con:
                    rows = await con.fetch(
                        "SELECT * FROM events WHERE seq > $1 AND type = ANY($2::text[]) ORDER BY seq LIMIT $3",
                        last, types, batch,
                    )
                    for row in rows:
                        ev = Event(
                            type=row["type"], source=row["source"], payload=json.loads(row["payload"]),
                            observed_at=row["observed_at"], created_at=row["created_at"], id=row["id"],
                            correlation_id=row["correlation_id"], idempotency_key=row["idempotency_key"],
                        )
                        if ev.is_fresh(utcnow()):
                            await asyncio.gather(*(h(ev) for h in self._handlers[ev.type]))
                        last = row["seq"]
                    if rows:
                        await con.execute(
                            "INSERT INTO event_cursors (consumer, seq) VALUES ($1, $2) "
                            "ON CONFLICT (consumer) DO UPDATE SET seq = EXCLUDED.seq",
                            self._consumer, last,
                        )
                if len(rows) < batch:
                    self._wakeup.clear()
                    try:
                        await asyncio.wait_for(self._wakeup.wait(), timeout=5)
                    except asyncio.TimeoutError:
                        pass
        finally:
            await self._pool.release(listener)
