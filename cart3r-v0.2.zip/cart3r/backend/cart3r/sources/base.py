"""Sources de données avec secours et contrôle de fraîcheur.

Chaque appel renvoie un `Fresh[T]` qui porte l'heure d'observation et le nom
de la source. Si toutes les sources échouent, ou si la donnée est trop
vieille, on lève `DataUnavailable` : l'appelant ne décide jamais sur une
valeur inventée ou périmée.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Awaitable, Callable, Generic, TypeVar

T = TypeVar("T")


class DataUnavailable(RuntimeError):
    pass


@dataclass(frozen=True)
class Fresh(Generic[T]):
    value: T
    observed_at: datetime
    source: str

    def age(self, now: datetime | None = None) -> timedelta:
        return (now or datetime.now(timezone.utc)) - self.observed_at


@dataclass
class ProviderHealth:
    consecutive_failures: int = 0
    last_latency_s: float | None = None
    cooldown_until: float = 0.0  # time.monotonic()


@dataclass
class Provider(Generic[T]):
    name: str
    fetch: Callable[..., Awaitable[Fresh[T]]]
    timeout_s: float = 2.0
    health: ProviderHealth = field(default_factory=ProviderHealth)


class FallbackSource(Generic[T]):
    """Essaie les fournisseurs dans l'ordre ; écarte temporairement ceux qui échouent.

    - Un fournisseur qui échoue `max_failures` fois de suite est mis en pause
      `cooldown_s` secondes (sauf s'il est le seul restant).
    - Une réponse plus vieille que `max_age` est rejetée comme un échec.
    """

    def __init__(
        self,
        providers: list[Provider[T]],
        *,
        max_age: timedelta,
        max_failures: int = 3,
        cooldown_s: float = 30.0,
        clock: Callable[[], float] = time.monotonic,
        now: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ) -> None:
        if not providers:
            raise ValueError("au moins un fournisseur est requis")
        self.providers = providers
        self.max_age = max_age
        self.max_failures = max_failures
        self.cooldown_s = cooldown_s
        self._clock = clock
        self._now = now

    def _ordered(self) -> list[Provider[T]]:
        t = self._clock()
        ready = [p for p in self.providers if p.health.cooldown_until <= t]
        return ready or list(self.providers)

    async def get(self, *args, **kwargs) -> Fresh[T]:
        errors: list[str] = []
        for p in self._ordered():
            start = self._clock()
            try:
                result = await asyncio.wait_for(p.fetch(*args, **kwargs), timeout=p.timeout_s)
                if result.age(self._now()) > self.max_age:
                    raise DataUnavailable(f"donnée périmée ({result.age(self._now())})")
            except Exception as exc:  # noqa: BLE001 - on veut basculer sur toute erreur
                p.health.consecutive_failures += 1
                if p.health.consecutive_failures >= self.max_failures:
                    p.health.cooldown_until = self._clock() + self.cooldown_s
                errors.append(f"{p.name}: {type(exc).__name__}: {exc}")
                continue
            p.health.consecutive_failures = 0
            p.health.last_latency_s = self._clock() - start
            return result
        raise DataUnavailable("; ".join(errors))
