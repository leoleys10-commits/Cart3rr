"""Lecture brute d'un compte mint SPL Token / Token-2022.

On lit les octets du compte directement (RPC `getAccountInfo`, encodage base64),
sans faire confiance à un score tiers.

Disposition d'un mint SPL (82 octets) :
  0   COption<Pubkey> mint_authority   (u32 tag + 32 octets)
  36  u64 supply
  44  u8  decimals
  45  bool is_initialized
  46  COption<Pubkey> freeze_authority (u32 tag + 32 octets)
Token-2022 : le mint est complété jusqu'à 165 octets, puis 1 octet
`AccountType` (1 = Mint) à l'offset 165, puis des extensions TLV
(u16 type, u16 longueur, valeur), en little-endian.

À VÉRIFIER avant la mise en production : la numérotation des types
d'extension ci-dessous a été écrite d'après le dépôt spl-token-2022 ; un test
d'intégration la confrontera à de vrais mints (phase 7). La sécurité ne dépend
pas de cette table : toute extension hors liste blanche exclut le token.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field

from .b58 import b58encode

TOKEN_PROGRAM_ID = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
TOKEN_2022_PROGRAM_ID = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"

MINT_LEN = 82
ACCOUNT_LEN = 165
ACCOUNT_TYPE_MINT = 1

EXTENSION_NAMES: dict[int, str] = {
    1: "TransferFeeConfig",
    3: "MintCloseAuthority",
    4: "ConfidentialTransferMint",
    6: "DefaultAccountState",
    9: "NonTransferable",
    10: "InterestBearingConfig",
    12: "PermanentDelegate",
    14: "TransferHook",
    16: "ConfidentialTransferFeeConfig",
    18: "MetadataPointer",
    19: "TokenMetadata",
    20: "GroupPointer",
    21: "TokenGroup",
    22: "GroupMemberPointer",
    23: "TokenGroupMember",
}

# Seules extensions tolérées en V1 : métadonnées. Tout le reste = exclusion.
SAFE_EXTENSIONS: frozenset[int] = frozenset({18, 19})

# Extensions connues comme utilisées pour piéger les acheteurs.
CRITICAL_EXTENSIONS: frozenset[int] = frozenset({1, 3, 6, 9, 12, 14})


class MintParseError(ValueError):
    pass


@dataclass(frozen=True)
class MintInfo:
    program: str
    mint_authority: str | None
    freeze_authority: str | None
    supply: int
    decimals: int
    is_initialized: bool
    extensions: tuple[int, ...] = field(default_factory=tuple)

    @property
    def is_token_2022(self) -> bool:
        return self.program == TOKEN_2022_PROGRAM_ID

    @property
    def unsafe_extensions(self) -> tuple[int, ...]:
        return tuple(e for e in self.extensions if e not in SAFE_EXTENSIONS)

    def extension_names(self) -> list[str]:
        return [EXTENSION_NAMES.get(e, f"Inconnue({e})") for e in self.extensions]


def _coption_pubkey(data: bytes, offset: int) -> str | None:
    (tag,) = struct.unpack_from("<I", data, offset)
    if tag == 0:
        return None
    if tag != 1:
        raise MintParseError(f"tag COption invalide à l'offset {offset}: {tag}")
    return b58encode(data[offset + 4 : offset + 36])


def _parse_tlv(data: bytes) -> tuple[int, ...]:
    exts: list[int] = []
    off = ACCOUNT_LEN + 1
    while off + 4 <= len(data):
        ext_type, length = struct.unpack_from("<HH", data, off)
        if ext_type == 0 and length == 0:
            break  # zone non initialisée
        if off + 4 + length > len(data):
            raise MintParseError("extension TLV tronquée")
        exts.append(ext_type)
        off += 4 + length
    return tuple(exts)


def parse_mint(data: bytes, owner_program: str) -> MintInfo:
    if owner_program not in (TOKEN_PROGRAM_ID, TOKEN_2022_PROGRAM_ID):
        raise MintParseError(f"programme propriétaire inattendu : {owner_program}")
    if len(data) < MINT_LEN:
        raise MintParseError(f"compte trop court pour un mint : {len(data)} octets")

    mint_authority = _coption_pubkey(data, 0)
    (supply,) = struct.unpack_from("<Q", data, 36)
    decimals = data[44]
    is_initialized = data[45] == 1
    freeze_authority = _coption_pubkey(data, 46)

    extensions: tuple[int, ...] = ()
    if len(data) > MINT_LEN:
        if owner_program != TOKEN_2022_PROGRAM_ID:
            raise MintParseError("données au-delà de 82 octets sur un mint SPL classique")
        if len(data) <= ACCOUNT_LEN or data[ACCOUNT_LEN] != ACCOUNT_TYPE_MINT:
            raise MintParseError("Token-2022 : AccountType Mint absent")
        if any(data[MINT_LEN:ACCOUNT_LEN]):
            raise MintParseError("Token-2022 : zone de padding non nulle")
        extensions = _parse_tlv(data)

    return MintInfo(
        program=owner_program,
        mint_authority=mint_authority,
        freeze_authority=freeze_authority,
        supply=supply,
        decimals=decimals,
        is_initialized=is_initialized,
        extensions=extensions,
    )


def build_mint_bytes(
    *,
    mint_authority: bytes | None = None,
    freeze_authority: bytes | None = None,
    supply: int = 1_000_000_000 * 10**6,
    decimals: int = 6,
    extensions: list[tuple[int, bytes]] | None = None,
) -> bytes:
    """Construit les octets d'un mint (utilisé par les tests et le backtest)."""

    def coption(pk: bytes | None) -> bytes:
        return struct.pack("<I", 0) + b"\0" * 32 if pk is None else struct.pack("<I", 1) + pk

    base = coption(mint_authority) + struct.pack("<QBB", supply, decimals, 1) + coption(freeze_authority)
    assert len(base) == MINT_LEN
    if extensions is None:
        return base
    tlv = b"".join(struct.pack("<HH", t, len(v)) + v for t, v in extensions)
    return base + b"\0" * (ACCOUNT_LEN - MINT_LEN) + bytes([ACCOUNT_TYPE_MINT]) + tlv
