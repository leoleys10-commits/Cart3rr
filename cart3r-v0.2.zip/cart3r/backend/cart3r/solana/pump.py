"""Constantes et détection Pump.fun / PumpSwap (à confirmer sur mainnet en phase 7)."""
from __future__ import annotations

PUMP_FUN_PROGRAM = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"
PUMPSWAP_PROGRAM = "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA"
CREATE_MARKERS = ("Instruction: Create", "Instruction: CreateV2")
MIGRATE_MARKERS = ("Instruction: Migrate",)


def classify_logs(logs: list[str]) -> str | None:
    """'created', 'graduated' ou None, d'après les logs d'une transaction Pump.fun."""
    text = "\n".join(logs)
    if any(m in text for m in MIGRATE_MARKERS):
        return "graduated"
    if any(m in text for m in CREATE_MARKERS):
        return "created"
    return None
