"""Extraction d'un swap depuis une transaction `getTransaction` (jsonParsed).

On ne décode pas les instructions de chaque DEX : on compare les soldes
avant/après du wallet (SOL natif + WSOL, et tokens). C'est robuste aux
routes multi-DEX et suffisant pour le Smart Money Tracker et le Shadow.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

WSOL_MINT = "So11111111111111111111111111111111111111112"
STABLE_MINTS = frozenset({
    "EPjFWdd5AufqSSqeM2qJ1zzybapC8G4wEGGkZwyTDt1v",  # USDC
    "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",  # USDT
})


@dataclass(frozen=True)
class SwapEvent:
    signature: str
    wallet: str
    mint: str
    side: str  # "buy" | "sell"
    token_amount: int  # unités de base, toujours positif
    sol_lamports: int  # SOL dépensés (buy) ou reçus (sell), hors frais réseau
    fee_lamports: int
    slot: int
    block_time: datetime


def _account_keys(tx: dict) -> list[str]:
    keys = tx["transaction"]["message"]["accountKeys"]
    out = [k["pubkey"] if isinstance(k, dict) else k for k in keys]
    loaded = tx.get("meta", {}).get("loadedAddresses") or {}
    return out + loaded.get("writable", []) + loaded.get("readonly", [])


def _token_deltas(meta: dict, owner: str) -> dict[str, int]:
    deltas: dict[str, int] = {}
    for sign, key in ((-1, "preTokenBalances"), (1, "postTokenBalances")):
        for b in meta.get(key) or []:
            if b.get("owner") != owner:
                continue
            amount = int(b["uiTokenAmount"]["amount"])
            deltas[b["mint"]] = deltas.get(b["mint"], 0) + sign * amount
    return {m: d for m, d in deltas.items() if d != 0}


def parse_swap(tx: dict, wallet: str, signature: str) -> SwapEvent | None:
    """Renvoie le swap SOL↔token du wallet, ou None si ce n'en est pas un clair.

    Cas ignorés volontairement (None) : transaction échouée, plusieurs tokens
    non-SOL qui bougent (route exotique), transfert sans contrepartie en SOL
    (réception de tokens : non copiable, cf. étude Bitquery).
    """
    meta = tx.get("meta") or {}
    if meta.get("err") is not None:
        return None
    keys = _account_keys(tx)
    if wallet not in keys:
        return None
    idx = keys.index(wallet)
    fee = int(meta.get("fee", 0))
    payer_fee = fee if idx == 0 else 0
    sol_delta = int(meta["postBalances"][idx]) - int(meta["preBalances"][idx]) + payer_fee

    tdeltas = _token_deltas(meta, wallet)
    sol_delta += tdeltas.pop(WSOL_MINT, 0)
    if STABLE_MINTS & tdeltas.keys():
        return None  # swap contre stablecoin : hors périmètre V1
    if len(tdeltas) != 1:
        return None
    (mint, tok), = tdeltas.items()

    if tok > 0 and sol_delta < 0:
        side, sol = "buy", -sol_delta
    elif tok < 0 and sol_delta > 0:
        side, sol = "sell", sol_delta
    else:
        return None

    bt = tx.get("blockTime")
    return SwapEvent(
        signature=signature, wallet=wallet, mint=mint, side=side, token_amount=abs(tok),
        sol_lamports=sol, fee_lamports=payer_fee, slot=int(tx["slot"]),
        block_time=datetime.fromtimestamp(bt, timezone.utc) if bt else datetime.now(timezone.utc),
    )
