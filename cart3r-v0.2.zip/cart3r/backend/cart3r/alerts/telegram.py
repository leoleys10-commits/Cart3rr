"""Bot Telegram : alertes + commandes.

Sécurité :
- seul `CART3R_TELEGRAM_OWNER_CHAT_ID` est écouté ; tout autre chat est ignoré ;
- consultation libre : /status /positions /wallets /aide ;
- /panic sans code (arrêter est toujours sûr) ;
- /reprendre <code TOTP>, /observer <adresse> <code TOTP> : code à 6 chiffres exigé.
NON TESTÉ EN RÉSEAU (câblage) ; le TOTP est testé.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone

import httpx

from cart3r.core import totp
from cart3r.core.events import Event
from cart3r.solana.b58 import is_pubkey

log = logging.getLogger(__name__)
LAMPORTS = 1_000_000_000

HELP = (
    "Commandes CART3R :\n"
    "/status — capital, limites, mode\n"
    "/positions — positions ouvertes\n"
    "/wallets — wallets observés et leur statut\n"
    "/panic — arrête immédiatement tout nouvel achat\n"
    "/reprendre 123456 — reprise après arrêt (code TOTP)\n"
    "/observer <adresse> 123456 — ajoute un wallet au Shadow Trading (code TOTP)"
)


class TelegramBot:
    def __init__(self, http: httpx.AsyncClient, token: str, owner_chat_id: int, pool, bus, totp_secret: str) -> None:
        self.http, self.base = http, f"https://api.telegram.org/bot{token}"
        self.owner, self.pool, self.bus, self.totp_secret = owner_chat_id, pool, bus, totp_secret
        self._offset = 0

    async def send(self, text: str) -> None:
        try:
            await self.http.post(f"{self.base}/sendMessage", json={"chat_id": self.owner, "text": text[:4000],
                                                                    "disable_web_page_preview": True})
        except Exception as exc:  # noqa: BLE001
            log.warning("envoi Telegram impossible : %s", exc)

    async def on_alert(self, ev: Event) -> None:
        p = ev.payload
        icon = {"critical": "🛑", "warning": "⚠️"}.get(p.get("level"), "•")
        text = f"{icon} {p.get('message')}"
        if p.get("mint"):
            text += f"\nhttps://dexscreener.com/solana/{p['mint']}"
        await self.send(text)

    async def _status(self) -> str:
        st = await self.pool.fetchval("SELECT state FROM guard_state WHERE id = 1")
        if not st:
            return "Capital non initialisé (processus guard pas encore démarré)."
        import json
        s = json.loads(st) if isinstance(st, str) else st
        equity = s["cash_lamports"] + sum(s["open_positions"].values())
        ref = s["reference_lamports"]
        state = "PANIC STOP" if s["panic"] else (s["halted_reason"] or s["paused_until_period"] or "achats autorisés")
        return (f"Mode : paper\nCapital : {equity / LAMPORTS:.4f} SOL (référence {ref / LAMPORTS:.4f} SOL, "
                f"{100 * (equity - ref) / ref:+.2f} %)\nPositions ouvertes : {len(s['open_positions'])}\n"
                f"Achats aujourd'hui : {s['buys_today']}\nÉtat : {state}")

    async def _positions(self) -> str:
        rows = await self.pool.fetch("SELECT mint, strategy, cost_lamports, last_value_lamports, opened_at "
                                     "FROM positions WHERE state <> 'closed' ORDER BY opened_at")
        if not rows:
            return "Aucune position ouverte."
        lines = []
        for r in rows:
            v = r["last_value_lamports"] or 0
            lines.append(f"{r['mint'][:6]}… {r['strategy']} : {r['cost_lamports'] / LAMPORTS:.4f} → "
                         f"{v / LAMPORTS:.4f} SOL ({100 * (v - r['cost_lamports']) / r['cost_lamports']:+.1f} %)")
        return "\n".join(lines)

    async def _wallets(self) -> str:
        rows = await self.pool.fetch("SELECT address, shadow_status FROM wallets WHERE active ORDER BY added_at")
        if not rows:
            return "Aucun wallet observé. Ajoute-en avec /observer <adresse> <code>."
        return "\n".join(f"{r['address'][:8]}… : {r['shadow_status']}" for r in rows)

    async def handle(self, text: str) -> str:
        parts = text.strip().split()
        cmd = parts[0].lower().split("@")[0] if parts else ""
        now = datetime.now(timezone.utc)
        if cmd in ("/start", "/aide", "/help"):
            return HELP
        if cmd == "/status":
            return await self._status()
        if cmd == "/positions":
            return await self._positions()
        if cmd == "/wallets":
            return await self._wallets()
        if cmd == "/panic":
            await self.bus.publish(Event(type="system.panic_stop", source="telegram", observed_at=now, payload={}))
            return "🛑 PANIC STOP : plus aucun achat. Les positions ouvertes restent surveillées et protégées."
        if cmd == "/reprendre":
            if len(parts) < 2 or not totp.verify(self.totp_secret, parts[1]):
                return "Code TOTP invalide."
            await self.bus.publish(Event(type="system.resume", source="telegram", observed_at=now, payload={}))
            return "Reprise demandée."
        if cmd == "/observer":
            if len(parts) < 3 or not is_pubkey(parts[1]):
                return "Usage : /observer <adresse Solana> <code TOTP>"
            if not totp.verify(self.totp_secret, parts[2]):
                return "Code TOTP invalide."
            await self.pool.execute(
                "INSERT INTO wallets (address, added_at, added_from, shadow_status, active) "
                "VALUES ($1, now(), 'telegram', 'observed', true) ON CONFLICT (address) DO UPDATE SET active = true",
                parts[1])
            return "Wallet ajouté au Shadow Trading. Le suivi démarre dans la minute."
        return "Commande inconnue. /aide pour la liste."

    async def poll(self) -> None:
        while True:
            try:
                r = await self.http.get(f"{self.base}/getUpdates", params={"timeout": 30, "offset": self._offset},
                                        timeout=40)
                for upd in r.json().get("result", []):
                    self._offset = upd["update_id"] + 1
                    msg = upd.get("message") or {}
                    if (msg.get("chat") or {}).get("id") != self.owner:
                        continue  # chat inconnu : ignoré
                    await self.send(await self.handle(msg.get("text", "")))
            except Exception as exc:  # noqa: BLE001
                log.warning("Telegram indisponible : %s", exc)
                await asyncio.sleep(5)
