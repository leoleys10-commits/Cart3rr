"""Processus `api` : API du dashboard + bot Telegram.

Écoute UNIQUEMENT sur 127.0.0.1 : on y accède par un tunnel SSH
(`ssh -L 8080:127.0.0.1:8080 ...`). Mot de passe (HTTP Basic) + TOTP pour
toute action qui augmente le risque.
NON TESTÉ EN RÉSEAU (câblage FastAPI).
"""
from __future__ import annotations

import asyncio
import json
import os
import secrets as pysecrets
from datetime import datetime, timezone
from pathlib import Path

import httpx
import uvicorn
from fastapi import Depends, FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel

from cart3r.alerts.telegram import TelegramBot
from cart3r.core import totp
from cart3r.core.config import Mode, Secrets, Settings, risk_increasing_changes
from cart3r.core.events import Event
from cart3r.core.runtime import create_pool, load_settings
from cart3r.db.event_store import PostgresEventBus
from cart3r.solana.b58 import is_pubkey

STATIC = Path(__file__).parent / "static"


def _rows(rows) -> list[dict]:
    out = []
    for r in rows:
        d = dict(r)
        for k, v in d.items():
            if isinstance(v, datetime):
                d[k] = v.isoformat()
            elif hasattr(v, "is_finite"):  # Decimal
                d[k] = float(v)
            elif isinstance(v, str) and k in ("exit_plan", "scores", "reasons", "findings", "fills", "state"):
                try:
                    d[k] = json.loads(v)
                except ValueError:
                    pass
        out.append(d)
    return out


def _iso(v: datetime | None) -> str | None:
    return v.isoformat() if v else None


class SettingsUpdate(BaseModel):
    settings: dict
    totp: str | None = None


class WalletAdd(BaseModel):
    address: str
    totp: str


class Totp(BaseModel):
    totp: str


def build_app(secrets: Secrets) -> FastAPI:
    app = FastAPI(title="CART3R", docs_url=None, redoc_url=None)
    security = HTTPBasic()
    state: dict = {}
    pw = secrets.dashboard_password.get_secret_value() if secrets.dashboard_password else None
    totp_secret = secrets.totp_secret.get_secret_value() if secrets.totp_secret else ""

    def auth(c: HTTPBasicCredentials = Depends(security)) -> None:
        if not pw or not pysecrets.compare_digest(c.password.encode(), pw.encode()):
            raise HTTPException(401, "mot de passe invalide", headers={"WWW-Authenticate": "Basic"})

    def need_totp(code: str | None) -> None:
        if not totp.verify(totp_secret, code or ""):
            raise HTTPException(403, "code TOTP invalide")

    @app.on_event("startup")
    async def startup() -> None:
        state["pool"] = await create_pool(secrets)
        state["bus"] = PostgresEventBus(state["pool"], consumer="api")
        state["http"] = httpx.AsyncClient(timeout=15)
        tasks = []

        async def save_alert(ev: Event) -> None:
            p = ev.payload
            await state["pool"].execute(
                "INSERT INTO alerts (at, level, kind, message, delivered) VALUES (now(), $1, $2, $3, $4)",
                p.get("level", "info"), p.get("kind", ""), p.get("message", ""), bool(secrets.telegram_bot_token))

        state["bus"].subscribe("alert", save_alert)
        if secrets.telegram_bot_token and secrets.telegram_owner_chat_id:
            bot = TelegramBot(state["http"], secrets.telegram_bot_token.get_secret_value(),
                              secrets.telegram_owner_chat_id, state["pool"], state["bus"], totp_secret)
            state["bus"].subscribe("alert", bot.on_alert)
            tasks.append(bot.poll())
            await bot.send("CART3R api démarré. /aide pour les commandes.")
        tasks.append(state["bus"].run())
        state["tasks"] = [asyncio.create_task(t) for t in tasks]

    async def publish(type_: str, payload: dict) -> None:
        await state["bus"].publish(Event(type=type_, source="api", observed_at=datetime.now(timezone.utc), payload=payload))

    @app.get("/", dependencies=[Depends(auth)])
    async def index() -> FileResponse:
        return FileResponse(STATIC / "index.html")

    @app.get("/api/status", dependencies=[Depends(auth)])
    async def status() -> dict:
        pool = state["pool"]
        settings, version = await load_settings(pool)
        g = await pool.fetchrow("SELECT state, updated_at FROM guard_state WHERE id = 1")
        closed = await pool.fetch("SELECT realized_lamports, cost_lamports, closed_at FROM positions WHERE state = 'closed'")
        return {
            "settings": settings.model_dump(mode="json"), "settings_version": version,
            "guard": (json.loads(g["state"]) if isinstance(g["state"], str) else g["state"]) if g else None,
            "guard_updated_at": g["updated_at"].isoformat() if g else None,
            "closed_trades": _rows(closed),
            "open_positions": await pool.fetchval("SELECT count(*) FROM positions WHERE state <> 'closed'"),
            "last_event_at": _iso(await pool.fetchval("SELECT max(created_at) FROM events")),
        }

    @app.get("/api/positions", dependencies=[Depends(auth)])
    async def positions(state_: str = "open") -> list[dict]:
        q = "SELECT * FROM positions WHERE state <> 'closed' ORDER BY opened_at DESC" if state_ == "open" else \
            "SELECT * FROM positions WHERE state = 'closed' ORDER BY closed_at DESC LIMIT 500"
        return _rows(await state["pool"].fetch(q))

    @app.get("/api/decisions", dependencies=[Depends(auth)])
    async def decisions() -> list[dict]:
        return _rows(await state["pool"].fetch("SELECT * FROM decisions ORDER BY decided_at DESC LIMIT 300"))

    @app.get("/api/scanner", dependencies=[Depends(auth)])
    async def scanner() -> list[dict]:
        return _rows(await state["pool"].fetch(
            "SELECT DISTINCT ON (s.mint) s.*, t.graduated_at, c.score AS security_score, c.excluded "
            "FROM token_snapshots s JOIN tokens t ON t.mint = s.mint "
            "LEFT JOIN LATERAL (SELECT score, excluded FROM security_checks WHERE mint = s.mint ORDER BY checked_at DESC LIMIT 1) c ON true "
            "WHERE s.observed_at > now() - interval '3 hours' ORDER BY s.mint, s.observed_at DESC LIMIT 200"))

    @app.get("/api/wallets", dependencies=[Depends(auth)])
    async def wallets() -> list[dict]:
        return _rows(await state["pool"].fetch("SELECT * FROM wallets WHERE active ORDER BY added_at"))

    @app.get("/api/wallet_trades", dependencies=[Depends(auth)])
    async def wallet_trades() -> list[dict]:
        return _rows(await state["pool"].fetch("SELECT * FROM wallet_trades ORDER BY block_time DESC LIMIT 100"))

    @app.get("/api/shadow", dependencies=[Depends(auth)])
    async def shadow() -> list[dict]:
        return _rows(await state["pool"].fetch("SELECT * FROM shadow_trades ORDER BY opened_at DESC LIMIT 1000"))

    @app.get("/api/alerts", dependencies=[Depends(auth)])
    async def alerts() -> list[dict]:
        return _rows(await state["pool"].fetch("SELECT * FROM alerts ORDER BY at DESC LIMIT 100"))

    @app.post("/api/wallets", dependencies=[Depends(auth)])
    async def add_wallet(body: WalletAdd) -> dict:
        need_totp(body.totp)
        if not is_pubkey(body.address):
            raise HTTPException(400, "adresse Solana invalide")
        await state["pool"].execute(
            "INSERT INTO wallets (address, added_at, added_from, shadow_status, active) VALUES ($1, now(), 'manual', "
            "'observed', true) ON CONFLICT (address) DO UPDATE SET active = true", body.address)
        return {"ok": True}

    @app.put("/api/settings", dependencies=[Depends(auth)])
    async def put_settings(body: SettingsUpdate) -> dict:
        old, version = await load_settings(state["pool"])
        try:
            new = Settings.model_validate(body.settings)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(422, str(exc)) from exc
        if new.mode is not Mode.PAPER:
            raise HTTPException(403, "Semi-auto et Live ne sont pas activables : critères go/no-go non atteints.")
        risky = risk_increasing_changes(old, new)
        if risky:
            need_totp(body.totp)
        await state["pool"].execute(
            "INSERT INTO settings_history (version, changed_at, author, settings, risk_increasing, confirmed_with_totp) "
            "VALUES ($1, now(), 'dashboard', $2::jsonb, $3::jsonb, $4)",
            version + 1, json.dumps(new.model_dump(mode="json")), json.dumps(risky), bool(risky))
        await publish("settings.changed", {"version": version + 1})
        return {"ok": True, "version": version + 1, "risk_increasing": risky}

    @app.post("/api/panic", dependencies=[Depends(auth)])
    async def panic() -> dict:
        await publish("system.panic_stop", {})
        return {"ok": True}

    @app.post("/api/resume", dependencies=[Depends(auth)])
    async def resume(body: Totp) -> dict:
        need_totp(body.totp)
        await publish("system.resume", {})
        return {"ok": True}

    return app


def run_api(secrets: Secrets) -> None:
    # Dans le conteneur : 0.0.0.0 ; docker-compose ne publie le port que sur 127.0.0.1 du serveur.
    uvicorn.run(build_app(secrets), host=os.environ.get("CART3R_API_HOST", "127.0.0.1"), port=8080, log_level="info")
