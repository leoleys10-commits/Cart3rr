"""Moteur de décision : assemble sécurité, signal, score et coûts en une intention.

Règle d'exploration (importante et volontaire) :
- tant qu'une stratégie a moins de `MIN_TRADES_FOR_STATS` trades clôturés,
  son espérance nette est INCONNUE. En mode Paper, le bot prend quand même
  les trades qui passent tous les autres filtres, pour la mesurer.
- En Semi-auto et Live, une espérance inconnue ou insuffisante = refus.
"""
from __future__ import annotations

import statistics
import uuid
from dataclasses import dataclass, field

from cart3r.core.config import Mode, Settings

from .fees import CostInputs, OutcomeModel, expected_net_pct, round_trip_cost
from .security import SecurityVerdict, Severity
from .strategies import Signal, opportunity_score

MIN_TRADES_FOR_STATS = 30
RUG_LOSS_THRESHOLD_PCT = -80.0


def estimate_outcome(net_returns_pct: list[float]) -> OutcomeModel | None:
    """Statistiques d'une stratégie à partir de ses trades clôturés (rendements nets en %)."""
    if len(net_returns_pct) < MIN_TRADES_FOR_STATS:
        return None
    n = len(net_returns_pct)
    rugs = [r for r in net_returns_pct if r <= RUG_LOSS_THRESHOLD_PCT]
    wins = [r for r in net_returns_pct if r > 0]
    losses = [r for r in net_returns_pct if RUG_LOSS_THRESHOLD_PCT < r <= 0]
    return OutcomeModel(
        p_win=len(wins) / n,
        avg_gain_pct=statistics.fmean(wins) if wins else 0.0,
        avg_loss_pct=-statistics.fmean(losses) if losses else 0.0,
        p_rug=len(rugs) / n,
        rug_loss_pct=-statistics.fmean(rugs) if rugs else 90.0,
    )


@dataclass(frozen=True)
class Intent:
    mint: str
    strategy: str
    opportunity_score: int
    security_score: int
    stop_pct: float
    liquidity_usd: float
    expected_net_pct: float | None  # None = inconnue (exploration en paper)
    round_trip_cost_pct: float
    exploration: bool
    correlation_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    wallet: str | None = None


@dataclass(frozen=True)
class DecisionResult:
    accepted: bool
    reasons: tuple[str, ...]
    intent: Intent | None
    opportunity_score: int
    expected_net_pct: float | None


def decide(
    *, mint: str, security: SecurityVerdict, signal: Signal, social_score: float | None, settings: Settings,
    costs: CostInputs, strategy_returns: list[float], liquidity_usd: float, wallet: str | None = None,
) -> DecisionResult:
    reasons: list[str] = []
    if security.excluded:
        reasons.extend(f"sécurité : {f.rule}: {f.detail}" for f in security.findings if f.severity is Severity.CRITICAL)
    if not signal.ok:
        reasons.extend(signal.reasons)
    score = opportunity_score(security.score, signal, social_score)
    if score < settings.decision.min_opportunity_score:
        reasons.append(f"score {score} < {settings.decision.min_opportunity_score}")

    cost = round_trip_cost(costs)
    ex = settings.execution
    if cost.total_pct > float(ex.max_round_trip_cost_pct):
        reasons.append(f"coût aller-retour {cost.total_pct:.2f} % > {ex.max_round_trip_cost_pct} %")
    if cost.tip_pct > float(ex.max_tip_pct_of_position):
        reasons.append(f"tip {cost.tip_pct:.2f} % > {ex.max_tip_pct_of_position} %")

    model = estimate_outcome(strategy_returns)
    e_net = expected_net_pct(model, cost) if model else None
    exploration = False
    if e_net is None:
        if settings.mode is Mode.PAPER:
            exploration = True
        else:
            reasons.append(f"espérance non mesurée (moins de {MIN_TRADES_FOR_STATS} trades pour cette stratégie)")
    elif e_net < float(settings.decision.min_expected_net_pct):
        reasons.append(f"espérance nette {e_net:.2f} % < {settings.decision.min_expected_net_pct} %")

    if reasons:
        return DecisionResult(False, tuple(reasons), None, score, e_net)
    intent = Intent(
        mint=mint, strategy=signal.strategy, opportunity_score=score, security_score=security.score,
        stop_pct=float(settings.exits.initial_stop_pct), liquidity_usd=liquidity_usd,
        expected_net_pct=e_net, round_trip_cost_pct=cost.total_pct, exploration=exploration, wallet=wallet,
    )
    return DecisionResult(True, (), intent, score, e_net)
