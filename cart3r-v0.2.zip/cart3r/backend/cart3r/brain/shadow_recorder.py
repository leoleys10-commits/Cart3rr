"""Enregistreur Shadow : transforme les swaps observés en carnets fictifs.

Pour chaque achat d'un wallet observé :
- carnet `wallet` : son fill réel ;
- carnet `copy`   : une quote réelle SOL→token pour NOTRE taille de position,
  demandée au moment où CART3R aurait pu agir ;
- carnet `cart3r` : idem, seulement si `would_accept` (filtres CART3R) dit oui.
Pour chaque vente : on vend au prorata la même fraction dans nos carnets,
avec une quote réelle token→SOL.

La fonction de quote est injectée : en production le client Jupiter, en test
une fausse quote. Si la quote échoue, la jambe devient « non simulable ».
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Awaitable, Callable

from cart3r.solana.tx_parse import SwapEvent

from .shadow import Fill, Leg, LegStatus, ShadowTrade, wallet_sell_fraction

WSOL = "So11111111111111111111111111111111111111112"
LAMPORTS = 1_000_000_000


@dataclass(frozen=True)
class QuoteResult:
    out_amount: int
    fee_lamports: int  # signature + priorité + rente estimées par la quote


QuoteFn = Callable[[str, str, int], Awaitable[QuoteResult]]
AcceptFn = Callable[[SwapEvent], Awaitable[tuple[bool, str | None]]]


class ShadowRecorder:
    def __init__(
        self,
        quote: QuoteFn,
        would_accept: AcceptFn,
        position_lamports: int,
        now: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ) -> None:
        self._quote, self._accept, self._size, self._now = quote, would_accept, position_lamports, now
        self.open: dict[tuple[str, str], ShadowTrade] = {}
        self.closed: list[ShadowTrade] = []

    async def _buy_leg(self, leg: Leg, mint: str) -> None:
        try:
            q = await self._quote(WSOL, mint, self._size)
        except Exception as exc:  # noqa: BLE001
            leg.mark_not_simulable(f"quote d'achat indisponible : {exc}")
            return
        leg.buys.append(Fill(self._now(), q.out_amount, self._size / LAMPORTS, q.fee_lamports / LAMPORTS))

    async def _sell_leg(self, leg: Leg | None, mint: str, fraction: float) -> None:
        if leg is None or leg.status is not LegStatus.OPEN or not leg.buys:
            return
        amount = int(leg.tokens_held * fraction) if fraction < 1.0 else int(leg.tokens_held)
        if amount <= 0:
            return
        try:
            q = await self._quote(mint, WSOL, amount)
        except Exception as exc:  # noqa: BLE001
            leg.mark_not_simulable(f"quote de vente indisponible : {exc}")
            return
        leg.sells.append(Fill(self._now(), amount, q.out_amount / LAMPORTS, q.fee_lamports / LAMPORTS))
        leg.close_if_flat(dust=1.0)

    async def on_swap(self, ev: SwapEvent) -> None:
        key = (ev.wallet, ev.mint)
        if ev.side == "buy":
            trade = self.open.get(key)
            if trade is None:
                trade = ShadowTrade(wallet=ev.wallet, mint=ev.mint)
                self.open[key] = trade
                await self._buy_leg(trade.copy_leg, ev.mint)
                accepted, reason = await self._accept(ev)
                if accepted:
                    trade.cart3r_leg = Leg()
                    await self._buy_leg(trade.cart3r_leg, ev.mint)
                else:
                    trade.cart3r_reject_reason = reason
            # Les achats suivants du wallet (renforcement) ne sont pas copiés en V1.
            trade.wallet_leg.buys.append(
                Fill(ev.block_time, ev.token_amount, ev.sol_lamports / LAMPORTS, ev.fee_lamports / LAMPORTS)
            )
            return

        trade = self.open.get(key)
        if trade is None:
            return  # vente d'une position ouverte avant le début de l'observation
        trade.wallet_leg.sells.append(
            Fill(ev.block_time, ev.token_amount, ev.sol_lamports / LAMPORTS, ev.fee_lamports / LAMPORTS)
        )
        fraction = wallet_sell_fraction(trade, ev.token_amount)
        trade.wallet_leg.close_if_flat(dust=1.0)
        await self._sell_leg(trade.copy_leg, ev.mint, fraction)
        await self._sell_leg(trade.cart3r_leg, ev.mint, fraction)
        if trade.wallet_leg.status is LegStatus.CLOSED:
            del self.open[key]
            self.closed.append(trade)
