"""Construction des mesures de sécurité à partir des données brutes.

Fonctions pures (testables) ; le service `security_service` les alimente
avec les réponses RPC / DexScreener / Jupiter.
"""
from __future__ import annotations

from collections.abc import Iterable


def top10_share_pct(largest_accounts: Iterable[dict], supply: int, excluded_accounts: set[str]) -> float | None:
    """Part du supply détenue par les 10 plus gros comptes, hors pool et bonding curve.

    `largest_accounts` : réponse `getTokenLargestAccounts` ({address, amount}).
    `excluded_accounts` : comptes token du pool / de la bonding curve / brûlés.
    """
    if supply <= 0:
        return None
    holders = [int(a["amount"]) for a in largest_accounts if a["address"] not in excluded_accounts]
    holders.sort(reverse=True)
    return 100.0 * sum(holders[:10]) / supply


def sell_quote_loss_pct(sol_in: int, sol_back: int, platform_fees_pct: float) -> float:
    """Perte d'un aller-retour simulé immédiat, HORS frais de plateforme connus.

    Une perte nettement supérieure aux frais trahit une taxe cachée ou un
    pool truqué.
    """
    if sol_in <= 0:
        raise ValueError("sol_in doit être positif")
    gross_loss = 100.0 * (sol_in - sol_back) / sol_in
    return gross_loss - platform_fees_pct


def wash_volume_share_pct(trades: Iterable[dict], min_round_trips: int = 3) -> float | None:
    """Part du volume faite par des wallets qui font des allers-retours de même taille.

    `trades` : {wallet, side, token_amount, sol_lamports}. Un wallet est suspect
    s'il a au moins `min_round_trips` paires achat/vente de quantités
    identiques (à 1 % près) et ne garde jamais de position.
    """
    trades = list(trades)
    if not trades:
        return None
    by_wallet: dict[str, list[dict]] = {}
    for t in trades:
        by_wallet.setdefault(t["wallet"], []).append(t)
    total = sum(t["sol_lamports"] for t in trades)
    if total <= 0:
        return None
    suspect = 0
    for wallet_trades in by_wallet.values():
        buys = [t["token_amount"] for t in wallet_trades if t["side"] == "buy"]
        sells = [t["token_amount"] for t in wallet_trades if t["side"] == "sell"]
        pairs = 0
        remaining = list(sells)
        for b in buys:
            for i, s in enumerate(remaining):
                if b > 0 and abs(b - s) / b <= 0.01:
                    pairs += 1
                    remaining.pop(i)
                    break
        net = sum(buys) - sum(sells)
        if pairs >= min_round_trips and abs(net) <= 0.01 * max(sum(buys), 1):
            suspect += sum(t["sol_lamports"] for t in wallet_trades)
    return 100.0 * suspect / total
