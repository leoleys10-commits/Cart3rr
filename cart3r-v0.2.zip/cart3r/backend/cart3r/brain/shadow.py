"""Shadow Trading : trois carnets par trade observé.

1. `wallet`   : ce que le wallet observé a réellement fait.
2. `copy`     : copie brute au prix réellement disponible pour CART3R
                (quote demandée au moment où il aurait pu agir).
3. `cart3r`   : seulement si les filtres CART3R auraient accepté.

Règle d'honnêteté : sans quote réelle au bon moment, la jambe est
« non simulable » et n'entre dans aucune statistique.
"""
from __future__ import annotations

import math
import statistics
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class LegStatus(str, Enum):
    OPEN = "open"
    CLOSED = "closed"
    NOT_SIMULABLE = "not_simulable"


@dataclass
class Fill:
    at: datetime
    token_amount: float  # unités du token
    quote_amount_sol: float  # SOL payés (achat) ou reçus (vente), frais de plateforme inclus
    fees_sol: float = 0.0  # frais réseau + tips


@dataclass
class Leg:
    buys: list[Fill] = field(default_factory=list)
    sells: list[Fill] = field(default_factory=list)
    status: LegStatus = LegStatus.OPEN
    note: str = ""

    def mark_not_simulable(self, why: str) -> None:
        self.status, self.note = LegStatus.NOT_SIMULABLE, why

    @property
    def tokens_held(self) -> float:
        return sum(f.token_amount for f in self.buys) - sum(f.token_amount for f in self.sells)

    @property
    def cost_sol(self) -> float:
        return sum(f.quote_amount_sol + f.fees_sol for f in self.buys)

    @property
    def proceeds_sol(self) -> float:
        return sum(f.quote_amount_sol - f.fees_sol for f in self.sells)

    def net_return_pct(self) -> float | None:
        """Rendement net réalisé ; None si ouverte ou non simulable."""
        if self.status is not LegStatus.CLOSED or self.cost_sol <= 0:
            return None
        return 100.0 * (self.proceeds_sol - self.cost_sol) / self.cost_sol

    def close_if_flat(self, dust: float = 1e-9) -> None:
        if self.status is LegStatus.OPEN and self.buys and self.tokens_held <= dust:
            self.status = LegStatus.CLOSED


@dataclass
class ShadowTrade:
    wallet: str
    mint: str
    wallet_leg: Leg = field(default_factory=Leg)
    copy_leg: Leg = field(default_factory=Leg)
    cart3r_leg: Leg | None = None  # None = les filtres CART3R auraient refusé
    cart3r_reject_reason: str | None = None


def wallet_sell_fraction(trade: ShadowTrade, sold_tokens: float) -> float:
    """Part de sa position que le wallet vient de vendre (pour copier au prorata)."""
    held_before = trade.wallet_leg.tokens_held + sold_tokens
    if held_before <= 0:
        return 0.0
    return min(1.0, sold_tokens / held_before)


@dataclass(frozen=True)
class WalletStats:
    n_closed: int
    n_not_simulable: int
    wallet_mean_pct: float | None
    copy_mean_pct: float | None
    imitation_penalty_pct: float | None
    copy_win_rate: float | None
    copy_mean_ci90_low: float | None
    copy_mean_ci90_high: float | None


def _ci90(values: list[float]) -> tuple[float | None, float | None]:
    if len(values) < 2:
        return None, None
    mean = statistics.fmean(values)
    half = 1.645 * statistics.stdev(values) / math.sqrt(len(values))
    return mean - half, mean + half


def wallet_stats(trades: list[ShadowTrade]) -> WalletStats:
    copy_returns: list[float] = []
    wallet_returns: list[float] = []
    not_sim = 0
    for t in trades:
        if t.copy_leg.status is LegStatus.NOT_SIMULABLE:
            not_sim += 1
            continue
        c, w = t.copy_leg.net_return_pct(), t.wallet_leg.net_return_pct()
        if c is not None and w is not None:
            copy_returns.append(c)
            wallet_returns.append(w)
    n = len(copy_returns)
    lo, hi = _ci90(copy_returns)
    return WalletStats(
        n_closed=n,
        n_not_simulable=not_sim,
        wallet_mean_pct=statistics.fmean(wallet_returns) if n else None,
        copy_mean_pct=statistics.fmean(copy_returns) if n else None,
        imitation_penalty_pct=(statistics.fmean(wallet_returns) - statistics.fmean(copy_returns)) if n else None,
        copy_win_rate=(sum(r > 0 for r in copy_returns) / n) if n else None,
        copy_mean_ci90_low=lo,
        copy_mean_ci90_high=hi,
    )


class WalletStatus(str, Enum):
    OBSERVED = "observed"
    COPYABLE = "copyable"
    DEMOTED = "demoted"


def next_status(current: WalletStatus, stats: WalletStats, min_trades: int) -> WalletStatus:
    """Règles de statut de la section 5 bis (phase 1)."""
    if stats.n_closed < min_trades or stats.copy_mean_ci90_low is None:
        return current if current is WalletStatus.DEMOTED else WalletStatus.OBSERVED
    if stats.copy_mean_ci90_high is not None and stats.copy_mean_ci90_high < 0:
        return WalletStatus.DEMOTED
    if stats.copy_mean_ci90_low > 0 and (stats.copy_mean_pct or 0) > 0:
        return WalletStatus.COPYABLE
    return WalletStatus.DEMOTED if current is WalletStatus.COPYABLE else current
