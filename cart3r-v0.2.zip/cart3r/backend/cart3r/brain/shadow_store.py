"""Persistance des carnets shadow dans PostgreSQL."""
from __future__ import annotations

import json

import asyncpg

from .shadow import LegStatus, ShadowTrade


async def save_shadow(pool: asyncpg.Pool, t: ShadowTrade) -> None:
    books = [("wallet", t.wallet_leg), ("copy", t.copy_leg)]
    if t.cart3r_leg is not None:
        books.append(("cart3r", t.cart3r_leg))
    for book, leg in books:
        if not leg.buys:
            continue
        fills = [{"side": s, "at": f.at.isoformat(), "tokens": f.token_amount, "sol": f.quote_amount_sol, "fees": f.fees_sol}
                 for s, lst in (("buy", leg.buys), ("sell", leg.sells)) for f in lst]
        await pool.execute(
            "INSERT INTO shadow_trades (wallet, mint, book, status, note, fills, net_return_pct, opened_at, closed_at) "
            "VALUES ($1,$2,$3,$4,$5,$6::jsonb,$7,$8,$9) ON CONFLICT DO NOTHING",
            t.wallet, t.mint, book, leg.status.value, leg.note or t.cart3r_reject_reason, json.dumps(fills),
            leg.net_return_pct(), leg.buys[0].at,
            leg.sells[-1].at if leg.status is LegStatus.CLOSED and leg.sells else None,
        )
