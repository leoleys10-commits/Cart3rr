"""Security Manager : règles anti-rug et score de sécurité /100.

Principe : une règle « critique » exclut le token quel que soit le score.
Les autres règles retirent des points. Les données manquantes ne sont JAMAIS
supposées favorables : une donnée critique absente = exclusion.

Les seuils sont des hypothèses initiales (phase 1, section 6), calibrées plus
tard sur l'historique.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from cart3r.solana.mint import EXTENSION_NAMES, MintInfo


class Severity(str, Enum):
    CRITICAL = "critical"
    PENALTY = "penalty"


@dataclass(frozen=True)
class Finding:
    rule: str
    severity: Severity
    detail: str
    points: int = 0  # points retirés (pénalités seulement)


@dataclass(frozen=True)
class SecurityInput:
    """Tout ce qui a été mesuré sur le token. `None` = mesure indisponible."""

    mint: MintInfo | None
    metadata_mutable: bool | None
    top10_share_pct: float | None  # hors pool / bonding curve
    creator_cluster_share_pct: float | None
    bundled_share_pct: float | None  # achats du bloc de création + 5 premiers slots
    deployer_flagged: bool | None
    liquidity_usd: float | None
    planned_position_usd: float
    sell_quote_ok: bool | None
    sell_quote_loss_pct: float | None  # perte hors frais sur l'aller-retour simulé
    wash_volume_share_pct: float | None


@dataclass(frozen=True)
class SecurityThresholds:
    top10_exclude_pct: float = 30.0
    top10_penalty_pct: float = 15.0
    creator_cluster_exclude_pct: float = 10.0
    bundled_exclude_pct: float = 15.0
    max_position_share_of_liquidity_pct: float = 1.0
    max_sell_quote_loss_pct: float = 5.0
    wash_exclude_pct: float = 40.0
    wash_penalty_pct: float = 20.0


@dataclass(frozen=True)
class SecurityVerdict:
    excluded: bool
    score: int
    findings: tuple[Finding, ...] = field(default_factory=tuple)

    @property
    def reasons(self) -> list[str]:
        return [f"{f.rule}: {f.detail}" for f in self.findings]


def evaluate(inp: SecurityInput, th: SecurityThresholds = SecurityThresholds()) -> SecurityVerdict:
    out: list[Finding] = []

    def crit(rule: str, detail: str) -> None:
        out.append(Finding(rule, Severity.CRITICAL, detail))

    def pen(rule: str, detail: str, points: int) -> None:
        out.append(Finding(rule, Severity.PENALTY, detail, points))

    # --- Autorités et extensions du mint (lecture on-chain obligatoire) ---
    if inp.mint is None:
        crit("mint_unreadable", "compte mint non lu : impossible de vérifier les autorités")
    else:
        m = inp.mint
        if not m.is_initialized:
            crit("mint_not_initialized", "mint non initialisé")
        if m.mint_authority is not None:
            crit("mint_authority_active", f"autorité de mint active ({m.mint_authority})")
        if m.freeze_authority is not None:
            crit("freeze_authority_active", f"autorité de gel active ({m.freeze_authority})")
        for ext in m.unsafe_extensions:
            crit("token2022_extension", f"extension non autorisée : {EXTENSION_NAMES.get(ext, ext)}")

    # --- Métadonnées ---
    if inp.metadata_mutable is None:
        pen("metadata_unknown", "mutabilité des métadonnées inconnue", 5)
    elif inp.metadata_mutable:
        pen("metadata_mutable", "métadonnées modifiables", 5)

    # --- Distribution ---
    if inp.top10_share_pct is None:
        crit("holders_unknown", "répartition des holders indisponible")
    elif inp.top10_share_pct > th.top10_exclude_pct:
        crit("concentration", f"top 10 = {inp.top10_share_pct:.1f} % (> {th.top10_exclude_pct} %)")
    elif inp.top10_share_pct > th.top10_penalty_pct:
        pen("concentration", f"top 10 = {inp.top10_share_pct:.1f} %", 15)

    if inp.creator_cluster_share_pct is None:
        crit("creator_cluster_unknown", "cluster créateur non analysé")
    elif inp.creator_cluster_share_pct > th.creator_cluster_exclude_pct:
        crit("creator_cluster", f"wallets liés au créateur = {inp.creator_cluster_share_pct:.1f} %")

    if inp.bundled_share_pct is None:
        pen("bundles_unknown", "achats groupés non analysés", 10)
    elif inp.bundled_share_pct > th.bundled_exclude_pct:
        crit("bundles", f"part achetée en bundle = {inp.bundled_share_pct:.1f} %")
    elif inp.bundled_share_pct > th.bundled_exclude_pct / 2:
        pen("bundles", f"part achetée en bundle = {inp.bundled_share_pct:.1f} %", 10)

    if inp.deployer_flagged is None:
        pen("deployer_unknown", "historique du déployeur inconnu", 5)
    elif inp.deployer_flagged:
        crit("deployer_flagged", "le déployeur a déjà lancé des rugs")

    # --- Liquidité et vendabilité ---
    if inp.liquidity_usd is None or inp.liquidity_usd <= 0:
        crit("liquidity_unknown", "liquidité indisponible ou nulle")
    else:
        share = 100.0 * inp.planned_position_usd / inp.liquidity_usd
        if share > th.max_position_share_of_liquidity_pct:
            crit("liquidity_too_thin", f"la position représenterait {share:.2f} % de la liquidité")

    if inp.sell_quote_ok is not True:
        crit("not_sellable", "quote de vente impossible ou non testée")
    elif inp.sell_quote_loss_pct is None or inp.sell_quote_loss_pct > th.max_sell_quote_loss_pct:
        crit("sell_tax", f"perte à la revente simulée = {inp.sell_quote_loss_pct}")

    # --- Wash trading ---
    if inp.wash_volume_share_pct is None:
        pen("wash_unknown", "wash trading non analysé", 10)
    elif inp.wash_volume_share_pct > th.wash_exclude_pct:
        crit("wash_trading", f"volume suspect = {inp.wash_volume_share_pct:.1f} %")
    elif inp.wash_volume_share_pct > th.wash_penalty_pct:
        pen("wash_trading", f"volume suspect = {inp.wash_volume_share_pct:.1f} %", 15)

    excluded = any(f.severity is Severity.CRITICAL for f in out)
    score = max(0, 100 - sum(f.points for f in out))
    if excluded:
        score = 0
    return SecurityVerdict(excluded=excluded, score=score, findings=tuple(out))
