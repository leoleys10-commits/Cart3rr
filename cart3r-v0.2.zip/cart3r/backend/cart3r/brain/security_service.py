"""Collecte des mesures de sécurité pour un token (réseau) → `SecurityInput`.

V1 — ce qui est mesuré et comment :
- autorités et extensions : lecture brute du compte mint (RPC) ;
- top 10 : getTokenLargestAccounts, hors comptes détenus par le pool ;
- vendabilité / taxe : aller-retour simulé via deux quotes Jupiter ;
- cluster créateur et historique du déployeur : rapport RugCheck
  (champs lus défensivement ; champ absent = mesure manquante = exclusion) ;
- bundles et wash trading : NON mesurés en V1 → pénalité (jamais supposés bons).
"""
from __future__ import annotations

import logging

from cart3r.solana.mint import MintParseError, parse_mint

from .security import SecurityInput
from .security_inputs import sell_quote_loss_pct, top10_share_pct

log = logging.getLogger(__name__)
WSOL = "So11111111111111111111111111111111111111112"
ASSUMED_PLATFORM_FEES_ROUND_TRIP_PCT = 2.5


def rugcheck_insights(report: dict | None) -> tuple[float | None, bool | None]:
    """(part du cluster créateur %, déployeur signalé) depuis un rapport RugCheck."""
    if not report:
        return None, None
    insiders = report.get("graphInsidersDetected")
    cluster: float | None
    if isinstance(insiders, (int, float)):
        cluster = 0.0 if insiders == 0 else 100.0  # réseau d'initiés détecté : exclusion
    else:
        cluster = None
    risks = report.get("risks")
    flagged: bool | None = None
    if isinstance(risks, list):
        flagged = any(
            isinstance(r, dict) and "rug" in str(r.get("name", "")).lower() and r.get("level") == "danger"
            for r in risks
        )
    return cluster, flagged


async def collect(*, mint: str, rpc, jupiter, rugcheck, pair_address: str | None, liquidity_usd: float | None,
                  position_lamports: int, sol_usd: float) -> SecurityInput:
    mint_info = None
    try:
        acc = (await rpc.account_info(mint)).value
        if acc is not None:
            data, owner = acc
            mint_info = parse_mint(data, owner)
    except (MintParseError, Exception) as exc:  # noqa: BLE001
        log.warning("mint %s illisible : %s", mint, exc)

    top10 = None
    if mint_info is not None:
        try:
            largest = (await rpc.largest_token_accounts(mint)).value
            owners = (await rpc.token_account_owners([a["address"] for a in largest])).value
            excluded = {a for a, o in owners.items() if pair_address and o == pair_address}
            top10 = top10_share_pct(largest, mint_info.supply, excluded)
        except Exception as exc:  # noqa: BLE001
            log.warning("holders de %s indisponibles : %s", mint, exc)

    sell_ok, sell_loss = None, None
    try:
        buy = (await jupiter.quote(WSOL, mint, position_lamports, 300)).value
        back = (await jupiter.quote(mint, WSOL, int(buy["outAmount"]), 300)).value
        sell_ok = int(back["outAmount"]) > 0
        sell_loss = sell_quote_loss_pct(position_lamports, int(back["outAmount"]), ASSUMED_PLATFORM_FEES_ROUND_TRIP_PCT)
    except Exception as exc:  # noqa: BLE001
        log.info("aller-retour simulé impossible pour %s : %s", mint, exc)
        sell_ok = False

    report = None
    try:
        report = (await rugcheck.report(mint)).value
    except Exception as exc:  # noqa: BLE001
        log.info("RugCheck indisponible pour %s : %s", mint, exc)
    cluster, flagged = rugcheck_insights(report)

    return SecurityInput(
        mint=mint_info, metadata_mutable=None, top10_share_pct=top10, creator_cluster_share_pct=cluster,
        bundled_share_pct=None, deployer_flagged=flagged, liquidity_usd=liquidity_usd,
        planned_position_usd=position_lamports / 1e9 * sol_usd, sell_quote_ok=sell_ok,
        sell_quote_loss_pct=sell_loss, wash_volume_share_pct=None,
    )
