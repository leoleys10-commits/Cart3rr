"""Capital Protection Engine.

Tout est compté en lamports (SOL). Les limites sont des pourcentages du
capital de référence, fixé au démarrage à partir du plafond en euros.
Le garde-fou ne peut que refuser ou réduire ; il n'augmente jamais une taille.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime

from cart3r.core.config import Settings

LAMPORTS = 1_000_000_000


@dataclass
class GuardState:
    reference_lamports: int  # capital de référence (plafond)
    cash_lamports: int  # SOL disponibles (réserve incluse)
    reserve_lamports: int
    open_positions: dict[str, int] = field(default_factory=dict)  # id -> valeur marquée
    day: date | None = None
    day_start_equity: int = 0
    week: tuple[int, int] | None = None
    week_start_equity: int = 0
    buys_today: int = 0
    halted_reason: str | None = None  # arrêt qui exige ta reprise
    paused_until_period: str | None = None  # "day" | "week" : reprise automatique
    panic: bool = False

    @property
    def equity(self) -> int:
        return self.cash_lamports + sum(self.open_positions.values())

    def to_json(self) -> dict:
        return {
            "reference_lamports": self.reference_lamports, "cash_lamports": self.cash_lamports,
            "reserve_lamports": self.reserve_lamports, "open_positions": self.open_positions,
            "day": self.day.isoformat() if self.day else None, "day_start_equity": self.day_start_equity,
            "week": list(self.week) if self.week else None, "week_start_equity": self.week_start_equity,
            "buys_today": self.buys_today, "halted_reason": self.halted_reason,
            "paused_until_period": self.paused_until_period, "panic": self.panic,
        }

    @classmethod
    def from_json(cls, d: dict) -> "GuardState":
        d = dict(d)
        d["day"] = date.fromisoformat(d["day"]) if d.get("day") else None
        d["week"] = tuple(d["week"]) if d.get("week") else None
        return cls(**d)


@dataclass(frozen=True)
class SizeDecision:
    approved: bool
    lamports: int
    reasons: tuple[str, ...]


class CapitalGuard:
    def __init__(self, settings: Settings, state: GuardState) -> None:
        self.s, self.st = settings, state

    @classmethod
    def fresh(cls, settings: Settings, eur_per_sol: float, start_lamports: int | None = None) -> "CapitalGuard":
        ref = int(float(settings.capital.cap_eur) / eur_per_sol * LAMPORTS)
        reserve = int(float(settings.capital.reserve_eur) / eur_per_sol * LAMPORTS)
        cash = ref if start_lamports is None else min(start_lamports, ref)  # jamais plus que le plafond
        return cls(settings, GuardState(reference_lamports=ref, cash_lamports=cash, reserve_lamports=reserve))

    # ---------- périodes et limites ----------

    def roll_periods(self, now: datetime) -> None:
        st = self.st
        if st.day != now.date():
            st.day, st.day_start_equity, st.buys_today = now.date(), st.equity, 0
            if st.paused_until_period == "day":
                st.paused_until_period = None
        iso = now.isocalendar()
        week = (iso[0], iso[1])
        if st.week != week:
            st.week, st.week_start_equity = week, st.equity
            if st.paused_until_period in ("day", "week"):
                st.paused_until_period = None

    def check_limits(self) -> list[str]:
        """Met à jour les arrêts et renvoie les alertes nouvellement déclenchées."""
        st, r = self.st, self.s.risk
        ref = st.reference_lamports
        alerts: list[str] = []
        dd = 100.0 * (ref - st.equity) / ref
        if dd >= float(r.max_drawdown_pct) and st.halted_reason is None:
            st.halted_reason = f"drawdown {dd:.1f} % ≥ {r.max_drawdown_pct} %"
            alerts.append(st.halted_reason)
        week_loss = 100.0 * (st.week_start_equity - st.equity) / ref
        if week_loss >= float(r.weekly_loss_pct) and st.paused_until_period != "week":
            st.paused_until_period = "week"
            alerts.append(f"perte de la semaine {week_loss:.1f} % ≥ {r.weekly_loss_pct} %")
        day_loss = 100.0 * (st.day_start_equity - st.equity) / ref
        if day_loss >= float(r.daily_loss_pct) and st.paused_until_period is None:
            st.paused_until_period = "day"
            alerts.append(f"perte du jour {day_loss:.1f} % ≥ {r.daily_loss_pct} %")
        return alerts

    def can_buy(self) -> list[str]:
        st, reasons = self.st, []
        if st.panic:
            reasons.append("PANIC STOP actif")
        if st.halted_reason:
            reasons.append(f"trading arrêté : {st.halted_reason} (reprise manuelle requise)")
        if st.paused_until_period:
            reasons.append(f"achats suspendus jusqu'à la prochaine période ({st.paused_until_period})")
        if len(st.open_positions) >= self.s.positions.max_open_positions:
            reasons.append(f"{len(st.open_positions)} positions ouvertes (max {self.s.positions.max_open_positions})")
        if st.buys_today >= self.s.decision.max_buys_per_day:
            reasons.append(f"{st.buys_today} achats aujourd'hui (max {self.s.decision.max_buys_per_day})")
        return reasons

    # ---------- taille de position ----------

    def size(self, *, stop_pct: float, eur_per_sol: float, liquidity_usd: float, sol_usd: float) -> SizeDecision:
        reasons = self.can_buy()
        if reasons:
            return SizeDecision(False, 0, tuple(reasons))
        eur = lambda lamports: lamports / LAMPORTS * eur_per_sol  # noqa: E731
        to_lamports = lambda e: int(e / eur_per_sol * LAMPORTS)  # noqa: E731

        # Le risque se calcule sur min(référence, capital réel) : il baisse après une perte, jamais l'inverse.
        base = min(self.st.reference_lamports, self.st.equity)
        risk_lamports = base * float(self.s.risk.risk_normal_pct) / 100
        size = int(risk_lamports / (stop_pct / 100))
        # Si la taille issue du risque normal est sous le minimum d'achat, on monte au minimum
        # seulement si le risque reste ≤ au risque MAXIMAL autorisé.
        min_size = to_lamports(float(self.s.positions.min_buy_eur))
        if size < min_size and min_size * stop_pct / 100 <= base * float(self.s.risk.risk_max_pct) / 100:
            size = min_size
        size = min(size, to_lamports(float(self.s.positions.max_buy_eur)))
        liquidity_cap = int(liquidity_usd * 0.01 / sol_usd * LAMPORTS)
        size = min(size, liquidity_cap)
        spendable = self.st.cash_lamports - self.st.reserve_lamports
        size = min(size, spendable)
        if eur(size) < float(self.s.positions.min_buy_eur):
            return SizeDecision(False, 0, (f"taille possible {eur(size):.2f} € < minimum {self.s.positions.min_buy_eur} €",))
        return SizeDecision(True, size, ())

    # ---------- mouvements ----------

    def on_buy(self, position_id: str, cost_lamports: int) -> None:
        self.st.cash_lamports -= cost_lamports
        self.st.open_positions[position_id] = cost_lamports
        self.st.buys_today += 1

    def mark(self, position_id: str, value_lamports: int) -> None:
        if position_id in self.st.open_positions:
            self.st.open_positions[position_id] = value_lamports

    def on_sell(self, position_id: str, proceeds_lamports: int, remaining_value_lamports: int) -> None:
        self.st.cash_lamports += proceeds_lamports
        if remaining_value_lamports <= 0:
            self.st.open_positions.pop(position_id, None)
        else:
            self.st.open_positions[position_id] = remaining_value_lamports

    def resume(self) -> None:
        """Reprise manuelle après un arrêt (drawdown ou panic). Ne touche pas aux pauses journalières."""
        self.st.halted_reason, self.st.panic = None, False
