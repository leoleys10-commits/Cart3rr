"""Processus `guard` : seul détenteur de l'état du capital.

- `trade.intent` → taille de position → `order.approved` ou `order.rejected`
- `order.filled` → mise à jour du cash et des positions
- toutes les 30 s : valorisation des positions, contrôle des limites, alertes
- `system.panic_stop` / `system.resume` : arrêt et reprise
NON TESTÉ EN RÉSEAU (câblage) ; la logique est dans `capital.py`, testée.
"""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone

import httpx

from cart3r.core.config import Secrets
from cart3r.core.events import Event
from cart3r.core.runtime import alert, create_pool, load_settings
from cart3r.db.event_store import PostgresEventBus
from cart3r.sources.clients import PriceFeed

from .capital import CapitalGuard, GuardState

log = logging.getLogger(__name__)


class Guard:
    def __init__(self, pool, bus, prices) -> None:
        self.pool, self.bus, self.prices = pool, bus, prices
        self.g: CapitalGuard | None = None
        self._lock = asyncio.Lock()

    async def start(self) -> None:
        settings, _ = await load_settings(self.pool)
        row = await self.pool.fetchval("SELECT state FROM guard_state WHERE id = 1")
        if row:
            self.g = CapitalGuard(settings, GuardState.from_json(json.loads(row) if isinstance(row, str) else row))
        else:
            sol_eur, _ = (await self.prices.sol()).value  # pas de cours = pas de démarrage
            self.g = CapitalGuard.fresh(settings, eur_per_sol=sol_eur)
            await alert(self.bus, "info", "start",
                        f"Capital paper initialisé : {settings.capital.cap_eur} € = "
                        f"{self.g.st.reference_lamports / 1e9:.4f} SOL au cours de {sol_eur:.2f} €")
        await self.save()

    async def save(self) -> None:
        await self.pool.execute(
            "INSERT INTO guard_state (id, state, updated_at) VALUES (1, $1::jsonb, now()) "
            "ON CONFLICT (id) DO UPDATE SET state = EXCLUDED.state, updated_at = now()",
            json.dumps(self.g.st.to_json()))

    async def refresh(self) -> None:
        rows = await self.pool.fetch("SELECT id, last_value_lamports FROM positions WHERE state <> 'closed'")
        for r in rows:
            if r["last_value_lamports"] is not None:
                self.g.mark(r["id"], int(r["last_value_lamports"]))
        self.g.roll_periods(datetime.now(timezone.utc))
        for msg in self.g.check_limits():
            await self.bus.publish(Event(type="risk.limit_hit", source="guard", observed_at=datetime.now(timezone.utc),
                                         payload={"message": msg}))
            await alert(self.bus, "critical", "limit", f"Limite atteinte : {msg}. Nouveaux achats bloqués.")

    async def on_intent(self, ev: Event) -> None:
        async with self._lock:
            await self.refresh()
            p = ev.payload
            try:
                sol_eur, sol_usd = (await self.prices.sol()).value
            except Exception as exc:  # noqa: BLE001
                return await self._reject(ev, [f"cours du SOL indisponible : {exc}"])
            d = self.g.size(stop_pct=float(p["stop_pct"]), eur_per_sol=sol_eur,
                            liquidity_usd=float(p.get("liquidity_usd") or 0), sol_usd=sol_usd)
            if not d.approved:
                return await self._reject(ev, list(d.reasons))
            await self.bus.publish(Event(
                type="order.approved", source="guard", observed_at=datetime.now(timezone.utc),
                correlation_id=ev.correlation_id, idempotency_key=f"approved:{ev.correlation_id}",
                payload={**p, "lamports": d.lamports, "mode": self.g.s.mode.value},
            ))
            await self.save()

    async def _reject(self, ev: Event, reasons: list[str]) -> None:
        await self.pool.execute(
            "UPDATE decisions SET accepted = false, reasons = reasons || $2::jsonb WHERE correlation_id = $1",
            ev.correlation_id, json.dumps([f"guard : {r}" for r in reasons]))
        await self.bus.publish(Event(type="order.rejected", source="guard", observed_at=datetime.now(timezone.utc),
                                     correlation_id=ev.correlation_id, payload={"reasons": reasons}))

    async def on_filled(self, ev: Event) -> None:
        async with self._lock:
            p = ev.payload
            if p["side"] == "buy":
                self.g.on_buy(p["position_id"], int(p["lamports"]))
            else:
                self.g.on_sell(p["position_id"], int(p["lamports"]), int(p.get("remaining_value_lamports", 0)))
            await self.save()

    async def on_panic(self, _: Event) -> None:
        async with self._lock:
            self.g.st.panic = True
            await self.save()

    async def on_resume(self, _: Event) -> None:
        async with self._lock:
            self.g.resume()
            await self.save()

    async def on_settings(self, _: Event) -> None:
        async with self._lock:
            self.g.s, _v = await load_settings(self.pool)

    async def loop(self) -> None:
        while True:
            try:
                async with self._lock:
                    await self.refresh()
                    await self.save()
            except Exception as exc:  # noqa: BLE001
                log.warning("contrôle périodique en échec : %s", exc)
            await asyncio.sleep(30)


async def run_guard(secrets: Secrets) -> None:
    pool = await create_pool(secrets)
    bus = PostgresEventBus(pool, consumer="guard")
    async with httpx.AsyncClient(timeout=10) as http:
        guard = Guard(pool, bus, PriceFeed(http))
        await guard.start()
        bus.subscribe("trade.intent", guard.on_intent)
        bus.subscribe("order.filled", guard.on_filled)
        bus.subscribe("system.panic_stop", guard.on_panic)
        bus.subscribe("system.resume", guard.on_resume)
        bus.subscribe("settings.changed", guard.on_settings)
        await asyncio.gather(bus.run(), guard.loop())
