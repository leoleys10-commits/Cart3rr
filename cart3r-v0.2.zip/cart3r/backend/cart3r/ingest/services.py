"""Services d'ingestion (processus `ingest`).

- TokenDetector : WebSocket `logsSubscribe` sur les programmes Pump.fun et
  PumpSwap ; repère créations et graduations, publie `token.created` /
  `token.graduated`.
- SmartMoneyTracker : interroge les signatures des wallets observés
  (compatible offre gratuite ; WebSocket par wallet en option plus tard),
  parse les swaps, publie `wallet.trade`.
- MarketScanner : rafraîchit DexScreener (secours GeckoTerminal) pour les
  tokens suivis, publie `market.tick`.

NON TESTÉ EN RÉSEAU ici. Les identifiants de programmes et les libellés de
logs sont à confirmer sur mainnet en phase 7 (test d'intégration dédié).
"""
from __future__ import annotations

import asyncio
import json
import logging

import websockets

from cart3r.core.events import Event, EventBus
from cart3r.solana.pump import PUMP_FUN_PROGRAM, classify_logs
from cart3r.solana.tx_parse import parse_swap
from cart3r.sources.base import DataUnavailable, FallbackSource
from cart3r.sources.clients import DexScreener, SolanaRpc

log = logging.getLogger(__name__)

class TokenDetector:
    def __init__(self, ws_url: str, rpc: FallbackSource, bus: EventBus) -> None:
        self._ws_url, self._rpc, self._bus = ws_url, rpc, bus

    async def run(self) -> None:
        backoff = 1.0
        while True:
            try:
                async with websockets.connect(self._ws_url, ping_interval=20) as ws:
                    await ws.send(json.dumps({
                        "jsonrpc": "2.0", "id": 1, "method": "logsSubscribe",
                        "params": [{"mentions": [PUMP_FUN_PROGRAM]}, {"commitment": "confirmed"}],
                    }))
                    backoff = 1.0
                    async for raw in ws:
                        msg = json.loads(raw)
                        value = msg.get("params", {}).get("result", {}).get("value")
                        if not value or value.get("err") is not None:
                            continue
                        kind = classify_logs(value.get("logs", []))
                        if kind:
                            asyncio.create_task(self._handle(kind, value["signature"]))
            except Exception as exc:  # noqa: BLE001
                log.warning("WebSocket Pump.fun coupé (%s), reconnexion dans %.0fs", exc, backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 60)

    async def _handle(self, kind: str, signature: str) -> None:
        try:
            fresh = await self._rpc.get(signature)  # FallbackSource sur SolanaRpc.transaction
        except DataUnavailable as exc:
            log.warning("transaction %s illisible : %s", signature, exc)
            return
        tx = fresh.value
        if not tx:
            return
        mints = {b["mint"] for b in (tx["meta"].get("postTokenBalances") or [])}
        mints.discard("So11111111111111111111111111111111111111112")
        if len(mints) > 1:
            # Une migration crée aussi le jeton LP du pool : on garde le mint Pump.fun (suffixe « pump »).
            pump = {m for m in mints if m.endswith("pump")}
            mints = pump if len(pump) == 1 else mints
        if len(mints) != 1:
            log.info("transaction %s : mint ambigu %s", signature, sorted(mints))
            return
        mint = mints.pop()
        await self._bus.publish(Event(
            type=f"token.{kind}", source="helius", observed_at=fresh.observed_at,
            payload={"mint": mint, "signature": signature, "slot": tx.get("slot")},
            idempotency_key=f"{kind}:{mint}",
        ))


class SmartMoneyTracker:
    def __init__(self, rpc: SolanaRpc, bus: EventBus, wallets: list[str], poll_s: float = 3.0) -> None:
        self._rpc, self._bus, self._poll_s = rpc, bus, poll_s
        self.wallets = list(wallets)
        self._last_sig: dict[str, str | None] = {w: None for w in wallets}

    async def poll_once(self, wallet: str) -> int:
        sigs = (await self._rpc.signatures_for_address(wallet, limit=20)).value
        last = self._last_sig.get(wallet)
        if last is None:  # premier passage : on se cale sans rejouer l'historique
            self._last_sig[wallet] = sigs[0]["signature"] if sigs else None
            return 0
        new = []
        for s in sigs:
            if s["signature"] == last:
                break
            if s.get("err") is None:
                new.append(s["signature"])
        if sigs:
            self._last_sig[wallet] = sigs[0]["signature"]
        published = 0
        for sig in reversed(new):  # ordre chronologique
            tx = (await self._rpc.transaction(sig)).value
            if not tx:
                continue
            ev = parse_swap(tx, wallet, sig)
            if ev is None:
                continue
            published += await self._bus.publish(Event(
                type="wallet.trade", source=self._rpc.name, observed_at=ev.block_time,
                payload={"wallet": ev.wallet, "mint": ev.mint, "side": ev.side,
                         "token_amount": ev.token_amount, "sol_lamports": ev.sol_lamports,
                         "fee_lamports": ev.fee_lamports, "slot": ev.slot, "signature": sig},
                idempotency_key=f"wtrade:{sig}:{wallet}",
            ))
        return published

    async def run(self) -> None:
        while True:
            for w in list(self.wallets):
                try:
                    await self.poll_once(w)
                except Exception as exc:  # noqa: BLE001
                    log.warning("suivi du wallet %s en échec : %s", w, exc)
            await asyncio.sleep(self._poll_s)


class MarketScanner:
    def __init__(self, dex: DexScreener, bus: EventBus, poll_s: float = 10.0) -> None:
        self._dex, self._bus, self._poll_s = dex, bus, poll_s
        self.tracked: set[str] = set()

    async def run(self) -> None:
        while True:
            mints = sorted(self.tracked)
            for i in range(0, len(mints), 30):
                try:
                    fresh = await self._dex.tokens(mints[i : i + 30])
                except Exception as exc:  # noqa: BLE001
                    log.warning("DexScreener indisponible : %s", exc)
                    continue
                for pair in fresh.value:
                    await self._bus.publish(Event(
                        type="market.tick", source="dexscreener", observed_at=fresh.observed_at,
                        payload={
                            "mint": pair.get("baseToken", {}).get("address"),
                            "pair": pair.get("pairAddress"), "dex": pair.get("dexId"),
                            "price_usd": pair.get("priceUsd"), "liquidity_usd": (pair.get("liquidity") or {}).get("usd"),
                            "market_cap": pair.get("marketCap"), "volume": pair.get("volume"),
                            "txns": pair.get("txns"), "price_change": pair.get("priceChange"),
                            "raw": pair,
                        },
                    ))
            await asyncio.sleep(self._poll_s)
