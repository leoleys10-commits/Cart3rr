"""Exécution simulée (mode Paper) sur des quotes réelles.

Pour rester honnête, chaque fill :
- attend la latence d'exécution mesurée/configurée, puis demande une NOUVELLE
  quote (le prix a pu bouger entre la décision et l'envoi) ;
- retire un glissement supplémentaire configurable (défaut 0,5 %) ;
- compte les frais réseau annoncés par la quote, plus la rente du compte
  token (récupérée à la fermeture) ;
- échoue si la quote échoue : pas de fill inventé.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Awaitable, Callable

from cart3r.brain.shadow_recorder import QuoteResult

WSOL = "So11111111111111111111111111111111111111112"
TOKEN_ACCOUNT_RENT = 2_039_280
CLOSE_ACCOUNT_FEE = 5_000


class PaperFillError(RuntimeError):
    pass


@dataclass(frozen=True)
class PaperFill:
    side: str
    tokens: int
    lamports: int  # coût total (achat) ou produit net (vente)
    fee_lamports: int


QuoteFn = Callable[[str, str, int], Awaitable[QuoteResult]]


class PaperBroker:
    def __init__(self, quote: QuoteFn, latency_s: float = 1.5, extra_slippage_pct: float = 0.5,
                 sleep: Callable[[float], Awaitable[None]] = asyncio.sleep) -> None:
        self._quote, self._latency, self._slip, self._sleep = quote, latency_s, extra_slippage_pct, sleep

    async def buy(self, mint: str, lamports: int, *, new_token_account: bool = True) -> PaperFill:
        await self._sleep(self._latency)
        try:
            q = await self._quote(WSOL, mint, lamports)
        except Exception as exc:  # noqa: BLE001
            raise PaperFillError(f"quote d'achat indisponible : {exc}") from exc
        tokens = int(q.out_amount * (1 - self._slip / 100))
        if tokens <= 0:
            raise PaperFillError("quote d'achat vide")
        rent = TOKEN_ACCOUNT_RENT if new_token_account else 0
        return PaperFill("buy", tokens, lamports + q.fee_lamports + rent, q.fee_lamports)

    async def sell(self, mint: str, tokens: int, *, closes_position: bool) -> PaperFill:
        await self._sleep(self._latency)
        try:
            q = await self._quote(mint, WSOL, tokens)
        except Exception as exc:  # noqa: BLE001
            raise PaperFillError(f"quote de vente indisponible : {exc}") from exc
        out = int(q.out_amount * (1 - self._slip / 100))
        refund = TOKEN_ACCOUNT_RENT - CLOSE_ACCOUNT_FEE if closes_position else 0
        return PaperFill("sell", tokens, out - q.fee_lamports + refund, q.fee_lamports)

    async def value(self, mint: str, tokens: int) -> int:
        """Valeur de revente actuelle (sans latence), pour le suivi des positions."""
        q = await self._quote(mint, WSOL, tokens)
        return max(0, int(q.out_amount) - q.fee_lamports)
