"""Exit Strategy Engine : décide quoi vendre, à partir de la valeur de revente réelle.

`ratio` = valeur actuelle de ce qu'il reste (quote de vente) / coût de ce qu'il
reste. Un stop ne garantit jamais le prix : la décision est prise sur la
quote, l'exécution peut glisser.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta


@dataclass
class ExitPlan:
    stop_pct: float  # ex. 25 => sortie à -25 %
    take_profits: list[tuple[float, float]]  # (gain %, part de la position INITIALE vendue %)
    trailing_pct: float  # depuis le plus haut, actif après le premier palier
    max_hold: timedelta = timedelta(hours=24)
    done_levels: list[int] = field(default_factory=list)
    peak_ratio: float = 1.0
    sold_fraction: float = 0.0  # part de la position initiale déjà vendue

    def to_json(self) -> dict:
        d = asdict(self)
        d["max_hold"] = self.max_hold.total_seconds()
        return d

    @classmethod
    def from_json(cls, d: dict) -> "ExitPlan":
        d = dict(d)
        d["max_hold"] = timedelta(seconds=d["max_hold"])
        d["take_profits"] = [tuple(x) for x in d["take_profits"]]
        return cls(**d)


@dataclass(frozen=True)
class ExitAction:
    fraction_of_remaining: float  # 0 < f <= 1
    reason: str
    emergency: bool = False


@dataclass(frozen=True)
class RiskFlags:
    security_alert: str | None = None
    liquidity_drop_pct: float | None = None  # baisse depuis l'entrée
    followed_wallet_sold_fraction: float | None = None  # pour smart_money_swing
    unsellable: bool = False


LIQUIDITY_EMERGENCY_PCT = 30.0


def evaluate(plan: ExitPlan, ratio: float, opened_at: datetime, now: datetime, flags: RiskFlags = RiskFlags()) -> ExitAction | None:
    """Renvoie l'action à exécuter maintenant (une seule à la fois), ou None."""
    plan.peak_ratio = max(plan.peak_ratio, ratio)

    if flags.unsellable:
        return None  # rien à faire : la position passe en « Bloquée », réessais périodiques
    if flags.security_alert:
        return ExitAction(1.0, f"urgence sécurité : {flags.security_alert}", emergency=True)
    if flags.liquidity_drop_pct is not None and flags.liquidity_drop_pct >= LIQUIDITY_EMERGENCY_PCT:
        return ExitAction(1.0, f"urgence liquidité : -{flags.liquidity_drop_pct:.0f} %", emergency=True)
    if ratio <= 1 - plan.stop_pct / 100:
        return ExitAction(1.0, f"stop loss ({(ratio - 1) * 100:+.1f} %)")
    if plan.done_levels and ratio <= plan.peak_ratio * (1 - plan.trailing_pct / 100):
        return ExitAction(1.0, f"trailing stop ({(ratio - 1) * 100:+.1f} %, plus haut {(plan.peak_ratio - 1) * 100:+.1f} %)")
    if flags.followed_wallet_sold_fraction:
        f = min(1.0, flags.followed_wallet_sold_fraction)
        return ExitAction(f, f"le wallet suivi a vendu {f * 100:.0f} % de sa position")
    for i, (gain, part) in enumerate(plan.take_profits):
        if i in plan.done_levels or ratio < 1 + gain / 100:
            continue
        remaining = 1.0 - plan.sold_fraction
        if remaining <= 0:
            return None
        return ExitAction(min(1.0, (part / 100) / remaining), f"prise de profit palier {i + 1} (+{gain:.0f} %)")
    if now - opened_at >= plan.max_hold:
        return ExitAction(1.0, f"durée maximale atteinte ({plan.max_hold})")
    return None


def apply(plan: ExitPlan, action: ExitAction) -> None:
    """À appeler APRÈS confirmation de la vente."""
    remaining = 1.0 - plan.sold_fraction
    plan.sold_fraction += remaining * action.fraction_of_remaining
    if action.reason.startswith("prise de profit palier"):
        level = int(action.reason.split("palier ")[1].split(" ")[0]) - 1
        plan.done_levels.append(level)
