"""Configuration CART3R.

Deux familles de valeurs :
- `Settings` : réglages métier modifiables par l'utilisateur (page Settings),
  validés ici. Le bot ne fait que les LIRE ; seule l'API authentifiée peut les écrire.
- `Secrets` : clés API, mots de passe, chemin du keystore. Lus depuis
  l'environnement du serveur, jamais exposés au dashboard ni aux logs.

Les plages autorisées et les règles de cohérence reprennent la section 9 du
document d'architecture (phase 2).
"""
from __future__ import annotations

import os
from decimal import Decimal
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, SecretStr, model_validator


class Mode(str, Enum):
    PAPER = "paper"
    SEMI_AUTO = "semi_auto"
    LIVE = "live"


class ReserveCurrency(str, Enum):
    SOL = "SOL"
    USDC = "USDC"


class Strategy(str, Enum):
    SMART_MONEY_SWING = "smart_money_swing"
    MOMENTUM_POST_GRADUATION = "momentum_post_graduation"
    BREAKOUT = "breakout"
    NARRATIVE = "narrative"
    DIP_BUYING = "dip_buying"
    EARLY_ENTRY = "early_entry"


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True, frozen=False)


class CapitalSettings(_Strict):
    cap_eur: Decimal = Field(Decimal("100"), ge=Decimal("10"), le=Decimal("10000"))
    reserve_eur: Decimal = Field(Decimal("30"), ge=Decimal("0"))
    reserve_currency: ReserveCurrency = ReserveCurrency.SOL

    @property
    def tradable_eur(self) -> Decimal:
        return self.cap_eur - self.reserve_eur

    @model_validator(mode="after")
    def _reserve_range(self) -> "CapitalSettings":
        lo, hi = self.cap_eur * Decimal("0.10"), self.cap_eur * Decimal("0.90")
        if not (lo <= self.reserve_eur <= hi):
            raise ValueError(f"la réserve doit être entre 10 % et 90 % du plafond ({lo} à {hi} €)")
        return self


class PositionSettings(_Strict):
    max_open_positions: int = Field(2, ge=1, le=5)
    min_buy_eur: Decimal = Field(Decimal("5"), ge=Decimal("2"))
    max_buy_eur: Decimal = Field(Decimal("10"), gt=Decimal("0"))

    @model_validator(mode="after")
    def _min_le_max(self) -> "PositionSettings":
        if self.min_buy_eur > self.max_buy_eur:
            raise ValueError("le montant minimal d'achat dépasse le montant maximal")
        return self


class RiskSettings(_Strict):
    risk_normal_pct: Decimal = Field(Decimal("1"), ge=Decimal("0.5"), le=Decimal("3"))
    risk_max_pct: Decimal = Field(Decimal("2"), ge=Decimal("0.5"), le=Decimal("3"))
    daily_loss_pct: Decimal = Field(Decimal("5"), ge=Decimal("1"), le=Decimal("10"))
    weekly_loss_pct: Decimal = Field(Decimal("10"), ge=Decimal("2"), le=Decimal("20"))
    max_drawdown_pct: Decimal = Field(Decimal("15"), ge=Decimal("5"), le=Decimal("30"))

    @model_validator(mode="after")
    def _ordering(self) -> "RiskSettings":
        if self.risk_max_pct < self.risk_normal_pct:
            raise ValueError("le risque maximal doit être ≥ au risque normal")
        if self.weekly_loss_pct < self.daily_loss_pct:
            raise ValueError("la perte hebdomadaire doit être ≥ à la perte journalière")
        return self


class ExecutionSettings(_Strict):
    max_slippage_pct: Decimal = Field(Decimal("3"), ge=Decimal("0.5"), le=Decimal("10"))
    max_round_trip_cost_pct: Decimal = Field(Decimal("8"), ge=Decimal("2"), le=Decimal("15"))
    max_tip_pct_of_position: Decimal = Field(Decimal("0.5"), ge=Decimal("0"), le=Decimal("2"))


class DecisionSettings(_Strict):
    min_opportunity_score: int = Field(80, ge=60, le=100)
    min_expected_net_pct: Decimal = Field(Decimal("3"), ge=Decimal("0"), le=Decimal("20"))
    max_buys_per_day: int = Field(6, ge=0, le=20)


class ExitSettings(_Strict):
    initial_stop_pct: Decimal = Field(Decimal("25"), ge=Decimal("5"), le=Decimal("60"))
    take_profit_levels: list[tuple[Decimal, Decimal]] = Field(
        default_factory=lambda: [(Decimal("30"), Decimal("25")), (Decimal("60"), Decimal("25"))],
        description="(gain %, part de la position vendue %)",
    )
    trailing_stop_pct: Decimal = Field(Decimal("20"), ge=Decimal("5"), le=Decimal("50"))

    @model_validator(mode="after")
    def _levels(self) -> "ExitSettings":
        total = sum((part for _, part in self.take_profit_levels), Decimal("0"))
        if total > Decimal("100"):
            raise ValueError("les prises de profit partielles dépassent 100 % de la position")
        gains = [g for g, _ in self.take_profit_levels]
        if gains != sorted(gains) or any(g <= 0 for g in gains):
            raise ValueError("les paliers de prise de profit doivent être positifs et croissants")
        return self


class ShadowSettings(_Strict):
    observed_wallets: int = Field(30, ge=20, le=50)
    min_trades_for_copyable: int = Field(30, ge=20, le=100)


class SocialSettings(_Strict):
    telegram_channels: list[str] = Field(default_factory=list)


class Settings(_Strict):
    """Réglages complets. Toute instance construite est cohérente."""

    mode: Mode = Mode.PAPER
    capital: CapitalSettings = Field(default_factory=CapitalSettings)
    positions: PositionSettings = Field(default_factory=PositionSettings)
    risk: RiskSettings = Field(default_factory=RiskSettings)
    execution: ExecutionSettings = Field(default_factory=ExecutionSettings)
    decision: DecisionSettings = Field(default_factory=DecisionSettings)
    exits: ExitSettings = Field(default_factory=ExitSettings)
    strategies: set[Strategy] = Field(
        default_factory=lambda: {
            Strategy.SMART_MONEY_SWING,
            Strategy.MOMENTUM_POST_GRADUATION,
            Strategy.BREAKOUT,
        }
    )
    shadow: ShadowSettings = Field(default_factory=ShadowSettings)
    social: SocialSettings = Field(default_factory=SocialSettings)

    @model_validator(mode="after")
    def _cross_checks(self) -> "Settings":
        tradable = self.capital.tradable_eur
        # Règle section 9 : un achat ≤ 25 % du capital tradable.
        if self.positions.max_buy_eur > tradable * Decimal("0.25"):
            raise ValueError(
                f"le montant max par achat ({self.positions.max_buy_eur} €) dépasse 25 % "
                f"du capital tradable ({tradable} €)"
            )
        if self.positions.max_buy_eur * self.positions.max_open_positions > tradable:
            raise ValueError("positions max × montant max dépasse le capital tradable")
        return self


# Changements qui augmentent le risque : exigent une confirmation TOTP côté API.
RISK_INCREASING_FIELDS: dict[str, str] = {
    "capital.cap_eur": "up",
    "capital.reserve_eur": "down",
    "positions.max_open_positions": "up",
    "positions.max_buy_eur": "up",
    "risk.risk_normal_pct": "up",
    "risk.risk_max_pct": "up",
    "risk.daily_loss_pct": "up",
    "risk.weekly_loss_pct": "up",
    "risk.max_drawdown_pct": "up",
    "execution.max_slippage_pct": "up",
    "execution.max_round_trip_cost_pct": "up",
    "execution.max_tip_pct_of_position": "up",
    "decision.min_opportunity_score": "down",
    "decision.min_expected_net_pct": "down",
    "decision.max_buys_per_day": "up",
}


def _get(obj: BaseModel, dotted: str):
    for part in dotted.split("."):
        obj = getattr(obj, part)
    return obj


def risk_increasing_changes(old: Settings, new: Settings) -> list[str]:
    """Liste les champs dont la nouvelle valeur augmente le risque.

    Le passage en mode LIVE compte aussi comme une hausse de risque.
    """
    changed: list[str] = []
    for path, direction in RISK_INCREASING_FIELDS.items():
        a, b = _get(old, path), _get(new, path)
        if (direction == "up" and b > a) or (direction == "down" and b < a):
            changed.append(path)
    if new.mode == Mode.LIVE and old.mode != Mode.LIVE:
        changed.append("mode")
    if new.strategies - old.strategies:
        changed.append("strategies")
    return changed


class Secrets(BaseModel):
    """Secrets lus dans l'environnement du serveur. Jamais sérialisés en clair."""

    model_config = ConfigDict(extra="ignore")

    database_url: SecretStr
    helius_api_key: SecretStr | None = None
    helius_backup_rpc_url: SecretStr | None = None
    jupiter_api_key: SecretStr | None = None
    rugcheck_api_key: SecretStr | None = None
    telegram_bot_token: SecretStr | None = None
    telegram_owner_chat_id: int | None = None
    keystore_path: str = "/run/cart3r/keystore.json"
    withdrawal_address: str | None = None
    totp_secret: SecretStr | None = None
    dashboard_password: SecretStr | None = None

    @classmethod
    def from_env(cls, env: dict[str, str] | None = None) -> "Secrets":
        env = dict(os.environ if env is None else env)
        mapping = {
            "database_url": "CART3R_DATABASE_URL",
            "helius_api_key": "CART3R_HELIUS_API_KEY",
            "helius_backup_rpc_url": "CART3R_BACKUP_RPC_URL",
            "jupiter_api_key": "CART3R_JUPITER_API_KEY",
            "rugcheck_api_key": "CART3R_RUGCHECK_API_KEY",
            "telegram_bot_token": "CART3R_TELEGRAM_BOT_TOKEN",
            "telegram_owner_chat_id": "CART3R_TELEGRAM_OWNER_CHAT_ID",
            "keystore_path": "CART3R_KEYSTORE_PATH",
            "withdrawal_address": "CART3R_WITHDRAWAL_ADDRESS",
            "totp_secret": "CART3R_TOTP_SECRET",
            "dashboard_password": "CART3R_DASHBOARD_PASSWORD",
        }
        data = {k: env[v] for k, v in mapping.items() if env.get(v)}
        return cls(**data)
