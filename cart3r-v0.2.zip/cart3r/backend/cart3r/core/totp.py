"""TOTP (RFC 6238) sans dépendance : codes à 6 chiffres compatibles Google Authenticator, Authy, etc."""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import struct
import time


def new_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def _code(secret_b32: str, counter: int, digits: int = 6) -> str:
    key = base64.b32decode(secret_b32.upper() + "=" * (-len(secret_b32) % 8))
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    value = struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFFFFFF
    return str(value % 10**digits).zfill(digits)


def now_code(secret_b32: str, at: float | None = None, step: int = 30) -> str:
    return _code(secret_b32, int((time.time() if at is None else at) // step))


def verify(secret_b32: str, code: str, at: float | None = None, step: int = 30, window: int = 1) -> bool:
    if not secret_b32 or not code or not code.isdigit():
        return False
    t = int((time.time() if at is None else at) // step)
    return any(hmac.compare_digest(_code(secret_b32, t + d), code) for d in range(-window, window + 1))


def provisioning_uri(secret_b32: str, account: str = "cart3r", issuer: str = "CART3R") -> str:
    return f"otpauth://totp/{issuer}:{account}?secret={secret_b32}&issuer={issuer}"
