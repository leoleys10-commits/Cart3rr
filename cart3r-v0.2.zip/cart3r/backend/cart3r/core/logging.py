"""Logging avec masquage des secrets.

Tout ce qui ressemble à une clé privée Solana (base58 de 64 octets), à un
fichier keypair (tableau de 64 entiers), à une phrase mnémonique ou à un token
d'API connu est remplacé par `[MASQUÉ]` avant d'être écrit.
"""
from __future__ import annotations

import logging
import re

MASK = "[MASQUÉ]"

_PATTERNS = [
    # Clé privée / keypair Solana encodée en base58 (64 octets ≈ 86-88 caractères).
    re.compile(r"\b[1-9A-HJ-NP-Za-km-z]{80,90}\b"),
    # Keypair JSON : tableau de 64 entiers 0-255.
    re.compile(r"\[\s*(?:\d{1,3}\s*,\s*){63}\d{1,3}\s*\]"),
    # Token de bot Telegram.
    re.compile(r"\b\d{6,12}:[A-Za-z0-9_-]{30,}\b"),
    # Paramètre api-key dans une URL.
    re.compile(r"(?i)(api[-_]?key=)[^&\s]+"),
]

# Mnémonique BIP39 : 12 à 24 mots minuscules de 3 à 8 lettres consécutifs.
_MNEMONIC = re.compile(r"\b(?:[a-z]{3,8}\s+){11,23}[a-z]{3,8}\b")


def mask_secrets(text: str) -> str:
    for pattern in _PATTERNS:
        if pattern.groups:
            text = pattern.sub(lambda m: m.group(1) + MASK, text)
        else:
            text = pattern.sub(MASK, text)
    return _MNEMONIC.sub(MASK, text)


class SecretMaskingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage()
        masked = mask_secrets(message)
        if masked != message:
            record.msg, record.args = masked, ()
        return True


def setup_logging(level: int = logging.INFO) -> None:
    handler = logging.StreamHandler()
    handler.addFilter(SecretMaskingFilter())
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(level)
