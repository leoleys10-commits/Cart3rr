"""Briques communes aux processus : pool PostgreSQL, réglages courants, alertes."""
from __future__ import annotations

import json
from datetime import datetime, timezone

import asyncpg

from cart3r.core.config import Secrets, Settings
from cart3r.core.events import Event, EventBus


def pg_dsn(secrets: Secrets) -> str:
    return secrets.database_url.get_secret_value().replace("postgresql+asyncpg://", "postgresql://")


async def create_pool(secrets: Secrets) -> asyncpg.Pool:
    return await asyncpg.create_pool(pg_dsn(secrets), min_size=1, max_size=5)


async def load_settings(pool: asyncpg.Pool) -> tuple[Settings, int]:
    """Dernière version des réglages ; défauts (version 0) si l'utilisateur n'a encore rien changé."""
    row = await pool.fetchrow("SELECT version, settings FROM settings_history ORDER BY version DESC LIMIT 1")
    if row is None:
        return Settings(), 0
    data = row["settings"]
    return Settings.model_validate(json.loads(data) if isinstance(data, str) else data), row["version"]


async def alert(bus: EventBus, level: str, kind: str, message: str, **extra) -> None:
    """Toute alerte passe par le bus : le processus api la relaie sur Telegram et l'enregistre."""
    await bus.publish(Event(type="alert", source=kind, observed_at=datetime.now(timezone.utc),
                            payload={"level": level, "kind": kind, "message": message, **extra}))
