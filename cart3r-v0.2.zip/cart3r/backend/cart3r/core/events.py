"""Bus d'événements interne.

En production : table `events` append-only dans PostgreSQL + LISTEN/NOTIFY
(voir `cart3r.db.event_store`). Ici : le modèle d'événement, les règles de
fraîcheur et d'idempotence, et un bus en mémoire utilisé par les tests et le
mode backtest.
"""
from __future__ import annotations

import asyncio
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable, Protocol

# Âge maximal d'une donnée selon le type d'événement (section 3 de l'architecture).
MAX_AGE: dict[str, timedelta] = {
    "market.tick": timedelta(seconds=10),
    "token.seen": timedelta(seconds=30),
    "token.created": timedelta(seconds=60),
    "token.graduated": timedelta(seconds=60),
    "wallet.trade": timedelta(seconds=30),
    "security.verdict": timedelta(seconds=60),
    "opportunity.candidate": timedelta(seconds=30),
    "trade.intent": timedelta(seconds=15),
    "order.approved": timedelta(seconds=10),
    "social.mention": timedelta(minutes=10),
    "alert": timedelta(minutes=5),  # pas de rafale de vieilles alertes au redémarrage
}

EVENT_TYPES = frozenset(
    {
        "token.created", "token.graduated", "token.seen", "market.tick",
        "wallet.trade", "social.mention", "security.verdict",
        "opportunity.candidate", "trade.intent",
        "order.approved", "order.rejected", "order.sent", "order.filled", "order.failed",
        "risk.limit_hit", "system.safe_mode", "system.panic_stop", "system.resume", "settings.changed",
        "alert",
    }
)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class Event:
    type: str
    source: str
    payload: dict[str, Any]
    observed_at: datetime
    created_at: datetime = field(default_factory=utcnow)
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    correlation_id: str | None = None
    idempotency_key: str | None = None

    def __post_init__(self) -> None:
        if self.type not in EVENT_TYPES:
            raise ValueError(f"type d'événement inconnu : {self.type}")
        if self.observed_at.tzinfo is None:
            raise ValueError("observed_at doit être en UTC avec fuseau")

    def age(self, now: datetime | None = None) -> timedelta:
        return (now or utcnow()) - self.observed_at

    def is_fresh(self, now: datetime | None = None) -> bool:
        limit = MAX_AGE.get(self.type)
        return limit is None or self.age(now) <= limit


Handler = Callable[[Event], Awaitable[None]]


class EventBus(Protocol):
    async def publish(self, event: Event) -> bool: ...
    def subscribe(self, event_type: str, handler: Handler) -> None: ...


class InMemoryEventBus:
    """Bus en mémoire : même contrat que le bus PostgreSQL.

    - `publish` renvoie False si l'`idempotency_key` a déjà été vue (pas de double ordre).
    - Les handlers ne reçoivent que des événements frais ; les périmés sont comptés
      et ignorés (jamais de décision sur donnée périmée).
    """

    def __init__(self, clock: Callable[[], datetime] = utcnow) -> None:
        self._handlers: dict[str, list[Handler]] = defaultdict(list)
        self._seen_keys: set[str] = set()
        self._clock = clock
        self.log: list[Event] = []
        self.dropped_stale: list[Event] = []

    def subscribe(self, event_type: str, handler: Handler) -> None:
        if event_type not in EVENT_TYPES:
            raise ValueError(f"type d'événement inconnu : {event_type}")
        self._handlers[event_type].append(handler)

    async def publish(self, event: Event) -> bool:
        if event.idempotency_key is not None:
            if event.idempotency_key in self._seen_keys:
                return False
            self._seen_keys.add(event.idempotency_key)
        self.log.append(event)
        if not event.is_fresh(self._clock()):
            self.dropped_stale.append(event)
            return True
        handlers = list(self._handlers.get(event.type, ()))
        if handlers:
            await asyncio.gather(*(h(event) for h in handlers))
        return True
