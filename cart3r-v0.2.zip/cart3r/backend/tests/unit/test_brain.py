import asyncio
from datetime import datetime, timedelta, timezone

import pytest

from cart3r.brain.fees import CostInputs, OutcomeModel, decide, expected_net_pct, round_trip_cost
from cart3r.brain.security import SecurityInput, evaluate
from cart3r.brain.shadow import (
    Fill, LegStatus, ShadowTrade, WalletStatus, next_status, wallet_sell_fraction, wallet_stats,
)
from cart3r.solana.mint import (
    TOKEN_2022_PROGRAM_ID, TOKEN_PROGRAM_ID, MintParseError, build_mint_bytes, parse_mint,
)
from cart3r.sources.base import DataUnavailable, FallbackSource, Fresh, Provider

NOW = datetime(2026, 11, 27, 12, 0, tzinfo=timezone.utc)
PK = bytes(range(32))


# ---------- Mint ----------

def test_parse_clean_spl_mint():
    m = parse_mint(build_mint_bytes(), TOKEN_PROGRAM_ID)
    assert m.mint_authority is None and m.freeze_authority is None
    assert m.decimals == 6 and m.is_initialized and m.extensions == ()


def test_parse_authorities():
    m = parse_mint(build_mint_bytes(mint_authority=PK, freeze_authority=PK), TOKEN_PROGRAM_ID)
    assert m.mint_authority and m.freeze_authority


def test_parse_token2022_extensions():
    data = build_mint_bytes(extensions=[(18, b"\1" * 64), (12, PK)])
    m = parse_mint(data, TOKEN_2022_PROGRAM_ID)
    assert m.extensions == (18, 12)
    assert m.unsafe_extensions == (12,)
    assert "PermanentDelegate" in m.extension_names()


def test_extended_data_on_classic_program_rejected():
    with pytest.raises(MintParseError):
        parse_mint(build_mint_bytes(extensions=[(18, b"")]), TOKEN_PROGRAM_ID)


def test_truncated_tlv_rejected():
    data = build_mint_bytes(extensions=[(18, b"\1" * 10)])[:-3]
    with pytest.raises(MintParseError):
        parse_mint(data, TOKEN_2022_PROGRAM_ID)


# ---------- Sécurité ----------

def _clean_input(**kw):
    base = dict(
        mint=parse_mint(build_mint_bytes(), TOKEN_PROGRAM_ID),
        metadata_mutable=False, top10_share_pct=12.0, creator_cluster_share_pct=3.0,
        bundled_share_pct=2.0, deployer_flagged=False, liquidity_usd=50_000.0,
        planned_position_usd=8.0, sell_quote_ok=True, sell_quote_loss_pct=1.0,
        wash_volume_share_pct=5.0,
    )
    base.update(kw)
    return SecurityInput(**base)


def test_clean_token_passes_with_full_score():
    v = evaluate(_clean_input())
    assert not v.excluded and v.score == 100


def test_permanent_delegate_excluded_even_if_authorities_revoked():
    mint = parse_mint(build_mint_bytes(extensions=[(19, b"x"), (12, PK)]), TOKEN_2022_PROGRAM_ID)
    v = evaluate(_clean_input(mint=mint))
    assert v.excluded and v.score == 0
    assert any("PermanentDelegate" in r for r in v.reasons)


@pytest.mark.parametrize(
    "override",
    [
        {"mint": None},
        {"top10_share_pct": None},
        {"top10_share_pct": 45.0},
        {"creator_cluster_share_pct": 12.0},
        {"bundled_share_pct": 20.0},
        {"deployer_flagged": True},
        {"liquidity_usd": None},
        {"liquidity_usd": 500.0},  # 8 $ = 1,6 % de la liquidité
        {"sell_quote_ok": None},
        {"sell_quote_ok": True, "sell_quote_loss_pct": 12.0},
        {"wash_volume_share_pct": 55.0},
    ],
)
def test_critical_rules_exclude(override):
    assert evaluate(_clean_input(**override)).excluded


def test_missing_non_critical_data_penalises_but_never_helps():
    v = evaluate(_clean_input(bundled_share_pct=None, wash_volume_share_pct=None, metadata_mutable=None))
    assert not v.excluded and v.score == 75


# ---------- Frais ----------

def _costs(**kw):
    base = dict(
        position_usd=8.0, platform_fee_buy_pct=1.25, platform_fee_sell_pct=1.25, aggregator_fee_pct=0.0,
        network_fee_sol_per_tx=0.00006, tip_sol_per_tx=0.0, sol_usd=80.0,
        slippage_buy_pct=1.0, slippage_sell_pct=1.0,
    )
    base.update(kw)
    return CostInputs(**base)


def test_round_trip_cost_matches_phase1_table():
    c = round_trip_cost(_costs())
    assert c.platform_pct == pytest.approx(2.5)
    assert c.network_pct == pytest.approx(0.00006 * 3 * 80 / 8 * 100)
    assert 4.5 < c.total_pct < 4.8


def test_jito_tip_adds_about_two_percent():
    c = round_trip_cost(_costs(tip_sol_per_tx=0.001))
    assert c.tip_pct == pytest.approx(2.0)


def test_phase1_example_is_negative_after_costs():
    model = OutcomeModel(p_win=0.40, avg_gain_pct=40, avg_loss_pct=25, p_rug=0.03)
    e = expected_net_pct(model, round_trip_cost(_costs()))
    assert e < 0


def test_decide_refuses_expensive_or_weak_trades():
    strong = OutcomeModel(p_win=0.5, avg_gain_pct=60, avg_loss_pct=20, p_rug=0.02)
    ok = decide(strong, _costs(), min_expected_net_pct=3, max_round_trip_cost_pct=8, max_tip_pct_of_position=0.5)
    assert ok.accepted, ok.reasons
    tipped = decide(strong, _costs(tip_sol_per_tx=0.001), min_expected_net_pct=3,
                    max_round_trip_cost_pct=8, max_tip_pct_of_position=0.5)
    assert not tipped.accepted and any("tip" in r for r in tipped.reasons)


def test_outcome_model_validates_probabilities():
    with pytest.raises(ValueError):
        OutcomeModel(p_win=0.8, avg_gain_pct=1, avg_loss_pct=1, p_rug=0.3)


# ---------- Shadow ----------

def _closed_trade(wallet_ret, copy_ret):
    t = ShadowTrade(wallet="W", mint="M")
    t.wallet_leg.buys.append(Fill(NOW, 100, 1.0))
    t.wallet_leg.sells.append(Fill(NOW, 100, 1.0 + wallet_ret / 100))
    t.copy_leg.buys.append(Fill(NOW, 100, 1.0))
    t.copy_leg.sells.append(Fill(NOW, 100, 1.0 + copy_ret / 100))
    t.wallet_leg.close_if_flat()
    t.copy_leg.close_if_flat()
    return t


def test_imitation_penalty_measured():
    trades = [_closed_trade(14, 3) for _ in range(5)]
    s = wallet_stats(trades)
    assert s.n_closed == 5
    assert s.imitation_penalty_pct == pytest.approx(11)


def test_not_simulable_excluded_from_stats():
    t = ShadowTrade(wallet="W", mint="M")
    t.copy_leg.mark_not_simulable("quote indisponible")
    s = wallet_stats([t, _closed_trade(10, 5)])
    assert s.n_not_simulable == 1 and s.n_closed == 1
    assert t.copy_leg.net_return_pct() is None


def test_fees_reduce_copy_return():
    t = ShadowTrade(wallet="W", mint="M")
    t.copy_leg.buys.append(Fill(NOW, 100, 1.0, fees_sol=0.01))
    t.copy_leg.sells.append(Fill(NOW, 100, 1.0, fees_sol=0.01))
    t.copy_leg.close_if_flat()
    assert t.copy_leg.status is LegStatus.CLOSED
    assert t.copy_leg.net_return_pct() == pytest.approx(-100 * 0.02 / 1.01)


def test_sell_fraction_for_prorata_copy():
    t = ShadowTrade(wallet="W", mint="M")
    t.wallet_leg.buys.append(Fill(NOW, 100, 1.0))
    t.wallet_leg.sells.append(Fill(NOW, 25, 0.4))
    assert wallet_sell_fraction(t, 25) == pytest.approx(0.25)


def test_status_needs_enough_positive_trades():
    few = wallet_stats([_closed_trade(20, 10) for _ in range(10)])
    assert next_status(WalletStatus.OBSERVED, few, 30) is WalletStatus.OBSERVED
    good = wallet_stats([_closed_trade(20, r) for r in [8, 12, 10, 9, 11] * 6])
    assert next_status(WalletStatus.OBSERVED, good, 30) is WalletStatus.COPYABLE
    bad = wallet_stats([_closed_trade(20, r) for r in [-8, -12, -10, -9, -11] * 6])
    assert next_status(WalletStatus.COPYABLE, bad, 30) is WalletStatus.DEMOTED


# ---------- Sources avec secours ----------

def _provider(name, *, fail=False, age_s=0, delay=0.0):
    async def fetch():
        await asyncio.sleep(delay)
        if fail:
            raise ConnectionError("down")
        return Fresh(value=name, observed_at=NOW - timedelta(seconds=age_s), source=name)
    return Provider(name=name, fetch=fetch, timeout_s=0.05)


def _source(providers, t=[0.0]):
    return FallbackSource(providers, max_age=timedelta(seconds=10), max_failures=2, cooldown_s=30,
                          clock=lambda: t[0], now=lambda: NOW)


def test_fallback_to_backup():
    src = _source([_provider("main", fail=True), _provider("backup")])
    assert asyncio.run(src.get()).source == "backup"


def test_stale_data_counts_as_failure():
    src = _source([_provider("main", age_s=60), _provider("backup", age_s=1)])
    assert asyncio.run(src.get()).source == "backup"


def test_timeout_counts_as_failure():
    src = _source([_provider("slow", delay=0.2), _provider("backup")])
    assert asyncio.run(src.get()).source == "backup"


def test_all_down_raises_never_invents():
    src = _source([_provider("a", fail=True), _provider("b", age_s=99)])
    with pytest.raises(DataUnavailable):
        asyncio.run(src.get())


def test_failing_provider_put_in_cooldown():
    clock = [0.0]
    main, backup = _provider("main", fail=True), _provider("backup")
    src = _source([main, backup], clock)
    asyncio.run(src.get())
    asyncio.run(src.get())
    assert main.health.cooldown_until == 30
    assert src._ordered() == [backup]
    clock[0] = 31
    assert src._ordered()[0] is main
