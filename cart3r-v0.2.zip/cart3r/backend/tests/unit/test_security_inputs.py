import pytest

from cart3r.brain.security_inputs import sell_quote_loss_pct, top10_share_pct, wash_volume_share_pct


def test_top10_excludes_pool_and_curve():
    accounts = [{"address": "pool", "amount": "800"}] + [{"address": f"h{i}", "amount": "10"} for i in range(15)]
    assert top10_share_pct(accounts, 1000, {"pool"}) == pytest.approx(10.0)


def test_top10_unknown_supply():
    assert top10_share_pct([], 0, set()) is None


def test_sell_quote_loss_reveals_hidden_tax():
    assert sell_quote_loss_pct(1_000_000, 975_000, 2.5) == pytest.approx(0.0)
    assert sell_quote_loss_pct(1_000_000, 850_000, 2.5) == pytest.approx(12.5)


def _t(wallet, side, amount, lamports):
    return {"wallet": wallet, "side": side, "token_amount": amount, "sol_lamports": lamports}


def test_wash_trader_detected():
    wash = [_t("bot", s, 100, 50) for _ in range(3) for s in ("buy", "sell")]
    organic = [_t("alice", "buy", 400, 300)]
    assert wash_volume_share_pct(wash + organic) == pytest.approx(50.0)


def test_holder_is_not_wash():
    trades = [_t("bob", "buy", 100, 50) for _ in range(4)] + [_t("bob", "sell", 100, 60)]
    assert wash_volume_share_pct(trades) == 0.0


def test_no_trades_is_unknown():
    assert wash_volume_share_pct([]) is None
