import asyncio
from datetime import datetime, timedelta, timezone
from decimal import Decimal

import pytest

from cart3r.brain.shadow_recorder import QuoteResult
from cart3r.brain.strategies import (
    MarketSnapshot, MomentumParams, SmartMoneyParams, momentum_signal, opportunity_score, smart_money_signal,
)
from cart3r.core.config import Settings
from cart3r.exec.exits import ExitAction, ExitPlan, RiskFlags, apply, evaluate
from cart3r.exec.paper import TOKEN_ACCOUNT_RENT, PaperBroker, PaperFillError
from cart3r.guard.capital import LAMPORTS, CapitalGuard

NOW = datetime(2026, 11, 27, 12, 0, tzinfo=timezone.utc)


# ---------- Stratégies ----------

def _snap(**kw):
    base = dict(mint="M", observed_at=NOW, price_usd=0.0001, liquidity_usd=40_000, market_cap_usd=300_000,
                volume_5m_usd=15_000, volume_1h_usd=80_000, buys_5m=90, sells_5m=50,
                price_change_5m_pct=8.0, price_change_1h_pct=60.0)
    base.update(kw)
    return MarketSnapshot(**base)


def test_momentum_accepts_healthy_setup():
    s = momentum_signal(_snap(), NOW - timedelta(minutes=30), MomentumParams())
    assert s.ok, s.reasons
    assert 0 < s.momentum_score <= 1 and 0 < s.liquidity_score <= 1


@pytest.mark.parametrize("override,word", [
    ({"price_change_5m_pct": 80.0}, "trop tard"),
    ({"liquidity_usd": 5_000}, "liquidité"),
    ({"buys_5m": 40, "sells_5m": 60}, "ratio"),
    ({"volume_5m_usd": None}, "données manquantes"),
])
def test_momentum_rejections(override, word):
    s = momentum_signal(_snap(**override), NOW - timedelta(minutes=30), MomentumParams())
    assert not s.ok and any(word in r for r in s.reasons)


def test_momentum_outside_graduation_window():
    s = momentum_signal(_snap(), NOW - timedelta(hours=10), MomentumParams())
    assert not s.ok


def test_dexscreener_parsing():
    pair = {"baseToken": {"address": "M"}, "priceUsd": "0.0002", "liquidity": {"usd": 1000},
            "marketCap": 5000, "volume": {"m5": 10, "h1": 50}, "txns": {"m5": {"buys": 3, "sells": 1}},
            "priceChange": {"m5": 1.5, "h1": -2}}
    s = MarketSnapshot.from_dexscreener(pair, NOW)
    assert s.price_usd == 0.0002 and s.buys_5m == 3 and s.price_change_1h_pct == -2


def test_smart_money_requires_copyable_and_close_price():
    p = SmartMoneyParams()
    ok = smart_money_signal(wallet_status="copyable", wallet_price_sol_per_token=1.0,
                            our_price_sol_per_token=1.05, seconds_after_wallet=10, independent_buyers=2, p=p)
    assert ok.ok
    late = smart_money_signal(wallet_status="copyable", wallet_price_sol_per_token=1.0,
                              our_price_sol_per_token=1.3, seconds_after_wallet=10, independent_buyers=2, p=p)
    assert not late.ok
    obs = smart_money_signal(wallet_status="observed", wallet_price_sol_per_token=1.0,
                             our_price_sol_per_token=1.0, seconds_after_wallet=1, independent_buyers=1, p=p)
    assert not obs.ok


def test_opportunity_score_redistributes_unknown_social():
    s = momentum_signal(_snap(), NOW - timedelta(minutes=30), MomentumParams())
    score = opportunity_score(100, s, None)
    assert 0 <= score <= 100
    assert opportunity_score(0, s, None) < score


# ---------- Capital guard ----------

def _guard(**kw):
    g = CapitalGuard.fresh(Settings(), eur_per_sol=100.0)  # 100 € = 1 SOL
    g.roll_periods(NOW)
    return g


def test_size_raised_to_minimum_within_max_risk():
    g = _guard()
    d = g.size(stop_pct=25, eur_per_sol=100, liquidity_usd=1_000_000, sol_usd=110)
    # risque 1 % = 1 € ; stop 25 % => 4 € < 5 € ; 5 € × 25 % = 1,25 € ≤ risque max 2 € => 5 €
    assert d.approved and d.lamports == int(5 / 100 * LAMPORTS)


def test_size_refused_when_minimum_exceeds_max_risk():
    g = _guard()
    d = g.size(stop_pct=50, eur_per_sol=100, liquidity_usd=1_000_000, sol_usd=110)
    # 5 € × 50 % = 2,5 € > risque max 2 € => refus
    assert not d.approved and "minimum" in d.reasons[0]


def test_size_with_tighter_stop():
    g = _guard()
    d = g.size(stop_pct=10, eur_per_sol=100, liquidity_usd=1_000_000, sol_usd=110)
    assert d.approved and d.lamports == int(10 / 100 * LAMPORTS)  # 1 € / 10 % = 10 € = max


def test_size_capped_by_liquidity():
    g = _guard()
    d = g.size(stop_pct=10, eur_per_sol=100, liquidity_usd=60_000, sol_usd=100)  # 1 % = 600 $ : pas limitant
    assert d.approved
    d2 = g.size(stop_pct=10, eur_per_sol=100, liquidity_usd=300, sol_usd=100)  # 1 % = 3 $ ≈ 3 € < 5 € minimum
    assert not d2.approved


def test_max_positions_and_daily_buys():
    g = _guard()
    g.on_buy("a", 10_000_000)
    g.on_buy("b", 10_000_000)
    assert any("positions" in r for r in g.can_buy())
    g2 = _guard()
    g2.st.buys_today = 6
    assert any("achats" in r for r in g2.can_buy())


def test_daily_loss_pauses_then_resumes_next_day():
    g = _guard()
    g.on_buy("a", 100_000_000)
    g.mark("a", 40_000_000)  # -6 % du capital de référence
    alerts = g.check_limits()
    assert any("jour" in a for a in alerts) and g.can_buy()
    g.on_sell("a", 40_000_000, 0)
    g.roll_periods(NOW + timedelta(days=1))
    assert g.st.paused_until_period is None


def test_drawdown_halts_until_manual_resume():
    g = _guard()
    g.on_buy("a", 200_000_000)
    g.mark("a", 40_000_000)  # -16 %
    g.check_limits()
    assert g.st.halted_reason
    g.roll_periods(NOW + timedelta(days=8))
    assert any("arrêté" in r for r in g.can_buy())
    g.resume()
    assert g.st.halted_reason is None


def test_risk_shrinks_after_loss_never_grows_after_gain():
    g = _guard()
    big = g.size(stop_pct=5, eur_per_sol=100, liquidity_usd=1e7, sol_usd=100).lamports
    g.st.cash_lamports += 5 * LAMPORTS  # gros gain
    assert g.size(stop_pct=5, eur_per_sol=100, liquidity_usd=1e7, sol_usd=100).lamports == big


def test_start_balance_never_above_cap():
    g = CapitalGuard.fresh(Settings(), eur_per_sol=100.0, start_lamports=5 * LAMPORTS)
    assert g.st.cash_lamports == g.st.reference_lamports == LAMPORTS


def test_panic_blocks_buys():
    g = _guard()
    g.st.panic = True
    assert not g.size(stop_pct=10, eur_per_sol=100, liquidity_usd=1e7, sol_usd=100).approved


# ---------- Sorties ----------

def _plan():
    return ExitPlan(stop_pct=25, take_profits=[(30, 25), (60, 25)], trailing_pct=20)


def test_stop_loss():
    a = evaluate(_plan(), 0.74, NOW, NOW)
    assert a.fraction_of_remaining == 1.0 and "stop" in a.reason


def test_take_profit_sequence_and_trailing():
    p = _plan()
    a1 = evaluate(p, 1.31, NOW, NOW)
    assert a1.fraction_of_remaining == pytest.approx(0.25)
    apply(p, a1)
    assert evaluate(p, 1.35, NOW, NOW) is None
    a2 = evaluate(p, 1.62, NOW, NOW)
    assert a2.fraction_of_remaining == pytest.approx(0.25 / 0.75)
    apply(p, a2)
    assert p.sold_fraction == pytest.approx(0.5)
    evaluate(p, 2.0, NOW, NOW)  # nouveau plus haut
    a3 = evaluate(p, 1.59, NOW, NOW)  # -20,5 % depuis 2.0
    assert a3.fraction_of_remaining == 1.0 and "trailing" in a3.reason


def test_emergencies_take_priority():
    a = evaluate(_plan(), 1.5, NOW, NOW, RiskFlags(liquidity_drop_pct=45))
    assert a.emergency and a.fraction_of_remaining == 1.0
    b = evaluate(_plan(), 1.0, NOW, NOW, RiskFlags(security_alert="autorité de gel réactivée"))
    assert b.emergency


def test_unsellable_does_nothing_and_time_stop():
    assert evaluate(_plan(), 0.1, NOW, NOW, RiskFlags(unsellable=True)) is None
    a = evaluate(_plan(), 1.05, NOW - timedelta(hours=25), NOW)
    assert "durée" in a.reason


def test_plan_json_roundtrip():
    p = _plan()
    apply(p, ExitAction(0.25, "prise de profit palier 1 (+30 %)"))
    q = ExitPlan.from_json(p.to_json())
    assert q.done_levels == [0] and q.take_profits == [(30, 25), (60, 25)]


# ---------- Paper broker ----------

class Q:
    def __init__(self, rate=1000.0, fail=False):
        self.rate, self.fail = rate, fail

    async def __call__(self, inp, out, amount):
        if self.fail:
            raise ConnectionError("down")
        if out != "So11111111111111111111111111111111111111112":
            return QuoteResult(int(amount * self.rate), 10_000)
        return QuoteResult(int(amount / self.rate), 10_000)


async def _nosleep(_):
    return None


def test_paper_buy_and_sell_costs():
    b = PaperBroker(Q(), latency_s=0, extra_slippage_pct=0.5, sleep=_nosleep)
    buy = asyncio.run(b.buy("M", 100_000_000))
    assert buy.tokens == int(100_000_000 * 1000 * 0.995)
    assert buy.lamports == 100_000_000 + 10_000 + TOKEN_ACCOUNT_RENT
    sell = asyncio.run(b.sell("M", buy.tokens, closes_position=True))
    assert sell.lamports < buy.lamports  # aller-retour perdant à prix constant


def test_paper_fill_fails_without_quote():
    b = PaperBroker(Q(fail=True), latency_s=0, sleep=_nosleep)
    with pytest.raises(PaperFillError):
        asyncio.run(b.buy("M", 1000))
