from datetime import datetime, timedelta, timezone

from cart3r.brain.decision import MIN_TRADES_FOR_STATS, decide, estimate_outcome
from cart3r.brain.fees import CostInputs
from cart3r.brain.security import SecurityInput, evaluate
from cart3r.brain.strategies import MarketSnapshot, MomentumParams, momentum_signal
from cart3r.core.config import Mode, Settings
from cart3r.solana.mint import TOKEN_PROGRAM_ID, build_mint_bytes, parse_mint

NOW = datetime(2026, 11, 27, 12, 0, tzinfo=timezone.utc)


def _sec(**kw):
    base = dict(mint=parse_mint(build_mint_bytes(), TOKEN_PROGRAM_ID), metadata_mutable=False, top10_share_pct=10,
                creator_cluster_share_pct=2, bundled_share_pct=1, deployer_flagged=False, liquidity_usd=50_000,
                planned_position_usd=8, sell_quote_ok=True, sell_quote_loss_pct=0.5, wash_volume_share_pct=3)
    base.update(kw)
    return evaluate(SecurityInput(**base))


def _sig(**kw):
    snap = dict(mint="M", observed_at=NOW, price_usd=1e-4, liquidity_usd=90_000, market_cap_usd=400_000,
                volume_5m_usd=30_000, volume_1h_usd=100_000, buys_5m=160, sells_5m=60,
                price_change_5m_pct=15, price_change_1h_pct=50)
    snap.update(kw)
    return momentum_signal(MarketSnapshot(**snap), NOW - timedelta(minutes=20), MomentumParams())


COSTS = CostInputs(position_usd=8, platform_fee_buy_pct=1.0, platform_fee_sell_pct=1.0, aggregator_fee_pct=0.1,
                   network_fee_sol_per_tx=0.00006, tip_sol_per_tx=0, sol_usd=80, slippage_buy_pct=1,
                   slippage_sell_pct=1)


def _decide(settings=None, returns=(), **kw):
    return decide(mint="M", security=kw.get("security", _sec()), signal=kw.get("signal", _sig()), social_score=None,
                  settings=settings or Settings(), costs=kw.get("costs", COSTS), strategy_returns=list(returns),
                  liquidity_usd=90_000)


def test_paper_explores_when_expectancy_unknown():
    r = _decide()
    assert r.accepted, r.reasons
    assert r.intent.exploration and r.intent.expected_net_pct is None


def test_live_refuses_unknown_expectancy():
    s = Settings()
    s.mode = Mode.LIVE
    r = _decide(settings=s)
    assert not r.accepted and any("non mesurée" in x for x in r.reasons)


def test_measured_negative_expectancy_refused_even_in_paper():
    losing = [-20.0] * 20 + [15.0] * 10
    r = _decide(returns=losing)
    assert not r.accepted and any("espérance" in x for x in r.reasons)


def test_security_exclusion_wins():
    r = _decide(security=_sec(top10_share_pct=60))
    assert not r.accepted and any("sécurité" in x for x in r.reasons)


def test_expensive_trade_refused():
    costly = CostInputs(**{**COSTS.__dict__, "slippage_buy_pct": 5, "slippage_sell_pct": 5})
    r = _decide(costs=costly)
    assert not r.accepted and any("coût" in x for x in r.reasons)


def test_estimate_outcome():
    assert estimate_outcome([1.0] * (MIN_TRADES_FOR_STATS - 1)) is None
    m = estimate_outcome([40.0] * 12 + [-20.0] * 15 + [-95.0] * 3)
    assert round(m.p_win, 2) == 0.4 and round(m.p_rug, 2) == 0.1
    assert m.avg_gain_pct == 40 and m.avg_loss_pct == 20
