from datetime import datetime, timezone

from cart3r.brain.security_service import rugcheck_insights
from cart3r.core import totp
from cart3r.core.config import Settings
from cart3r.guard.capital import CapitalGuard, GuardState


def test_totp_rfc6238_vector():
    # Vecteur RFC 6238 (SHA1) : secret ASCII "12345678901234567890", t=59 -> 94287082 (8 chiffres) ; 6 chiffres = 287082
    import base64
    secret = base64.b32encode(b"12345678901234567890").decode()
    assert totp.now_code(secret, at=59) == "287082"
    assert totp.verify(secret, "287082", at=59)
    assert not totp.verify(secret, "000000", at=59)
    assert not totp.verify("", "287082", at=59)


def test_totp_new_secret_roundtrip():
    s = totp.new_secret()
    assert totp.verify(s, totp.now_code(s))


def test_guard_state_roundtrip():
    g = CapitalGuard.fresh(Settings(), eur_per_sol=100.0)
    g.roll_periods(datetime(2026, 11, 27, tzinfo=timezone.utc))
    g.on_buy("p1", 1000)
    st = GuardState.from_json(g.st.to_json())
    assert st == g.st


def test_rugcheck_insights_defensive():
    assert rugcheck_insights(None) == (None, None)
    assert rugcheck_insights({}) == (None, None)
    assert rugcheck_insights({"graphInsidersDetected": 0, "risks": []}) == (0.0, False)
    c, f = rugcheck_insights({"graphInsidersDetected": 3, "risks": [{"name": "Creator rugged before", "level": "danger"}]})
    assert c == 100.0 and f is True
