import asyncio
import logging
from datetime import datetime, timedelta, timezone
from decimal import Decimal

import pytest
from pydantic import ValidationError

from cart3r.core.config import Mode, Settings, risk_increasing_changes
from cart3r.core.events import Event, InMemoryEventBus
from cart3r.core.logging import MASK, SecretMaskingFilter, mask_secrets
from cart3r.solana.b58 import b58decode, b58encode, is_pubkey

NOW = datetime(2026, 11, 27, 12, 0, tzinfo=timezone.utc)


# ---------- Configuration ----------

def test_default_settings_match_phase1():
    s = Settings()
    assert s.mode is Mode.PAPER
    assert s.capital.cap_eur == 100 and s.capital.reserve_eur == 30
    assert s.capital.tradable_eur == 70
    assert s.positions.max_open_positions == 2
    assert (s.positions.min_buy_eur, s.positions.max_buy_eur) == (5, 10)


def test_reserve_out_of_range_rejected():
    with pytest.raises(ValidationError):
        Settings(capital={"cap_eur": 100, "reserve_eur": 95})


def test_buy_size_above_quarter_of_tradable_rejected():
    with pytest.raises(ValidationError):
        Settings(positions={"max_buy_eur": 20})  # 25 % de 70 € = 17,5 €


def test_positions_times_size_above_tradable_rejected():
    with pytest.raises(ValidationError):
        Settings(capital={"cap_eur": 100, "reserve_eur": 60}, positions={"max_open_positions": 5, "max_buy_eur": 10})


def test_unknown_field_rejected():
    with pytest.raises(ValidationError):
        Settings(leverage=3)


def test_risk_increasing_changes_detected():
    old = Settings()
    new = old.model_copy(deep=True)
    new.risk.risk_normal_pct = Decimal("1.5")
    new.capital.reserve_eur = Decimal("20")
    new.mode = Mode.LIVE
    assert set(risk_increasing_changes(old, new)) == {"risk.risk_normal_pct", "capital.reserve_eur", "mode"}


def test_risk_decrease_needs_no_confirmation():
    old = Settings()
    new = old.model_copy(deep=True)
    new.risk.daily_loss_pct = Decimal("3")
    assert risk_increasing_changes(old, new) == []


# ---------- Événements ----------

def _ev(**kw):
    base = dict(type="market.tick", source="test", payload={}, observed_at=NOW)
    base.update(kw)
    return Event(**base)


def test_stale_event_not_delivered():
    bus = InMemoryEventBus(clock=lambda: NOW)
    got = []

    async def h(e):
        got.append(e)

    bus.subscribe("market.tick", h)
    asyncio.run(bus.publish(_ev(observed_at=NOW - timedelta(seconds=30))))
    asyncio.run(bus.publish(_ev(observed_at=NOW - timedelta(seconds=2))))
    assert len(got) == 1 and len(bus.dropped_stale) == 1


def test_idempotency_prevents_double_order():
    bus = InMemoryEventBus(clock=lambda: NOW)
    calls = []

    async def h(e):
        calls.append(e)

    bus.subscribe("order.approved", h)
    e1 = _ev(type="order.approved", idempotency_key="intent-42")
    e2 = _ev(type="order.approved", idempotency_key="intent-42")
    assert asyncio.run(bus.publish(e1)) is True
    assert asyncio.run(bus.publish(e2)) is False
    assert len(calls) == 1


def test_unknown_event_type_rejected():
    with pytest.raises(ValueError):
        _ev(type="buy.now")


def test_naive_datetime_rejected():
    with pytest.raises(ValueError):
        _ev(observed_at=datetime(2026, 1, 1))


# ---------- Masquage des secrets ----------

def test_mask_base58_private_key():
    key = b58encode(bytes(range(1, 65)))
    assert key not in mask_secrets(f"clé={key}")


def test_mask_keypair_json():
    arr = "[" + ",".join(str(i) for i in range(64)) + "]"
    assert mask_secrets(f"keypair {arr} chargé") == f"keypair {MASK} chargé"


def test_mask_mnemonic_and_api_key():
    words = " ".join(["abandon"] * 11 + ["about"])
    out = mask_secrets(f"seed: {words} url=https://x?api-key=abc123")
    assert "abandon" not in out and "abc123" not in out


def test_pubkey_is_not_masked():
    pk = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
    assert mask_secrets(pk) == pk


def test_logging_filter_masks(caplog):
    logger = logging.getLogger("cart3r.test")
    logger.addFilter(SecretMaskingFilter())
    key = b58encode(bytes(range(1, 65)))
    with caplog.at_level(logging.INFO):
        logger.info("signer chargé avec %s", key)
    assert key not in caplog.text and MASK in caplog.text


# ---------- Base58 ----------

def test_b58_roundtrip_and_known_value():
    assert b58encode(b"\0\0abc") == "11ZiCa"
    for data in (b"", b"\0", bytes(32), bytes(range(32))):
        assert b58decode(b58encode(data)) == data
    assert is_pubkey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")
    assert not is_pubkey("0OIl")
