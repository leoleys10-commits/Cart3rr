import asyncio
from datetime import datetime, timezone

import pytest

from cart3r.brain.shadow import LegStatus
from cart3r.brain.shadow_recorder import QuoteResult, ShadowRecorder, WSOL
from cart3r.solana.tx_parse import WSOL_MINT, parse_swap

W = "WaLLet1111111111111111111111111111111111111"
MINT = "MeMe111111111111111111111111111111111111pump"
NOW = datetime(2026, 11, 27, 12, 0, tzinfo=timezone.utc)


def _tx(*, sol_pre, sol_post, tok_pre, tok_post, fee=5000, err=None, wallet_index=0, extra_mint=None):
    keys = ["Other1111111111111111111111111111111111111"] * 3
    keys[wallet_index] = W
    def tb(amount, mint=MINT):
        return {"owner": W, "mint": mint, "uiTokenAmount": {"amount": str(amount)}}
    pre = [tb(tok_pre)] if tok_pre is not None else []
    post = [tb(tok_post)]
    if extra_mint:
        pre.append(tb(0, extra_mint)); post.append(tb(10, extra_mint))
    balances_pre, balances_post = [0, 0, 0], [0, 0, 0]
    balances_pre[wallet_index], balances_post[wallet_index] = sol_pre, sol_post
    return {
        "slot": 123, "blockTime": 1_795_000_000,
        "transaction": {"message": {"accountKeys": [{"pubkey": k} for k in keys]}},
        "meta": {"err": err, "fee": fee, "preBalances": balances_pre, "postBalances": balances_post,
                 "preTokenBalances": pre, "postTokenBalances": post},
    }


def test_parse_buy():
    ev = parse_swap(_tx(sol_pre=2_000_000_000, sol_post=1_899_995_000, tok_pre=None, tok_post=5_000), W, "sig")
    assert ev.side == "buy" and ev.mint == MINT and ev.token_amount == 5_000
    assert ev.sol_lamports == 100_000_000 and ev.fee_lamports == 5000


def test_parse_sell():
    ev = parse_swap(_tx(sol_pre=1_000_000_000, sol_post=1_149_995_000, tok_pre=5_000, tok_post=0), W, "sig")
    assert ev.side == "sell" and ev.sol_lamports == 150_000_000


def test_failed_tx_ignored():
    assert parse_swap(_tx(sol_pre=2, sol_post=1, tok_pre=0, tok_post=5, err={"x": 1}), W, "s") is None


def test_token_received_without_paying_is_not_a_buy():
    assert parse_swap(_tx(sol_pre=10_000, sol_post=5_000, tok_pre=0, tok_post=5, fee=5000), W, "s") is None


def test_multi_token_route_ignored():
    assert parse_swap(_tx(sol_pre=2_000_000_000, sol_post=1_000_000_000, tok_pre=0, tok_post=5,
                          extra_mint="X" * 44), W, "s") is None


def test_wsol_counted_as_sol():
    tx = _tx(sol_pre=1_000_000_000, sol_post=999_995_000, tok_pre=0, tok_post=7)
    tx["meta"]["preTokenBalances"].append({"owner": W, "mint": WSOL_MINT, "uiTokenAmount": {"amount": "500000000"}})
    tx["meta"]["postTokenBalances"].append({"owner": W, "mint": WSOL_MINT, "uiTokenAmount": {"amount": "0"}})
    ev = parse_swap(tx, W, "s")
    assert ev.side == "buy" and ev.sol_lamports == 500_000_000


def test_non_payer_wallet_fee_not_added():
    ev = parse_swap(_tx(sol_pre=2_000_000_000, sol_post=1_900_000_000, tok_pre=0, tok_post=5, wallet_index=1), W, "s")
    assert ev.sol_lamports == 100_000_000 and ev.fee_lamports == 0


# ---------- Shadow recorder ----------

class FakeMarket:
    """Prix fixé à la main : `price` lamports par token, frais 1 % + 10 000 lamports."""

    def __init__(self, price: float, fail: bool = False):
        self.price, self.fail = price, fail

    async def quote(self, inp, out, amount):
        if self.fail:
            raise ConnectionError("jupiter down")
        if inp == WSOL:
            return QuoteResult(int(amount / self.price * 0.99), 10_000)
        return QuoteResult(int(amount * self.price * 0.99), 10_000)


def _swap(side, tokens, lamports):
    from cart3r.solana.tx_parse import SwapEvent
    return SwapEvent("sig", W, MINT, side, tokens, lamports, 5000, 1, NOW)


def _recorder(market, accept=True):
    async def would_accept(ev):
        return (accept, None if accept else "score insuffisant")
    return ShadowRecorder(market.quote, would_accept, position_lamports=100_000_000, now=lambda: NOW)


def test_round_trip_records_three_books():
    m = FakeMarket(price=1000.0)
    rec = _recorder(m)
    asyncio.run(rec.on_swap(_swap("buy", 1_000_000, 1_000_000_000)))
    m.price = 1500.0  # +50 %
    asyncio.run(rec.on_swap(_swap("sell", 1_000_000, 1_500_000_000)))
    assert not rec.open and len(rec.closed) == 1
    t = rec.closed[0]
    assert t.wallet_leg.net_return_pct() == pytest.approx(50, abs=0.1)
    copy = t.copy_leg.net_return_pct()
    assert copy is not None and 40 < copy < 50  # frais déduits
    assert t.cart3r_leg.net_return_pct() == pytest.approx(copy)


def test_partial_sell_is_copied_prorata():
    m = FakeMarket(price=1000.0)
    rec = _recorder(m)
    asyncio.run(rec.on_swap(_swap("buy", 1_000_000, 1_000_000_000)))
    held = rec.open[(W, MINT)].copy_leg.tokens_held
    asyncio.run(rec.on_swap(_swap("sell", 250_000, 250_000_000)))
    t = rec.open[(W, MINT)]
    assert t.copy_leg.tokens_held == pytest.approx(held * 0.75, rel=1e-6)


def test_rejected_by_filters_has_no_cart3r_leg():
    rec = _recorder(FakeMarket(price=1000.0), accept=False)
    asyncio.run(rec.on_swap(_swap("buy", 1_000_000, 1_000_000_000)))
    t = rec.open[(W, MINT)]
    assert t.cart3r_leg is None and t.cart3r_reject_reason == "score insuffisant"


def test_quote_failure_marks_not_simulable():
    rec = _recorder(FakeMarket(price=1000.0, fail=True))
    asyncio.run(rec.on_swap(_swap("buy", 1_000_000, 1_000_000_000)))
    t = rec.open[(W, MINT)]
    assert t.copy_leg.status is LegStatus.NOT_SIMULABLE


def test_classify_pump_logs():
    from cart3r.solana.pump import classify_logs
    assert classify_logs(["Program log: Instruction: Create"]) == "created"
    assert classify_logs(["Program log: Instruction: Migrate"]) == "graduated"
    assert classify_logs(["Program log: Instruction: Buy"]) is None


def test_sell_of_unobserved_position_ignored():
    rec = _recorder(FakeMarket(price=1000.0))
    asyncio.run(rec.on_swap(_swap("sell", 10, 10)))
    assert not rec.open and not rec.closed
