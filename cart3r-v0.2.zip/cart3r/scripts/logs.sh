#!/usr/bin/env bash
# CART3R - résumé des erreurs à copier-coller dans la conversation avec Claude.
cd "$(dirname "$0")/.."
docker compose ps
for s in ingest brain guard exec api; do
  echo
  echo "===== $s ====="
  docker compose logs --no-color --tail 25 "$s" 2>&1 | grep -v -i "api-key=" | tail -25
done
