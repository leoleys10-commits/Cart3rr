#!/usr/bin/env bash
# CART3R - configuration guidée (pensée pour un téléphone : on colle les clés une par une).
# Usage : bash scripts/configure.sh
set -euo pipefail
cd "$(dirname "$0")/.."

if [ -f .env ]; then
  read -r -p "Un fichier .env existe déjà. Le remplacer ? (oui/non) " ok
  [ "$ok" = "oui" ] || { echo "Rien n'a été modifié."; exit 0; }
fi

ask() {  # ask "question" variable
  local value=""
  while [ -z "$value" ]; do
    read -r -p "$1 : " value
    value="$(printf '%s' "$value" | tr -d '[:space:]')"
  done
  printf -v "$2" '%s' "$value"
}

echo "Colle chaque valeur puis appuie sur Entrée."
ask "Clé API Helius" HELIUS
ask "Clé API Jupiter" JUPITER
ask "Token du bot Telegram (donné par @BotFather)" TG_TOKEN
ask "Ton Id Telegram (donné par @userinfobot)" TG_ID
case "$TG_ID" in (*[!0-9-]*) echo "L'Id Telegram doit être un nombre."; exit 1;; esac
ask "Choisis un mot de passe pour le dashboard (8 caractères min.)" DASH
[ "${#DASH}" -ge 8 ] || { echo "Mot de passe trop court."; exit 1; }

DB_PASS="$(openssl rand -hex 16)"
TOTP="$(python3 -c 'import base64,secrets;print(base64.b32encode(secrets.token_bytes(20)).decode().rstrip("="))')"

umask 077
cat > .env <<EOF
POSTGRES_PASSWORD=${DB_PASS}
CART3R_DATABASE_URL=postgresql+asyncpg://cart3r:${DB_PASS}@db:5432/cart3r
CART3R_HELIUS_API_KEY=${HELIUS}
CART3R_JUPITER_API_KEY=${JUPITER}
CART3R_TELEGRAM_BOT_TOKEN=${TG_TOKEN}
CART3R_TELEGRAM_OWNER_CHAT_ID=${TG_ID}
CART3R_DASHBOARD_PASSWORD=${DASH}
CART3R_TOTP_SECRET=${TOTP}
CART3R_BACKUP_RPC_URL=
CART3R_RUGCHECK_API_KEY=
EOF
chmod 600 .env

echo
echo "Configuration enregistrée."
echo
echo "DERNIÈRE ÉTAPE : ajoute ce code dans Google Authenticator"
echo "(+  ->  Saisir une clé de configuration  ->  nom : CART3R  ->  Basé sur l'heure)"
echo
echo "    ${TOTP}"
echo
echo "Copie-le maintenant (appui long). Il ne sera plus affiché."
