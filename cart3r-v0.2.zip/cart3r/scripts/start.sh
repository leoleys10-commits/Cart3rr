#!/usr/bin/env bash
# CART3R - construction et démarrage complet. Usage : bash scripts/start.sh
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] || { echo "Lance d'abord : bash scripts/configure.sh"; exit 1; }

echo "1/4  Construction du bot (3 à 8 minutes la première fois)…"
docker compose build

echo "2/4  Démarrage de la base de données…"
docker compose up -d db
for i in $(seq 1 30); do
  docker compose exec -T db pg_isready -U cart3r >/dev/null 2>&1 && break
  sleep 2
done

echo "3/4  Création des tables…"
docker compose run --rm brain python -m cart3r.db.init

echo "4/4  Démarrage des 5 processus…"
docker compose up -d
sleep 10
docker compose ps
echo
echo "Terminé. Tu dois recevoir « CART3R api démarré » sur Telegram. Envoie /status à ton bot."
echo "Un service n'est pas « running » ? Lance : bash scripts/logs.sh"
